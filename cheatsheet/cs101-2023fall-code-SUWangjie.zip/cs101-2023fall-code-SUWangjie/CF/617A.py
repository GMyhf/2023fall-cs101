# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 13:20:44 2023

@author: Lenovo
"""

x=int(input())
print((x+4)//5)