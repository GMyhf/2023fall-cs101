# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 12:57:15 2023

@author: Lenovo
"""
word=input()
print(word[0].upper() + word[1:])