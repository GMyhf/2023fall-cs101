# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 17:23:07 2023

@author: Lenovo
"""

n=int(input())
print(n//100+n%100//20+n%20//10+n%10//5+n%5)