# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 17:20:59 2023

@author: Lenovo
"""

word=[i for i in input().split("WUB")]
for i in word:
    print(i,end=" ")