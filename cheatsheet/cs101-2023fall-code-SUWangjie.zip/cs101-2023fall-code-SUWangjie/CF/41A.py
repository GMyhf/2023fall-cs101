# -*- coding: utf-8 -*-
"""
Created on Thu Sep  7 19:07:28 2023

@author: Lenovo
"""

s=input()
t=input()
s1=s[::-1]
if s1==t:
    print("YES")
else:
    print("NO")