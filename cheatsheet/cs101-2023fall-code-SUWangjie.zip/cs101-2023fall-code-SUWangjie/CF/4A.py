# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 22:37:36 2023

@author: Lenovo
"""

w=int(input())
if w==2 or w%2==1:
    print("No")
else:
    print("Yes")
    