# -*- coding: utf-8 -*-
"""
Created on Fri Dec  8 10:45:07 2023

@author: Lenovo
"""

k=int(input())
l=list(map(int,input().split()))
print(l.count(1))
print(l.count(5))
print(l.count(10))