# -*- coding: utf-8 -*-
"""
Created on Sun Dec 10 00:05:58 2023

@author: Lenovo
"""

print(" ".join(list(input().split())))