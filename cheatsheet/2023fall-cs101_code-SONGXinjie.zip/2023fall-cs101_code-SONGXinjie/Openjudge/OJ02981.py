"""于2023-9-10测试通过"""
print(int(input()) + int(input()))