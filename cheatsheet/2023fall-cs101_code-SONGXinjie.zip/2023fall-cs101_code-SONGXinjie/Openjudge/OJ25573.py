""""""
s = input()
r, b =