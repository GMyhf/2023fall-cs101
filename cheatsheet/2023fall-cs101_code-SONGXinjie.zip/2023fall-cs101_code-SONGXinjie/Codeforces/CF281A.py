"""于2023-8-31测试通过"""
word = input()
wanted_word = word[:1].upper() + word[1:]
print(wanted_word)