"""于2023-8-31测试通过"""
w = int(input())

if w > 2 and w % 2 == 0:
    print('YES')
else:
    print('NO')