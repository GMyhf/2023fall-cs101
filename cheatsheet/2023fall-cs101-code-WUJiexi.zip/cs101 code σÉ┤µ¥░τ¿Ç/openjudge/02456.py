'''
2300015897
'''
n,c = map(int,input().split())
pos = []
for i in range(n):
    pos.append(int(input()))
pos.sort()
l,r = 1,pos[-1] - pos[0]
mid = (l + r) // 2
while l <= r:
    cnt = 0
    check = pos[0]
    for i in range(1,n):
        if pos[i] - check >= mid:
            check = pos[i]
        elif pos[i] - check < mid:
            cnt += 1
    if cnt > n - c:
        r = mid - 1
    else:
        l = mid + 1
    mid = (l + r) // 2
print(mid)