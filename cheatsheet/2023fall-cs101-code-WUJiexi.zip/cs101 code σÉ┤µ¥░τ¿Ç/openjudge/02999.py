'''
2300015897
'''
n = int(input())
a1 = [int(x) for x in input().split()]
m = int(input())
a2 = [int(x) for x in input().split()]
dp =