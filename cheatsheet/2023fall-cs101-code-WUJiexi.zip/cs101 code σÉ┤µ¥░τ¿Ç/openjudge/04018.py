'''
2300015897
'''
while True:
    try:
        s1,s2 = input().split()
        a,b = len(s1),len(s2)
        dp = [[0]*(b + 1) for i in range(a + 1)]
        for i in range(1,a + 1):
            for j in range(1,b + 1):
                if s1[i - 1] == s2[j - 1]:
                    dp[i][j] = dp[i - 1][j - 1] + 1
                else:
                    dp[i][j] = max(dp[i - 1][j],dp[i][j - 1])

        print("Yes" if dp[a][b] == a else "No")
    except:
        break