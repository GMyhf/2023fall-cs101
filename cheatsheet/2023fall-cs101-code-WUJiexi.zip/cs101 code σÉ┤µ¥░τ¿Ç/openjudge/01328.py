'''
2300015897
'''
j = 0
while True:
    j += 1
    n,d = map(int,input().split())
    if n == d == 0:
        break
    pos = []
    flag = 1
    for i in range(n):
        x,y = map(int,input().split())
        if abs(y) > d:
            flag = 0
        else:
            r = (d**2 - y**2)**0.5
            pos.append((x - r,x + r))
    q = input()
    pos.sort()
    pos.sort(key = lambda x:x[1])
    if pos:
        end = pos[0][1]
        cnt = 1
        for i in range(1,len(pos)):
            if pos[i][0] > end:
                cnt += 1
                end = pos[i][1]
    if not flag:
        cnt = -1
    print(f"Case {j}: {cnt}")