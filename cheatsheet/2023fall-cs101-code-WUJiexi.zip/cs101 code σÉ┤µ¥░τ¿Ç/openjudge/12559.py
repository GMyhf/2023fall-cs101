'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
num_list = list(map(str,input().split()))
def quicksort(num):
    if len(num) <= 1:
        return num
    key = num[0]
    llist,mlist,rlist = [],[key],[]
    for i in range(1,len(num)):
        if num[i] + key > key + num[i]:
            llist.append(num[i])
        elif key + num[i] > num[i] + key:
            rlist.append(num[i])
        else:
            mlist.append(num[i])
    return quicksort(llist) + mlist + quicksort(rlist)
max_num = "".join(quicksort(num_list))
min_num = "".join(quicksort(num_list)[::-1])
print(max_num,min_num)

