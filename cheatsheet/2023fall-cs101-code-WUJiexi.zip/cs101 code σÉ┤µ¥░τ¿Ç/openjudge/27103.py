'''
2300015897
'''
n,m = map(int,input().split())
l = list(map(int,input().split()))
i = 0
cnt = 0
while i <= n - 1:
    s = set()
    while i <= n - 1 and len(s) != m:
        s.add(l[i])
        i += 1
    if i == n and len(s) < m:
        break
    cnt += 1
print(cnt + 1)