'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
temp = bin(n)[2:]
if temp == temp[::-1]:
    print("Yes")
else:
    print("No")