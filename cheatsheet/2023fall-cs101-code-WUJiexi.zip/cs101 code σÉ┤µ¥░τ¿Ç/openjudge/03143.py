x=int(input())

def prime(a):
    if a==2:
        return True
    else:
        for i in range(2,int(a**0.5)+1):
            if a%i == 0:
                return False
        return True

if x%2 != 0 or x<6:
    print("Error!")

else:
    for j in range(2,int(x/2)+1):
        if prime(j) and prime(x-j):
            print(f"{x}"+"="+f"{j}+{x-j}")