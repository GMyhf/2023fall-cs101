'''
2300015897
'''
def equation(x):
    return x**3 - 5*(x**2) + 10*x - 80
l,r = 0,10**11
mid = (l + r) // 2

while l < r:
    if equation(mid / 10**10) > 0:
        r = mid - 1
    else:
        l = mid + 1
    mid = (l + r) // 2

print(f'{mid / 10**10:.9f}')