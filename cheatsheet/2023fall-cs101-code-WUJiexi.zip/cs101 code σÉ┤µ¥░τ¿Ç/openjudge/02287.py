'''
2300015897
参考题解
'''
while True:
    n = int(input())
    if n == 0:
        break

    Tian = [int(x) for x in input().split()]
    King = [int(x) for x in input().split()]
    Tian.sort() , King.sort()
    ans = 0

    lT,rT = 0,n - 1
    lK,rK = 0,n - 1

    while lT <= rT:
        if Tian[lT] > King[lK]:
            ans += 1
            lT += 1
            lK += 1
        elif Tian[rT] > King[rK]:
            ans += 1
            rT -= 1
            rK -= 1
        else:
            if Tian[lT] < King[rK]:
                ans -= 1
            lT += 1
            rK -= 1

    print(200*ans)