'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
triangle = []
for i in range(n):
    triangle.append(list(map(int,input().split())))
k = n - 2
while k >= 0:
    for i in range(k + 1):
        triangle[k][i] += max(triangle[k + 1][i],triangle[k + 1][i + 1])
    k -= 1
print(triangle[0][0])