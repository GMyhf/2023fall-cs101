'''
2300015897
吴杰稀
光华管理学院
'''
a = int(input())
b_list = []
for i in range(6):
    b_list.append(8**i)
b_list.sort(reverse = True)
ans = ''
for i in range(6):
    ans += str(a // b_list[i])
    a -= (a // b_list[i]) * b_list[i]
print(int(ans))