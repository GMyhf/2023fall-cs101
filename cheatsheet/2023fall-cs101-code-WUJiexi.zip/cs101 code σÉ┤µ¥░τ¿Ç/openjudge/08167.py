n,m=map(int,input().split())
total_list=[j for j in range(n)]

for i in range(n):
    total_list[i]=list(map(int,input().split()))

#注意复制 分行用copy
new_list=[line.copy() for line in total_list]

for j in range(1,n-1):
    for i in range(1,m-1):
        t=(total_list[j][i-1]+total_list[j][i]+total_list[j][i+1]\
                        +total_list[j-1][i]+total_list[j+1][i])/5

        if t - int(t)>= 0.5:
            t=int(t)+1
        else:
            t=int(t)

        new_list[j][i]=t

#矩阵的输出 使用join函数，并注意用str将数字转化为字符串
for line in new_list:
    print(" ".join(str(i) for i in line))


