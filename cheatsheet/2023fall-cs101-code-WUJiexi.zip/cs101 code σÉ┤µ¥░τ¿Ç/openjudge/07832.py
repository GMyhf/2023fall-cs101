N,A,B=map(int,input().split())

#辗转相除
def gcd_iterative(x,y):
    while y != 0:
        x,y=y,x%y
    return x

delta=1/B
delta1=1/B
a=0
b=0

for i in range(1,N+1):
    fenmu=i

    if i*A/B % 1 ==0:
        fenzi=int(i*A/B)-1
    else:
        fenzi=int(i*A/B)

    t=gcd_iterative(fenzi,fenmu)

    num=fenzi/fenmu

    delta1=A/B-num

    if delta1!= 0 and delta1 < delta and gcd_iterative(fenzi,fenmu) == 1:
        delta=delta1
        a=fenzi
        b=fenmu

print(f"{a} {b}")