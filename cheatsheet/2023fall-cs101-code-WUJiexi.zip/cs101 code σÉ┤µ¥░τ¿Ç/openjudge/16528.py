'''
2300015897
吴杰稀
光华管理学院
'''
time_list = []
time_dict = {}
n = int(input())
for i in range(n):
    start,end = map(int,input().split())
    if start >= 0 and end <= 60:
        if end in time_dict:
            time_dict[end] = max(time_dict[end],start)
        else:
            time_dict[end] = start
for key,value in time_dict.items():
    time_list.append([value,key])

time_list.sort(key = lambda x:x[1])

ans = 0
end = -1
for plan in time_list:
    start,finish = plan[0],plan[1]
    if start > end:
        ans += 1
        end = finish
print(ans)
