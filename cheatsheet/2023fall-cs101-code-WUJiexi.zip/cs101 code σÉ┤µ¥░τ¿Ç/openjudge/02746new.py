'''
2300015897
吴杰稀
光华管理学院
'''
def circle(arr,num):
    total_list = [i for i in range(1,arr + 1)]
    selected = []
    cnt = 0
    while len(total_list) > 1:
        front = total_list.pop(0)
        cnt += 1
        if cnt == num:
            selected.append(front)
            cnt = 0
        else:
            total_list.append(front)
    return total_list[0]
while True:
    n,m = map(int,input().split())
    if n == m == 0:
        break
    else:
        print(circle(n,m))
