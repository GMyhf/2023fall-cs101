'''
2300015897
'''
from heapq import heappop,heappush
dx = [1,0,-1,0]
dy = [0,-1,0,1]
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and not v[x][y]:
        return True
    return False

def bfs(x,y):
    q = [(0,x,y)]
    v[x][y] = True
    while q:
        t,x1,y1 = heappop(q)
        if x1 == ex and y1 == ey:
            return t
        nt = t + 1
        for i in range(4):
            nx,ny = x1 + dx[i],y1 + dy[i]
            if is_valid(nx,ny):
                if not (maze[nx][ny] == "#" and nt % k != 0):
                    v[nx][ny] = True
                    heappush(q,(nt,nx,ny))
    return "Oop!"

cases = int(input())
for i in range(cases):
    m,n,k = map(int,input().split())
    maze = [[x for x in input()] for i in range(m)]
    sx,sy,ex,ey = 0,0,0,0
    for i in range(m):
        for j in range(n):
            if maze[i][j] == "S":
                sx,sy = i,j
            elif maze[i][j] == "E":
                ex,ey = i,j
    v = [[False]*n for i in range(m)]
    print(bfs(sx,sy))