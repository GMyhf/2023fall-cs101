'''
2300015897
'''
times = [int(x) for x in input().split()]
times.sort(reverse = True)
for i in range(len(times)):
    if times[i] >= i + 1:
        h = i + 1
    else:
        break
print(h)