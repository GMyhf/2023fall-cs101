'''
2300015897
吴杰稀
光华管理学院
'''
m,n = map(int,input().split())
blood_list = []
blood_1 = list(map(int,input().split()))
blood_2 = list(map(int,input().split()))
blood_list += blood_1 + blood_2
t = max(blood_list)
k = 0

while k < t:
    flag = 0
    k += 1
    m -= 1
    n -= 2
    for i in range(14):
        if blood_list[i] == 1:
            flag = 1
        blood_list[i] -= 1
    if flag == 1:
        m += 1
        n += 2
    if m <= 0 or n < 2:
        break
flag = 0
for _ in blood_list:
    if _ > 0:
        flag = 1
if flag == 1:
    print("NO")
else:
    print("YES")



