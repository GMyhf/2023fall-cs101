'''
2300015897
'''
import bisect
n = int(input())
l = [int(x) for x in input().split()]
l.sort()
res = 0
while len(l) > 1:
    a = l.pop(0) + l.pop(0)
    res += a
    bisect.insort(l,a)
print(res)