'''
2300015897
'''
from collections import deque
dx = [0,1,0,-1]
dy = [1,0,-1,0]

def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and not in_queue[x][y]:
        return True
    return False

def bfs(x,y,blood):
    global step
    step = 0
    q = deque()
    q.append([x,y,0])

    while q:

        cnt = len(q)

        for i in range(cnt):
            front = q.popleft()

            in_queue[front[0]][front[1]] = True

            for j in range(4):

                nx = front[0] + dx[j]
                ny = front[1] + dy[j]

                if nx == p and ny == q:
                    return

                if is_valid(nx,ny):

                    if maze[nx][ny] == "*":
                        q.append([nx,ny,front[2]])
                    elif maze[nx][ny] == "#":
                        if front[2] - 1 >= 0:
                            q.append([nx,ny,front[2] - 1])

        step += 1

n,m,b = map(int,input().split())
maze = [[x for x in input()] for i in range(n)]
s,t = 0,0
p,q = 0,0
for i in range(n):
    for j in range(m):
        if maze[i][j] == "@":
            s,t = i,j
        elif maze[i][j] == "+":
            p,q = i,j

in_queue = [[False]*m for i in range(n)]
in_queue[s][t] = True

bfs(s,t,b)

print(step)