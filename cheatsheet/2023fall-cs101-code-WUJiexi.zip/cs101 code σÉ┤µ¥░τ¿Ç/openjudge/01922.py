'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    n = int(input())
    if n == 0:
        break
    vt = []
    res = 99999
    for i in range(n):
        v,s = map(int,input().split())
        if 4.5 * 3600 % v == 0:
            t = s + 4.5 * 3600 // v
        else:
            t = s + 4.5 * 3600 // v + 1
        if s >= 0:
            res = min(res,t)
    print(int(res))
