'''
2300015897
'''

def find(x):
    for i in range(1,)
m = int(input())
num_list = [int(x) for x in input().split()]
