'''
2300015897
吴杰稀
光华管理学院
'''
n,m = map(int,input().split())
num_list = [0] * n
connection = [[] for i in range(n)]
matrix = [[0] * n for i in range(n)]

for i in range(m):
    a,b = map(int,input().split())
    num_list[a] += 1
    num_list[b] += 1
    connection[a].append(b)
    connection[b].append(a)

for i in range(n):
    matrix[i][i] = num_list[i]
for i in range(n):
    for j in range(n):
        if i != j:
            if j in connection[i]:
                matrix[i][j] = -1

for _ in matrix:
    print(*_)