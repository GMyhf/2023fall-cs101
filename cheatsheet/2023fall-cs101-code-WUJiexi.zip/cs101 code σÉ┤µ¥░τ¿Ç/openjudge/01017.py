'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    a1,b1,c1,d1,e1,f1 = map(int,input().split())
    if a1 == 0 and b1 == 0 and c1 == 0 and d1 == 0 and e1 == 0 and f1 == 0:
        break
    sum=0

    #6✖6装箱
    sum += f1

    #5✖5和1✖1装箱
    sum += e1
    t = 11*e1
    if a1 <= t:
        a1 = 0
    else:
        a1 = a1 - t

    #4✖4和2✖2和1✖1装箱
    sum += d1
    t = 20*d1
    blank = 5*d1
    if b1 <= blank:
        t = 20*d1 - 4*b1
        b1 = 0
        if a1 <= t:
            a1 = 0
        else:
            a1 = a1 - t
    else:
        b1 = b1 - blank

    #3✖️3装箱
    sum += int(c1//4)
    c1 = c1 - int(c1//4)*4

    #剩余装箱
    if c1 == 0:
        total_space = 4*b1 + a1
        if total_space % 36 == 0:
            sum += total_space//36
        else:
            sum += total_space//36 + 1
    else:
        if c1 == 1:
            blank = 5
        elif c1 == 2:
            blank = 3
        elif c1 == 3:
            blank = 1
        sum += 1
        if b1 <= blank:
            t = 36 - 9*c1 - 4*b1
            if a1 <= t:
                a1 = 0
            else:
                a1 = a1 - t
            if a1 == 0:
                sum += 0
            else:
                total_space = a1
                if total_space % 36 == 0:
                    sum += total_space // 36
                else:
                    sum += total_space // 36 + 1
        else:
            b1 = b1 - blank
            t = 36 - 9 *c1 - 4*blank
            if a1 <= t:
                a1 = 0
            else:
                a1 = a1 - t
            total_space = 4*b1 + a1
            if total_space % 36 == 0:
                sum += total_space // 36
            else:
                sum += total_space // 36 + 1
    print(sum)