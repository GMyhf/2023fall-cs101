'''
2300015897
'''
word = [x for x in input()]
word.sort()
book = [0]*len(word)
res = [0]*len(word)
def dfs(step):
    if step == len(word):
        print(''.join(res))
        return

    for i in range(len(word)):
        if book[i] == 0:
            res[step] = word[i]
            book[i] = 1
            dfs(step + 1)
            book[i] = 0
dfs(0)