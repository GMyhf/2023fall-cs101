'''
2300015897
'''
n,m = map(int,input().split())
d = [int(x) for x in input().split()]
d.sort()
if m == 2:
    print(d[-1] - d[0])
else:
    l,r = 0,d[-1] - d[0]
    mid = (r + l) // 2

    while l <= r:
        check = d[0]
        cnt = 0
        for i in range(1,n):
            if d[i] - check < mid:
                cnt += 1
            else:
                check = d[i]
        if cnt <= n - m:
            l = mid + 1
            mid = (r + l) // 2
        else:
            r = mid - 1
            mid = (r + l) // 2
    print(mid)