T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    locations = list(map(int, input().split()))
    profits = list(map(int, input().split()))

    dp = [0] * n
    dp[0] = profits[0]

    for i in range(1, n):
        for j in range(i - 1, -1, -1):
            if locations[i] - locations[j] > k:
                dp[i] = max(dp[i], dp[j] + profits[i])

    max_profit = max(dp)
    print(max_profit)