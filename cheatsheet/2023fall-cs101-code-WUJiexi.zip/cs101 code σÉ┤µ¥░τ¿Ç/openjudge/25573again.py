'''
2300015897
'''
s = input()
n = len(s)
r,b = [0]*(n + 1),[0]*(n + 1)
if s[0] == "R":
    b[1] = 1
else:
    r[1] = 1
for i in range(2,n + 1):
    if s[i - 1] == "R":
        r[i] = r[i - 1]
        b[i] = min(b[i - 1],r[i - 1]) + 1
    else:
        b[i] = b[i - 1]
        r[i] = min(r[i - 1],b[i - 1]) + 1
print(r[-1])