n=int(input())

import math

for i in range(n):
    a,b,c=map(float,input().split())
    t=b**2-4*a*c
    if b==0:
        b=-b
        
    if t==0:
        m=-b/(2*a)
        print("x1=x2="+f"{m:.5f}")
    elif t>0:
        m1,m2=(-b+math.sqrt(t))/(2*a),(-b-math.sqrt(t))/(2*a)
        print("x1="+f"{m1:.5f}"+";"+"x2="+f"{m2:.5f}")
    else:
        re=-b/(2*a)
        m1=math.sqrt(-t)/(2*a)
        m2=-math.sqrt(-t)/(2*a)
        print(f"x1={re:.5f}+{m1:.5f}i"+";"+f"x2={re:.5f}{m2:.5f}i")