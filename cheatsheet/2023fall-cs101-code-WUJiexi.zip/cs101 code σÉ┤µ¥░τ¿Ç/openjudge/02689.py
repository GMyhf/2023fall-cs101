str=input()
new_string=""
for character in str:
    if character==character.upper():
        new_string+=character.lower()
    else:
        new_string+=character.upper()
print(new_string)