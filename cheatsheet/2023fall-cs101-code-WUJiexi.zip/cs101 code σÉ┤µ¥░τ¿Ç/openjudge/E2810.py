'''
2300015897
吴杰稀
光华管理学院
'''
def cubic_caculator(a):
    for b in range(2,int( ((a**3)/3)**(1/3) ) + 1):
        t_1 = a**3 - b**3
        for c in range(b,int( (t_1/2)**(1/3) ) + 1):
            t_2 = t_1 - c**3
            for d in range(c,int( (t_2)**(1/3) + 2 )):
                if d**3 == t_2:
                    print(f"Cube = {a}, Triple = ({b},{c},{d})")

n = int(input())
for a in range(3,n+1):
    cubic_caculator(a)

