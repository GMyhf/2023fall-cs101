#来自题解
s = input().split()
def cal():
    chr = s.pop(0)
    if chr in "+-*/":
        return str(eval(cal() + chr + cal()))
    else:
        return chr
t = float(cal())
print(f"{t:.6f}")