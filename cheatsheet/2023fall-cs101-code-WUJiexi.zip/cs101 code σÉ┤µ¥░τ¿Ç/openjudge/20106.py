'''
2300015897
参考2300011072
'''
from heapq import heappop,heappush
m,n,p = map(int,input().split())
dx,dy = [1,0,-1,0],[0,-1,0,1]

def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != "#":
        return True
    return False

def bfs(x,y):
    v = [[False] * n for i in range(m)]
    q = [(0,x,y)]
    while q:
        t,x,y = heappop(q)
        v[x][y] = True
        if x == ex and y == ey:
            return t
        for i in range(4):
            nx = x + dx[i]
            ny = y + dy[i]
            if is_valid(nx,ny):
                if not v[nx][ny]:
                    nt = t + abs(maze[nx][ny] - maze[x][y])
                    heappush(q,(nt,nx,ny))
    return "NO"

maze = []
for i in range(m):
    t = [int(x) if x != "#" else str(x) for x in input().split()]
    maze.append(t)

res = [[0]*n for i in range(m)]

for i in range(p):
    sx,sy,ex,ey = map(int,input().split())
    if maze[sx][sy] == "#" or maze[ex][ey] == "#":
        print("NO")
    else:
        print(bfs(sx,sy))
