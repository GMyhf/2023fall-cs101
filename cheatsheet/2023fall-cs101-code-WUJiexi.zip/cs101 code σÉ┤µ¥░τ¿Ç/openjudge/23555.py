'''
2300015897
吴杰稀
光华管理学院
'''
n,m1,m2 = map(int,input().split())
matrix_A = [[0]*n for i in range(n)]
matrix_B = [[0]*n for i in range(n)]
for i in range(m1):
    a,b,c = map(int,input().split())
    matrix_A[a][b] = c
for i in range(m2):
    a,b,c = map(int,input().split())
    matrix_B[a][b] = c

def matrix_multiple(x,y):
    matrix_C = [[0]*n for i in range(n)]
    for i in range(n):
        for j in range(n):
            for t in range(n):
                matrix_C[i][j] += x[i][t] * y[t][j]
    return matrix_C

consequence = matrix_multiple(matrix_A,matrix_B)
for i in range(n):
    for j in range(n):
        if consequence[i][j] != 0:
            print(i,j,consequence[i][j])