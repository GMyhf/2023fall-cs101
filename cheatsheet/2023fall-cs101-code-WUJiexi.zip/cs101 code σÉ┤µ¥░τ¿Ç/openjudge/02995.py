'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
altitude = list(map(int,input().split()))
dp_up = [1] * n
dp_down = [1] * n
for i in range(1,n):
    for j in range(i):
        if altitude[j] < altitude[i]:
            dp_up[i] = max(dp_up[i],1 + dp_up[j])
altitude.reverse()

for i in range(1,n):
    for j in range(i):
        if altitude[j] < altitude[i]:
            dp_down[i] = max(dp_down[i],1 + dp_down[j])
dp_down.reverse()

res = dp_up[0] + dp_down[0]
for i in range(1,n):
    if dp_up[i] + dp_down[i] > res:
        res = dp_up[i] + dp_down[i]
print(res - 1)
