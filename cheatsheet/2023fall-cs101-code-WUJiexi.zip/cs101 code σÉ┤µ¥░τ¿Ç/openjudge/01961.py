no=0
while True:
    no += 1
    l = int(input())
    if l == 0:
        break
    s = input()
    print(f"Test case #{no}")

    if s[0] == s[1]:
        print("2 2")










