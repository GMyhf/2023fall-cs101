'''
2300015897
'''
t = int(input())
for i in range(t):
    n = int(input())
    p = [int(x) for x in input().split()]
    l,r= [p[0]] * n,[p[-1]] * n
    pl,pr = [0]*n,[0]*n
    for i in range(1,n):
        l[i] = min(p[i],l[i - 1])
        pl[i] = max(pl[i - 1],p[i] - l[i])
    for j in range(n - 2,-1,-1):
        r[j] = max(p[j],r[j + 1])
        pr[j] = max(pr[j + 1],r[j] - p[j])
    res = 0
    for i in range(1,n - 1):
        res = max(res,pl[i] + pr[i])
    print(res)