'''
2300015897
吴杰稀
光华管理学院
'''
temp = input()
temp = temp.strip()
word_list = list(input().split())
wordlist = ''.join(_ for _ in word_list)
i_list = []
add_up = 0

for i in range(len(word_list)):
    if temp.lower() == word_list[i].lower():
        add_up += 1
        i_list.append(i)
index = 0
if add_up != 0:
    for _ in word_list[:i_list[0]]:
        index += len(_)
    index += i_list[0]
    print(f"{add_up} {index}")
else:
    print("-1")
