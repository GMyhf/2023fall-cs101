n=int(input())
whole_coins=["A","B","C","D","E","F","G","H","I","J","K","L"]
suspected_coins = whole_coins.copy()
removal_list = []

for i in range(n):
    a1,b1,c1 = input().split()
    a2,b2,c2 = input().split()
    a3,b3,c3 = input().split()
    list_a = [a1,a2,a3]
    list_b = [b1,b2,b3]
    list_c = [c1,c2,c3]
    appear_letter = [_ for _ in a1] + [_ for _ in a2] + [_ for _ in a3]\
                   +[_ for _ in b1] + [_ for _ in b2] + [_ for _ in b3]

    appear_set = set(appear_letter)
    disappear_list = [_ for _ in whole_coins if _ not in appear_set]

    for i in range(3):
        if list_c[i] == "even":
            for _ in list_a[i]:
                if _ in whole_coins:
                    removal_list.append(_)

            for _ in list_b[i]:
                if _ in whole_coins:
                    removal_list.append(_)

            removal_set = set(removal_list)

            for i in range(12):
                if suspected_coins[i] in removal_set:
                    suspected_coins[i] = False

    for _ in suspected_coins:
        if _ and _ not in disappear_list:
            if "up" in list_c:
                if _ in b1 or _ in b2 or _ in b3:
                    print(f"{_} is the counterfeit coin and it is light.")
                else:
                    print(f"{_} is the counterfeit coin and it is heavy.")
            else:
                if _ in b1 or _ in b2 or _ in b3:
                    print(f"{_} is the counterfeit coin and it is heavy.")
                else:
                    print(f"{_} is the counterfeit coin and it is light.")


