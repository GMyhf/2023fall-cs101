'''
2300015897
吴杰稀
光华管理学院
'''
from collections import deque
dx = [-1,-1,-1,0,0,1,1,1]
dy = [-1,0,1,-1,1,-1,0,1]
cases = int(input())

def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and maze[x][y] == "W" and not in_queue[x][y]:
        return True
    return False

def bfs(x,y):
    area = 0
    q = deque([(x,y)])
    while q :
        front = q.popleft()
        for i in range(8):
            nx = front[0] + dx[i]
            ny = front[1] + dy[i]
            if is_valid(nx,ny):
                area += 1
                in_queue[nx][ny] = True
                q.append((nx,ny))
    if area == 0 and maze[x][y] == "W":
        return 1
    return area

for i in range(cases):
    ans = 0
    n,m = map(int,input().split())
    maze = [[x for x in input()] for i in range(n)]
    in_queue = [[False] * m for i in range(n)]
    for i in range(n):
        for j in range(m):
            if maze[i][j] == "W" and not in_queue[i][j]:
                ans = max(ans,bfs(i,j))
    print(ans)