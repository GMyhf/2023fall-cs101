'''
2300015897
'''
T = int(input().strip())
for _ in range(T):
    n, k = map(int, input().strip().split())
    locations = list(map(int, input().strip().split()))
    profits = list(map(int, input().strip().split()))
    dp = [0]*n
    dp[0] = profits[0]
    for i in range(1, n):
        dp[i] = max(dp[i-1], profits[i]) # 不在当前位置开设餐馆
        for j in range(i):
            if locations[i] - locations[j] > k:
                dp[i] = max(dp[i], dp[j] + profits[i]) # 在当前位置开设餐馆
    print(dp[-1])