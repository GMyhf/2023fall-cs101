n=int(input())

if 0<n<100:
    list=[]

    for m in range(1,n+1):
        if m%7 != 0 and m//10!=7 and m%10!=7:
            list.append(m)
    
    sum=0

    for x in list:
        sum+=x**2
        
    print(sum)