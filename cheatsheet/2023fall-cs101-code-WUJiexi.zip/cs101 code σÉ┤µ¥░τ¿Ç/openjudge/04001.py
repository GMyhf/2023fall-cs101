'''
2300015897
吴杰稀
光华管理学院
'''
from collections import deque

n,k = map(int,input().split())
in_queue = [False] * 100010
def get_step(start,end):
    q = deque()
    step = 0
    q.append(start)
    while True:
        cnt = len(q)
        for i in range(cnt):
            front = q.popleft()
            if front == end:
                return step
            in_queue[front] = True
            if 2*front <= 100000 and not in_queue[2*front]:
                q.append(2*front)
            if front + 1 <= 100000 and not in_queue[front + 1]:
                q.append(front + 1)
            if 0 <= front - 1 and not in_queue[front - 1]:
                q.append(front - 1)
        step += 1
print(get_step(n,k))


