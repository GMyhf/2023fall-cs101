def change(x,y):
    if len(x)>len(y):
        x,y=y,x
    else:
        x,y=x,y
    return x,y

while True:
    try:
        n=int(input())

        list=[]

        for _ in range(n):
            str=input()
            list.append(str)

            if str=="stop":
                list.remove("stop")
                break

        for i in range(len(list)-1):
            for j in range(i,len(list)):
                list[i],list[j]=change(list[i],list[j])

        for m in list:
            print(m)
    except:
        break
