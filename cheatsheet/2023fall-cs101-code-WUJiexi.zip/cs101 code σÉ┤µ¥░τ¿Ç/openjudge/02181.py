'''
2300015897
参考胡睿诚
'''
p = int(input())
h = [int(input()) for i in range(p)]
res = 0
k = 1
for i in range(p - 1):
    if (h[i + 1] - h[i])*k < 0:
        res += k * h[i]
        k = -k
if k == 1:
    res += h[-1]
print(res)



