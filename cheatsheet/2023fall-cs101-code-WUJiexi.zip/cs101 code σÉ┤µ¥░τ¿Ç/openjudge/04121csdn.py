def main():
    n1 = int(input())
    for l in range(n1):
        n = int(input())
        a = list(map(int, input().split()))
        p = [0] * (n + 1)  # 第i天卖出可获最大利益
        q = [0] * (n + 1)  # 第i天买入可获最大利益
        # 第i天卖出可获最大利益 当天价格 - 前面几天的最低价
        min1 = float('inf')
        for i in range(1, n + 1):
            min1 = min(min1, a[i])
            p[i] = a[i] - min1
        # 第i天买入获得的最大利益 后面天的最大值 - 当天价格
        max1 = -float('inf')
        for i in range(n, 0, -1):
            max1 = max(max1, a[i])
            q[i] = max1 - a[i]
        tmp = -float('inf')
        ans = -float('inf')
        for i in range(1, n + 1):
            tmp = max(tmp, p[i])  # 表示前些天卖出的最大利益
            # 表示前些天卖出的最大利益+这天买入的最大利益
            # 则为这些天两次买入卖出的最大利益
            ans = max(ans, tmp + q[i])
        print(ans)

if __name__ == "__main__":
    main()