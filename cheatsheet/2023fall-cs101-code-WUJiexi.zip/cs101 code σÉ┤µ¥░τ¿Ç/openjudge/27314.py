'''
2300015897
'''
s1 = input().lower()
s2 = ''
change = [x.lower() for x in input().split()]
for _ in s1:
    if _ == "," or _ == ".":
        s2 += ' ' + _
    else:
        s2 += _
s = s2.split()
if s[0] == change[0]:
    s[0] = change[1]
res = s[0].title()
for i in range(1,len(s)):
    if s[i] in ".,":
        res += s[i]
        continue
    if s[i] == change[0]:
        s[i] = change[1]
    if s[i - 1] == ".":
        res += ' ' + s[i].title()
    else:
        res += ' ' + s[i]
print(res)




