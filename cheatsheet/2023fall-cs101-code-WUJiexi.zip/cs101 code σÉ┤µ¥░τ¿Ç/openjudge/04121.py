'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    n = int(input())
    price_list = [int(x) for x in input().split()]
    x,y = price_list[0],price_list[-1]
    l,r = [x]*n,[y]*n
    pl,pr = [0]*n,[0]*n
    for i in range(1,n):
        l[i] = min(l[i - 1],price_list[i])
        #第i天前卖最大收益
        pl[i] = max(pl[i - 1],price_list[i] - l[i])
    for i in range(n - 2,-1,-1):
        r[i] = max(r[i + 1],price_list[i])
        #第i天后卖最大收益
        pr[i] = max(pr[i + 1],r[i] - price_list[i])
    ans = 0
    for i in range(1,n - 1):
        ans = max(ans,pl[i] + pr[i + 1])
    print(ans)