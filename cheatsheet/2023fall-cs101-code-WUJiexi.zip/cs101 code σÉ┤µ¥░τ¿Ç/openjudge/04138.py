'''
2300015897
吴杰稀
光华管理学院
'''

def exam_prime(a):
    if a == 2:
        return True
    else:
        t = int(a**(1/2)+1)
        sum = 0
        for i in range(2,t + 1):
            if a % i == 0:
                sum += 1
        if sum == 0:
            return True
        else:
            return False
s = int(input())
if s % 2 == 0:
    start = int(s//2)
else:
    start = int(s//2 + 1)
while True:
    if exam_prime(start) and exam_prime(s - start):
        print(start*(s-start))
        break
    else:
        start -= 1
