'''
2300015897
'''
import sys
sys.setrecursionlimit(200000)
dx,dy = [1,0,-1,0],[0,-1,0,1]
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != ".":
        return True
    return False
def dfsX(x,y):
    maze[x][y] = "."
    for j in range(4):
        nx,ny = x + dx[j],y + dy[j]
        if is_valid(nx,ny):
            if maze[nx][ny] == "X":
                dfsX(nx,ny)
def dfs(x,y):
    global cnt
    maze[x][y] = "."
    for i in range(4):
        nx,ny = x + dx[i],y + dy[i]
        if is_valid(nx,ny):
            if maze[nx][ny] == "*":
                dfs(nx,ny)
            elif maze[nx][ny] == "X":
                dfsX(nx,ny)
                cnt += 1
                dfs(nx,ny)
k = 0
while True:
    k += 1
    n,m = map(int,input().split())
    if n == m == 0:
        break
    maze = [[x for x in input()] for i in range(m)]
    ans = []
    for i in range(m):
        for j in range(n):
            if maze[i][j] == "*":
                cnt = 0
                dfs(i,j)
                if cnt != 0:
                    ans.append(cnt)
            elif maze[i][j] == "X":
                dfsX(i,j)
                ans.append(1)
    ans.sort()
    print(f"Throw {k}")
    print(*ans)
    print()