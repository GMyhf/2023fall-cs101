'''
2300015897
'''
n = int(input())
num = [int(x) for x in input().split()]
num.sort(reverse=True)
t = int(input())
for i in range(t):
    print(num[i])