'''
2300015897
'''
from heapq import heappush,heappop

dx = [1,0,-1,0]
dy = [0,-1,0,1]

def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != 2:
        return True
    return False

def bfs(x,y):
    q = [(0,x,y)]
    while q:
        step,x1,y1 = heappop(q)
        if maze[x1][y1] == 1:
            return step
        maze[x1][y1] = 2
        for i in range(4):
            nx,ny = x1 + dx[i],y1 + dy[i]
            if is_valid(nx,ny):
                heappush(q,(step + 1,nx,ny))
    return "NO"

m,n = map(int,input().split())
maze = [[int(x) for x in input().split()] for i in range(m)]
print(bfs(0,0))