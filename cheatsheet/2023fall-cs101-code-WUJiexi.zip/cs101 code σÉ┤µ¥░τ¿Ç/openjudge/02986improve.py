'''
2300015897
吴杰稀
光华管理学院
'''
import math
def count_2(n,k):
    if n - k < k:
        k = n - k
    count_n,count_k = 0,0
    for i in range(n-k+1,n+1):
        t = int(math.log(i,2))
        count_n += t
    for j in range(1,k + 1):
        t = int(math.log(j,2))
        count_k += t
    if count_n > count_k:
        return "0"
    else:
        return "1"

while True:
    try:
        a,b = map(int,input().split())
        print(int(count_2(a,b))%2)
    except:
        break