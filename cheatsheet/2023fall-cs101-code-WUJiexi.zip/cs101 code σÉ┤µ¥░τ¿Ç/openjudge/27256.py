'''
2300015897
'''

from bisect import bisect efta, b, cnt, now = [],[], 0, efor  in range(int(input())):opt = input().split()if opt[o] == 'query':1 = len(a)if 1 & 1: print(a[l >> 1][o])else:
ans = (a[l >> 1][e] + a[1 - 1 >> 1][0]) / 2print(ans if int(ans)!= ans else int(ans))if opt[o] == 'add':v = int(opt[1])a.insert(bisect_left(a,[v, 0]),[v, cnt])b. append(v)cnt += 1if opt[e] =='del':v = b[now]
now += 1a.pop(bisect_left(a,[v, 0]))