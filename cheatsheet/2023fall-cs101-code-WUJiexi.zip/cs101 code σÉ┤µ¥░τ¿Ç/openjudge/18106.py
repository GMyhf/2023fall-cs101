'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
res = [[0] * n for i in range(n)]
move = [[0,1],[1,0],[0,-1],[-1,0]]
i,j = 0,0
step = 0
for k in range(1,n**2 + 1):
    res[i][j] = k
    next_i,next_j = i + move[step][0],j + move[step][1]
    if next_i < 0 or next_i >= n or next_j < 0 or next_j >= n or res[next_i][next_j] != 0:
        step = (step + 1) % 4
        next_i,next_j = i + move[step][0],j + move[step][1]
    i,j = next_i,next_j
for _ in res:
    print(*_)