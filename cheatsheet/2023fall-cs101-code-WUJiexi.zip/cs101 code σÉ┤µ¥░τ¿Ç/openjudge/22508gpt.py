'''
2300015897
'''
from collections import defaultdict
def calculate_min_award(n, m, pks):
    graph = defaultdict(list)
    indegree = [0] * n

    for a, b in pks:
        graph[b].append(a)
        indegree[a] += 1

    dp = [100] * n  # 初始化奖金为100

    for i in range(n):
        if indegree[i] == 0:
            dfs(i, graph, indegree, dp)

    return sum(dp)


def dfs(node, graph, indegree, dp):
    if indegree[node] == 0:
        return

    for neighbor in graph[node]:
        if dp[neighbor] <= dp[node]:
            dp[neighbor] = dp[node] + 1
        indegree[neighbor] -= 1
        if indegree[neighbor] == 0:
            dfs(neighbor, graph, indegree, dp)


# 读取输入
n, m = map(int, input().split())
pks = [list(map(int, input().split())) for _ in range(m)]

# 计算最小奖金
min_award = calculate_min_award(n, m, pks)
print(min_award)