'''
2300015897
'''
from collections import deque
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < n and maze[x][y] != 1:
        return True
    return False
dx = [1,0,-1,0]
dy = [0,-1,0,1]
def bfs(s):
    s1 = s[0]
    s2 = s[1]
    if s1[0] != s2[0]:
        visit = [[False] * n for i in range(n - 1)]
    else:
        visit = [[False] * (n - 1) for i in range(n)]
    q = deque([(s1,s2)])
    while q:
        cnt = len(q)
        for i in range(cnt):
            front1,front2 = q.popleft()
            for i in range(4):
                nx1,ny1,nx2,ny2 = front1[0] + dx[i],front1[1] + dy[i],front2[0] + dx[i],front2[1] + dy[i]
                if is_valid(nx1,ny1) and is_valid(nx2,ny2) and not visit[nx1][ny1]:
                    if (nx1 == ex and ny1 == ey) or (nx2 == ex and ny2 == ey):
                        return "yes"
                    visit[nx1][ny1] = True
                    q.append(((nx1,ny1),(nx2,ny2)))
    return "no"

n = int(input())
maze = [[int(x) for x in input().split()] for i in range(n)]
start = []
ex,ey = 0,0
for i in range(n):
    for j in range(n):
        if maze[i][j] == 9:
            ex,ey = i,j
        elif maze[i][j] == 5:
            start.append((i,j))
print(bfs(start))