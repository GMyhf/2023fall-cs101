'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    array = [int(x) for x in input().split()]
    array.sort()
    if len(array) == 1 or len(array) == 2:
        print("True")
    else:
        flag = 1
        exam = array[1] - array[0]
        for i in range(2,len(array)):
            if array[i] - array[i - 1] != exam:
                print("False")
                flag = 0
                break
        if flag == 1:
            print("True")