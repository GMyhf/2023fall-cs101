'''
2300015897
'''
dx = [0,1,0,-1]
dy = [1,0,-1,0]
t,n = map(int,input().split())
num = [[0] * n for i in range(n)]
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < n and num[x][y] == 0:
        return True
    return False
add_up = 1
x0,y0 = 0,0
k = 0
while add_up <= n ** 2:
    num[x0][y0] = add_up
    nx,ny = x0 + dx[k],y0 + dy[k]
    if is_valid(nx,ny):
        x0,y0 = nx,ny
    else:
        k = (k + 1) % 4
        x0,y0 = x0 + dx[k],y0 + dy[k]
    add_up += 1
for i in range(t):
    px,py = map(int,input().split())
    print(num[px - 1][py - 1])