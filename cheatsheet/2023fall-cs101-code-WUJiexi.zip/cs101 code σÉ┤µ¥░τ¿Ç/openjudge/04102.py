'''
2300015897
'''
N, M, K = map(int, input().split())
L = [[-1]*(M+1) for i in range(K+1)]
L[0][M] = N
for i in range(K):
    cost, dmg = map(int, input().split())
    for p in range(M):
        for q in range(i+1, 0, -1):
            if p+dmg <= M and L[q-1][p+dmg] >= 0:
                L[q][p] = max(L[q][p], L[q-1][p+dmg]-cost)
for i in range(K, -1, -1):
    for j in range(M, -1, -1):
        if L[i][j] != -1:
            print(i,j)
            exit()