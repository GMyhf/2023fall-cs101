'''
2300015897
吴杰稀
光华管理学院
'''
dx = [-1,-1,-1,0,0,1,1,1]
dy = [-1,0,1,-1,1,-1,0,1]
cases = int(input())

def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and maze[x][y] == "W":
        return True
    return False

def dfs(x,y):
    global area
    maze[x][y] = "."
    for i in range(8):
        nx = x + dx[i]
        ny = y + dy[i]
        if is_valid(nx,ny):
            dfs(nx,ny)

for i in range(cases):
    ans = 0
    n,m = map(int,input().split())
    maze = [[x for x in input()] for i in range(n)]
    for i in range(n):
        for j in range(m):
            if maze[i][j] == "W":
                dfs(i,j)
                ans += 1
    print(ans)