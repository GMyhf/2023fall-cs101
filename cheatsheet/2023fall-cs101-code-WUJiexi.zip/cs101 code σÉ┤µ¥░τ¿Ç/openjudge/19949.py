'''
2300015897
'''
n = int(input())
cnt = 0
for i in range(n):
    string = input().split()
    i = 0
    while i < len(string):
        tmp = string[i]
        if "###" in tmp:
            if len(tmp) > 6 and tmp[:3] == tmp[-3:] == "###":
                while i < len(string) - 1:
                    if "###" not in string[i + 1]:
                        break
                    i += 1
                cnt += 1
                i += 1
        else:
            i += 1
print(cnt)