# 创建一个空的字典来存储数字和出现次数
number_count = {}

# 循环读取输入，直到输入结束
while True:
    try:
        line = input()
        # 遍历每个字符
        for char in line:
            # 检查字符是否为数字
            if char.isdigit():
                # 字符是数字，将其添加到字典中，如果已存在，则增加计数
                if char in number_count:
                    number_count[char] += 1
                else:
                    number_count[char] = 1
    except EOFError:
        break

# 将数字和出现次数按照数字大小排序
sorted_numbers = sorted(number_count.items(), key=lambda x: int(x[0]))

# 输出结果
for number, count in sorted_numbers:
    print(number + ":" + str(count))