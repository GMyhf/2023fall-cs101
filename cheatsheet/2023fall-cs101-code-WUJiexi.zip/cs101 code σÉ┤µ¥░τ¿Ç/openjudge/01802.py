'''
2300015897
'''
letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
dic = {}
for _ in letter:
    dic[_] = 0
para = [input() for i in range(4)]
mx = 0
for _ in para:
    for x in _:
        if x in dic:
            dic[x] += 1
            mx = max(mx,dic[x])
res = [[0] * 26 for i in range(mx + 1)]
for i in range(26):
    res[-1][i] = letter[i]
    for j in range(-2,-2 - dic[letter[i]],-1):
        res[j][i] = "*"
for _ in res:
    ans = ''
    for m in _:
        if m != 0:
            ans += m
        else:
            ans += ' '
    print(' '.join([x for x in ans]))