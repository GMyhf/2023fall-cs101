'''
2300015897
'''
from heapq import heappop,heappush
dx = [1,0,-1,0]
dy = [0,-1,0,1]
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != "#":
        return True
    return False

def bfs(t,x,y):
    q = [(t,x,y)]
    visit = [[False]*n for i in range(m)]
    while q:
        t1,x1,y1 = heappop(q)
        visit[x1][y1] = True
        if maze[x1][y1] == "a":
            return t1
        for i in range(4):
            nx,ny = x1 + dx[i],y1 + dy[i]
            if is_valid(nx,ny) and not visit[nx][ny]:
                if maze[nx][ny] == "x":
                    nt = t1 + 2
                else:
                    nt = t1 + 1
                heappush(q,(nt,nx,ny))
                visit[nx][ny] = True
    return "Impossible"

cases = int(input())
for i in range(cases):
    flag = 0
    m,n = map(int,input().split())
    maze = [[x for x in input()] for i in range(m)]
    sx,sy,ex,ey = 0,0,0,0
    for i in range(m):
        for j in range(n):
            if maze[i][j] == "r":
                sx,sy = i,j
                flag = 1
                break
    if flag:
        print(bfs(0,sx,sy))
    else:
        print("Impossible")

