'''
2300015897
'''
cases = int(input())
for i in range(cases):
    maax,miin = 0,0
    l,n = map(int,input().split())
    ant = [int(x) for x in input().split()]
    for _ in ant:
        maax = max(maax,max(_,l - _))
        miin = max(miin,min(_,l - _))
    print(miin,maax)