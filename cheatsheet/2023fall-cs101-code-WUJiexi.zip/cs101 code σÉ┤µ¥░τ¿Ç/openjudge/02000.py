def sum(x):
    sum=0
    x=n
    group=int((-1+(1+8*x)**0.5)/2)
    for i in range(group+1):
        sum+=i*i
    sum+=(x-group*(group+1)/2)*(group+1)
    return int(sum)

while True:
    n=int(input())
    if n==0:
        break
    t=sum(n)
    print(f"{n} {t}")
