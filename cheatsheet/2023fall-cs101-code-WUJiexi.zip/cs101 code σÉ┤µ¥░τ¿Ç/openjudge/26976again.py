'''
2300015897
参考胡睿诚
'''
def sgn(x):
    if x == 0:
        return 0
    elif x > 0:
        return 1
    elif x < 0:
        return -1

n = int(input())
num = [int(x) for x in input().split()]
delta = [sgn(num[i + 1] - num[i]) for i in range(n - 1)]
res = 1
sign = 0
for i in range(n - 1):
    if delta[i] * sign < 0 or (sign == 0 and delta[i] != 0):
        res += 1
        sign = delta[i]
print(res)