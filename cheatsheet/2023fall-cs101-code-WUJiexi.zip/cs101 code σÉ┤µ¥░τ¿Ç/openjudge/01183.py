list=[]
a=int(input())
for i in range(1,a+1):
    if (a**2+1)%i == 0:
        list.append(i)
l=len(list)
sum=a*2+list[-1]+(a**2+1)/list[-1]
print(int(sum))