#定义函数
def min(x,y):
    if x<y:
        return x
    else:
        return y
def max(x,y):
    if x>y:
        return x
    else:
        return y
    
#输入
while True:
    try:
        a,b=map(int,input().split())

        if a%b == 0 or b%a == 0:
            print(min(a,b))
        
        else:
            list=[]

            t=min(a,b)
            for i in range(1,int(t**0.5)+1):
                if t%i ==0:
                    list.append(i)
                    list.append(int(t//i))

            list.sort()

            new_list=[]

            for j in range(len(list)):
                if max(a,b)%list[j] == 0:
                    new_list.append(list[j])
                    
            print(new_list[-1])
    except:
        break