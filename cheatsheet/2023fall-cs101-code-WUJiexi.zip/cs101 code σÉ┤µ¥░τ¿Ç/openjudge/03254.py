'''
2300015897
吴杰稀
光华管理学院
'''
def circle(arr,start,num):
    total_list = []
    for i in range(start,start + arr):
        if i % arr == 0:
            i = arr
        else:
            i = i % arr
        total_list.append(i)
    selected = []
    cnt = 0
    while len(total_list) > 1:
        front = total_list.pop(0)
        cnt += 1
        if cnt == num:
            selected.append(front)
            cnt = 0
        else:
            total_list.append(front)
    selected.append(total_list[0])
    return ','.join([str(x) for x in selected])

while True:
    n,p,m = map(int,input().split())
    if n == p == m == 0:
        break
    else:
        print(circle(n,p,m))