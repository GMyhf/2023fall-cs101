times=int(input())
list=[]

for i in range(times):

    n=int(input())

    for j in range(1,n+1):

        for x in range(1,j):
            sum=0
            if j%x==0:
                sum+=1

        list.append(sum)

    for y in list:
        a=0
        if y%2 != 0:
            a+=1

    print(a)