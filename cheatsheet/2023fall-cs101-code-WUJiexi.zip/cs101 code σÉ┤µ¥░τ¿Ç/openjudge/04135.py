'''
2300015897
吴杰稀
光华管理学院
'''
n,m = map(int,input().split())
budget = [0]
add_up = 0
mx = 0
for i in range(n):
    t = int(input())
    mx = max(t,mx)
    add_up += t
    budget.append(add_up)
l,r = mx,budget[-1]

mid = (l + r + 1) // 2

while l <= r:
    check = 0
    total = 0
    for i in range(1,n + 1):
        if budget[i] - check > mid:
            check = budget[i - 1]
            total += 1
            #print(check)
        if i == n and budget[i] - check <= mid:
            total += 1
    if total <= m:
        r = mid - 1
        mid = (l + r + 1) // 2
    else:
        l = mid + 1
        mid = (l + r + 1) // 2
print(mid)