'''
2300015897
'''
cases = int(input())
ans = ["heavy","light"]
coins = "ABCDEFGHIJKL"
for i in range(cases):
    tests = []
    for i in range(3):
        tests.append([x for x in input().split()])
    for coin in coins:
        for answer in ans:
            flag = 1
            for test in tests:
                left = test[0]
                right = test[1]
                res = test[2]
                if coin in left:
                    if answer == "heavy":
                        should_be = "up"
                    else:
                        should_be = "down"
                elif coin in right:
                    if answer == "light":
                        should_be = "up"
                    else:
                        should_be = "down"
                else:
                    should_be = "even"
                if should_be != res:
                    flag = 0
                    break
            if flag == 1:
                print(f"{coin} is the counterfeit coin and it is {answer}.")
                break