l = int(input())
s = input()
def palin(string):
    s1 = string
    s2 = string[::-1]
    dp = [0] * (l + 1)
    for i in range(1, l + 1):
        prev = 0
        for j in range(1, l + 1):
            curr = dp[j]
            if s1[i - 1] == s2[j - 1]:
                dp[j] = prev + 1
            else:
                dp[j] = max(dp[j], dp[j - 1])
            prev = curr
    return dp[-1]

print(l - palin(s))