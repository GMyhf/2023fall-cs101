'''
2300015897
'''
t,w = map(int,input().split())
info = [int(input()) for i in range(t)]
dp = [[0]*(w + 1) for i in range(t + 1)]
if info[0] == 1:
    dp[1][0] = 1
else:
    dp[1][1] = 1
for i in range(2,t + 1):
    dp[i][0] = dp[i - 1][0] + info[i - 1] % 2
for i in range(2,t + 1):
    for j in range(1,w + 1):
        dp[i][j] = max(dp[i - 1][j - 1],dp[i - 1][j])
        if j % 2 + 1 == info[i - 1]:
            dp[i][j] += 1
ans = 0
for j in range(w + 1):
    ans = max(ans,dp[-1][j])
print(ans)

