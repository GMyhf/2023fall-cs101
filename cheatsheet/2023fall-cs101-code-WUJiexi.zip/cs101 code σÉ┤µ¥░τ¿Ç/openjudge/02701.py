n=int(input())

if 0<n<100:
    list=[m for m in range(1,n+1)]

    for m in list:
        if m%7 == 0 or m//10==7 or m%10==7:
            list[m-1]=False
#不要删乱了
    sum=0

    for x in list:
        sum+=x**2
        
    print(sum)