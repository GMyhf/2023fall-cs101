'''
2300015897
'''
n = int(input())
for i in range(n):
    s = int(input())
    la = int(input())
    a = [int(x) for x in input().split()]
    lb = int(input())
    b = [int(x) for x in input().split()]
    dic = {}
    res = 0
    for _ in a:
        dic[_] = dic.get(_,0) + 1
    for _ in b:
        res += dic.get(s - _,0)
    print(res)