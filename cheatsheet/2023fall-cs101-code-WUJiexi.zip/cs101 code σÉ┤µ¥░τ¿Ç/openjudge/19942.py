'''
2300015897
吴杰稀
光华管理学院
'''
m,n,p,q = map(int,input().split())
matrixA,matrixB = [],[]
for i in range(m):
    matrixA.append(list(map(int,input().split())))
for i in range(p):
    matrixB.append(list(map(int, input().split())))
new_matrix = [[0] * (n - q + 1) for i in range(m - p + 1)]

def multiple_matrix(x,y,a,b):
    res = 0
    for i in range(x,x + p):
        for j in range(y,y + q):
            res += a[i][j] * b[i - x][j - y]
    return res

for i in range(m -p + 1):
    for j in range(n - q + 1):
        new_matrix[i][j] = multiple_matrix(i,j,matrixA,matrixB)

for _ in new_matrix:
    print(*_)