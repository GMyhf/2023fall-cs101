'''
2300015897
参考夏天明
'''
i = 0
def decode():
    global i
    res = []
    while i < len(string):
        chr = string[i]
        i += 1
        if chr == "[":
            num = []
            while string[i] in "0123456789":
                num.append(string[i])
                i += 1
            res.extend(int(''.join(num)) * decode())
        elif chr == "]":
            return res
        else:
            res.append(chr)
    return res

string = input()
print(''.join(decode()))