'''
2300015897
'''
from heapq import heappop,heappush

n = int(input())
info = [list(map(int,input().split())) + [i] for i in range(n)]
info.sort()

column = []
res = [1]*n
cnt = 1
heappush(column,[info[0][1],1])

for i in range(1,n):
    end,pos = heappop(column)
    if info[i][0] > end:
        res[info[i][2]] = pos
        heappush(column,[info[i][1],pos])
    else:
        heappush(column,[end,pos])
        cnt += 1
        res[info[i][2]] = cnt
        heappush(column,[info[i][1],cnt])
print(len(column))
for i in range(n):
    print(res[i])
