'''
2300015897
'''
n = int(input())
info = [[float('-inf'),float('-inf')]]
for i in range(n):
    m,d = map(int,input().split())
    info.append([m,d])
info.append([float("inf"),0])
cnt = 0
end = float('-inf')
for i in range(1,n + 1):
    if end < info[i][0] - info[i][1] and info[i - 1][0] < info[i][0] - info[i][1] and info[i + 1][0] > info[i][0] + info[i][1]:
        end = info[i][0] + info[i][1]
        cnt += 1
print(cnt)