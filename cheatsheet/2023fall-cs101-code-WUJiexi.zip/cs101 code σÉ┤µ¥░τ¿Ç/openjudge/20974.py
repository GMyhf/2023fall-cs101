'''
2300015897
'''
m,s,c = map(int,input().split())
pos = [int(input()) for i in range(c)]
pos.sort()
res = s
res -= (pos[0] - 1 + s - pos[-1])
gaps = []
for i in range(1,c):
    gap = pos[i] - pos[i - 1] - 1
    if gap != 0:
        gaps.append(gap)
gaps.sort(reverse = True)
l = len(gaps)
if l >= m - 1:
    for i in range(m - 1):
        res -= gaps[i]
else:
    res -= sum(gaps)
print(res)