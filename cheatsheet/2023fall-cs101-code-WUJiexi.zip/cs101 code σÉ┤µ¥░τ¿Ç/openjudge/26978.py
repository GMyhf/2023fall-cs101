'''
2300015897
吴杰稀
光华管理学院
'''
length,window = map(int,input().split())
num_list = list(map(int,input().split()))
start,end = - length,- window
res = []
for i in range(start,end + 1):
    if i + window == 0:
        t = max(num_list[-3:])
    else:
        t = max(num_list[i:i + window])
    res.append(t)
print(*res)