'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
matrix = []
t = n ** 2
for i in range(n):
    matrix.append(list(map(int,input().split())))
ans = ""
visit_list = [[1] * (n + 2) for i in range(n + 2)]
for i in range(n):
    for j in range(n):
        visit_list[i + 1][j + 1] = 0
times = 0
x,y = 0,0
move = [[0,1],[1,0],[0,-1],[-1,0]]
k = 0
visit_list[1][1] = 1
ans += str(matrix[0][0])
while True:
    x += move[k][0]
    y += move[k][1]
    if not visit_list[x + 1][y + 1]:
        ans += str(matrix[x][y])
        visit_list[x + 1][y + 1] = 1
    else:
        x -= move[k][0]
        y -= move[k][1]
        k += 1
        k = k % 4
        x += move[k][0]
        y += move[k][1]
        ans += str(matrix[x][y])
        visit_list[x + 1][y + 1] = 1
    times += 1
    if times == t - 1:
        break
print(ans)