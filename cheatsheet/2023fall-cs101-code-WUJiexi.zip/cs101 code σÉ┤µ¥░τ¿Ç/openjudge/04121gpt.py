def maxProfit(n, prices):
    # 初始化四个状态
    buy1 = buy2 = float('-inf')
    sell1 = sell2 = 0

    # 对每一天的价格进行遍历
    for price in prices:
        # 如果今天的价格更低，就在今天第一次买入
        buy1 = max(buy1, -price)
        # 如果今天卖出的利润更高，就在今天第一次卖出
        sell1 = max(sell1, buy1 + price)
        # 如果用第一次卖出的利润减去今天的价格，可以购买的股票更多，就在今天第二次买入
        buy2 = max(buy2, sell1 - price)
        # 如果今天第二次卖出的利润更高，就在今天第二次卖出
        sell2 = max(sell2, buy2 + price)

    return sell2


T = int(input().strip())
for _ in range(T):
    N = int(input().strip())
    prices = list(map(int, input().strip().split()))
    print(maxProfit(N, prices))