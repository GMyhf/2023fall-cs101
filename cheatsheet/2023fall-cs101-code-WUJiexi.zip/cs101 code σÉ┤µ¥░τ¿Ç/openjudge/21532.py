'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
i = 6
while i <= n:
    if n % i == 0:
        print(n // i)
        break
    i += 1
