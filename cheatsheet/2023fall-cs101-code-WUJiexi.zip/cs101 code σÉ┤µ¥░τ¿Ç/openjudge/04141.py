'''
2300015897
'''
a,b,c,d,e,f = map(int,input().split())
res = [0]*1001
for i in range(a + 1):
    for j in range(b + 1):
        for k in range(c + 1):
            for l in range(d + 1):
                for m in range(e + 1):
                    for n in range(f + 1):
                        t = i + 2 * j + 3 * k + 5 * l + 10 * m + 20 * n
                        res[t] = 1

ans = 0
for i in range(1,1001):
    ans += res[i]
print(f"Total={ans}")