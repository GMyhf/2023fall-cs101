'''
2300015897
'''
dx = [1,2,2,1,-1,-2,-2,-1]
dy = [2,1,-1,-2,-2,-1,1,2]
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and not in_queue[x][y]:
        return True
    return False
cnt = 0
def dfs(x,y,step):
    global cnt
    if step == m*n - 1:
        cnt += 1
        return

    for i in range(8):
        nx = x + dx[i]
        ny = y + dy[i]
        if is_valid(nx,ny):
            in_queue[x][y] = True
            dfs(nx,ny,step + 1)
            in_queue[x][y] = False

cases = int(input())
for i in range(cases):
    n,m,x,y = map(int,input().split())
    in_queue = [[False]*m for i in range(n)]
    cnt = 0
    dfs(x,y,0)
    print(cnt)