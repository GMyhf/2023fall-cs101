'''
2300015897
吴杰稀
光华管理学院
'''
results=[]
def perfect_cubic(n):
    for a in range(3,n+1):
        for i in range(2,int(((a**3)/3)**(1/3))+1):
            b = i
            remain_1 = a**3 - b**3
            for j in range(b,int((remain_1/2)**(1/3)) + 1):
                c=j
                remain_2 = a**3 - b**3 - c**3
                if int(remain_2**(1/3))**3 == remain_2:
                    d = int(remain_2**(1/3))
                    results.append([a, b, c, d])
                elif (int(remain_2**(1/3)) + 1)**3 == remain_2:
                    d = int(remain_2**(1/3)) + 1
                    results.append([a,b,c,d])
    return results

n=int(input())
list = perfect_cubic(n)
for _ in list:
    print(f"Cube = {_[0]}, Triple = ({_[1]},{_[2]},{_[3]})")