'''
2300015897
吴杰稀
光华管理学院
'''
k = 1
while True:
    p,e,i,d = map(int,input().split())
    if p == -1:
        break
    p %= 23
    e %= 28
    i %= 33
    j = d + 1
    while True:
        if j % 23 == p and j % 28 == e and j % 33 == i:
            print("Case " + str(k) + ": the next triple peak occurs in " + str(j - d) + " days.")
            break
        j += 1
    k += 1