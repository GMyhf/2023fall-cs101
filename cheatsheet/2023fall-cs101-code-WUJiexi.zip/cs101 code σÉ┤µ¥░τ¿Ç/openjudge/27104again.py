'''
2300015897
'''
n = int(input())
info = [int(x) for x in input().split()]
l = []
for i in range(n):
    r = info[i]
    l.append((i - r,i + r))
l.sort(key = lambda x:x[0])
s,e = 0,n - 1
end = -1
cnt = 0
for i in range(n):
    if l[i][1] > end:


