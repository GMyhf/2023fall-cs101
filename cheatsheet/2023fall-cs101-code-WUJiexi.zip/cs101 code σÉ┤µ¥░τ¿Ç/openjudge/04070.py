'''
2300015897
吴杰稀
光华管理学院
'''
def dfs_permutation(step):
    if step == n + 1:
        for i in range(1,n + 1):
            print(a[i],end = ' ')
        print()
        return

    for i in range(1,n + 1):
        if book[i] == 0:
            a[step] = i
            book[i] = 1
            dfs_permutation(step + 1)
            book[i] = 0


while True:
    n = int(input())
    if n == 0:
        break
    a = [0] * (n + 1)
    book = [0] * (n + 1)
    dfs_permutation(1)
