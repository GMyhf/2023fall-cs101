'''
2300015897
吴杰稀
光华管理学院
'''
#枚举法
cases = int(input())
coins = 'ABCDEFGHIJKL'
ans = ['heavy','light']
for i in range(cases):
    tests = []
    for i in range(3):
        tests.append(list(map(str,input().split())))
    for coin in coins:
        for answer in ans:
            flag = 1
            for test in tests:
                left = test[0]
                right = test[1]
                result = test[2]
                if coin in left:
                    if answer == "heavy":
                        should_be = 'up'
                    else:
                        should_be = 'down'
                elif coin in right:
                    if answer == 'heavy':
                        should_be = 'down'
                    else:
                        should_be = 'up'
                else:
                    should_be = "even"
                if should_be != result:
                    flag = 0
                    break
            if flag == 1:
                print(f"{coin} is the counterfeit coin and it is {answer}.")
                break




