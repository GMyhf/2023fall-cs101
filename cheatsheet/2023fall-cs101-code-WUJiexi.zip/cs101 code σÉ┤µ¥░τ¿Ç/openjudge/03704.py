'''
2300015897
'''
while True:
    try:
        string = input()
        res = [' ']*len(string)
        stack = []
        for i in range(len(string)):
            if string[i] == "(":
                stack.append(i)
            if string[i] == ")":
                if stack:
                    stack.pop()
                else:
                    res[i] = '?'
        for _ in stack:
            res[_] = "$"
        print(string)
        print(''.join(res))
    except:
        break