
import math
def p(m) :
    h=int (math.log (m, 2))
    summi=0
    for i in range(1,h+1) :
        summi+=m/(2**i)
    return summi
while True :
    try:
        x=input ()
        n, k=map (int, x.split () )
        if n>k:
            n, k=n,n-k
        if n==k:
            print(1)
        elif n==1 or k==0:
            print(1)
        elif n%2==0 and k%2==1:
            print(0)
        else:
            if p(n)==p(k) +p(n-k) :
                print(1)
            else :
                print(0)
    except:
        break
