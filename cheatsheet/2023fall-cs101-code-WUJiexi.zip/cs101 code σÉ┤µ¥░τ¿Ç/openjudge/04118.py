'''
2300015897
'''
cases = int(input())
for i in range(cases):
    n,k = map(int,input().split())
    pos = [int(x) for x in input().split()]
    value = [int(x) for x in input().split()]
    dp = [0]*(pos[-1] + 1)
    j = 0
    for i in range(1,len(dp)):
        if i == pos[j]:
            dp[i] = max(dp[max(0,i - k - 1)] + value[j],dp[i - 1])
            j += 1
        else:
            dp[i] = dp[i - 1]
    print(dp[-1])