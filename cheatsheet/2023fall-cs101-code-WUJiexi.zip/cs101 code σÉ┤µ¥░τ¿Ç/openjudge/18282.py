'''
2300015897
光华管理学院
'''
cases = int(input())
for i in range(cases):
    n,m,p = map(int,input().split())
