'''
2300015897
吴杰稀
光华管理学院
'''
dp = [0] * 1000001
dp[1] = 1
dp[2] = 2
for i in range(3,1000001):
    dp[i] = (2 * dp[i - 1] + dp[i - 2]) % 32767
cases = int(input())
for i in range(cases):
    t = int(input())
    print(dp[t])