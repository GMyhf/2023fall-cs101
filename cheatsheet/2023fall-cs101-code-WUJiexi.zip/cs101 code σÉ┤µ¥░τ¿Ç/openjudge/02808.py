L,M=map(int,input().split())
total_list=[]
for i in range(M):
    start,end=map(int,input().split())
    list=[]
    for j in range(start,end+1):
        list.append(j)
    iset=set(list)
    total_list.append(iset)
new_set=total_list.pop() 
for i in range(M-1):
    poped_set=total_list.pop()
    new_set=new_set|poped_set
print(L+1-len(new_set))