'''
2300015897
'''
l = int(input())
s = input()
def palin(string):
    s1 = string
    s2 = string[::-1]
    dp1 = [0]*(l + 1)
    for i in range(1,l + 1):
        dp2 = [0]*(l + 1)
        for j in range(1,l + 1):
            if s1[i - 1] == s2[j - 1]:
                dp2[j] = dp1[j - 1] + 1
            else:
                dp2[j] = max(dp1[j],dp2[j - 1])
        dp1 = dp2.copy()
    return dp1[-1]
print(l - palin(s))