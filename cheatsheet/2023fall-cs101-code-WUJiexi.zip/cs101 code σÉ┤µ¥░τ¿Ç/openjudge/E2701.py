'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
num_list = [i for i in range(1,n+1)]
new_list = []
sum = 0
for _ in num_list:
    if _ % 7 == 0:
        _ = 0
    elif _ //10 == 7:
        _ = 0
    elif _ % 10 == 7:
        _ = 0
    new_list.append(_)
for i in new_list:
    sum += i**2
print(sum)