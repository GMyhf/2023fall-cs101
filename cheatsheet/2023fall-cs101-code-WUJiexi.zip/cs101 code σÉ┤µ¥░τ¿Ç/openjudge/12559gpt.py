n = int(input())
numbers = input().split()

# 定义比较函数，将字符串按照ab > ba的规则进行排序
def compare(a, b):
    if a + b > b + a:
        return -1
    elif a + b < b + a:
        return 1
    else:
        return 0

# 将numbers按照定义的比较函数进行排序
numbers.sort(key=lambda x: compare(str(x), ""))

# 将排序后的结果连接成字符串，并输出最大和最小整数
max_number = "".join(numbers)
min_number = "".join(numbers[::-1])
print(max_number, min_number)
