'''
2300015897
参考蒋子轩
'''
def change_date(x):
    t = x.split('.')
    m,d = int(t[0]),int(t[1])
    return 31*(m - 1) + d - 7
info = []
n = int(input())
for i in range(n):
    s,e,v = input().split()
    s = change_date(s)
    e = change_date(e)
    v = int(v)
    if s >= 0 and e <= 44:
        info.append((s,e,v))
info.sort()
dp = [0]*45
for i in range(1,46):
    dp[i - 1] = dp[i - 2]
    for start,end,value in info:
        if end == i - 1:
            dp[i - 1] = max(dp[i - 1],dp[start - 1] + value)
print(dp[-1])