def monkey_king(monkey_list,test):
    k=0
    if k >= len(monkey_list):
        k += -len(monkey_list)

    while len(monkey_list)>monkey_list.count(-1)+1:
        for i in range(test-1):
            while monkey_list[k]==-1:
                k+=1
                if k >= len(monkey_list):
                    k += -len(monkey_list)
            k+=1
        if k>=len(monkey_list):
            k+=-len(monkey_list)
        while monkey_list[k] == -1:
            k += 1
            if k>=len(monkey_list):
                k+=-len(monkey_list)
        monkey_list[k]=-1
        k+=1
        if k>=len(monkey_list):
            k+=-len(monkey_list)

    while monkey_list.count(-1):
        monkey_list.remove(-1)

    for king in monkey_list:
        print(king+1)

while 1:
    n,m=[int(x) for x in input().split()]
    if n==0 and m==0:
        break
    else:
        monkey_test=list(range(n))
        monkey_king(monkey_test,m)