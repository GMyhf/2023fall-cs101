'''
2300015897
'''
s = input().split()
stack = []
for i in range(len(s) - 1,-1,-1):
    if s[i] in "+-*/":
        a = stack.pop()
        b = stack.pop()
        if s[i] == "+":
            stack.append(a + b)
        elif s[i] == "-":
            stack.append(a - b)
        elif s[i] == "*":
            stack.append(a * b)
        elif s[i] == "/":
            stack.append(a / b)
    else:
        stack.append(float(s[i]))
print(f"{stack[-1]:.6f}")
