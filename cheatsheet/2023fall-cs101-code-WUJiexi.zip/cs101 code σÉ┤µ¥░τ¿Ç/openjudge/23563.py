'''
2300015897
光华管理学院
'''
res = 0
s = input().split("+")
for i in s:
    pos = i.find("^")
    if pos == -1:
        continue
    if pos != 1 and int(i[:pos - 1]) == 0:
        continue
    res = max(res,int(i[pos+1:]))
print(f"n^{res}")
