def candy(ratings):
    tg = [1] * n

    # 先从左往右遍历
    for i in range(1, n):
        if ratings[i] > ratings[i - 1]:
            tg[i] = tg[i - 1] + 1
    # 计算总的糖果数
    count = tg[-1]  # 初始值为最后一个孩子的糖果数
    # 从右往左遍历，同时累加总的糖果数
    for j in range(n - 2, -1, -1):
        if ratings[j] > ratings[j + 1]:
            tg[j] = max(tg[j], tg[j + 1] + 1)
        count += tg[j]
    return count

n = int(input())
rating = list(map(int,input().split()))
print(candy(rating))