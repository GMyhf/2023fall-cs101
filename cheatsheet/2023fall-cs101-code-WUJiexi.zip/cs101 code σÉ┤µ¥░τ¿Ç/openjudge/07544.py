'''
2300015897
吴杰稀
光华管理学院
'''
n,m,k = map(int,input().split())
matrixA = []
matrixB = []
matrixC = []
for i in range(n):
    row = list(map(int,input().split()))
    matrixA.append(row)
for j in range(m):
    row = list(map(int,input().split()))
    matrixB.append(row)
for i in range(n):
    row = []
    for j in range(k):
        t = 0
        for _ in range(m):
            t += matrixA[i][_]*matrixB[_][j]
        row.append(t)
    matrixC.append(row)

for _ in matrixC:
    print(' '.join(str(a) for a in _))