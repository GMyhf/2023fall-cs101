'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
price = [float(x) for x in input().split()]
l,r = [price[0]] * n,[price[-1]] * n
for i in range(n - 2,-1,-1):
    r[i] = max(r[i + 1],price[i])
ans = 1.00
for i in range(n):
    ans = max(ans,r[i]/price[i])
res = 100*ans
print(f"{res:.2f}")