'''
2300015897
吴杰稀
光华管理学院
'''
time,m = map(int,input().split())
herb = []
for i in range(m):
    herb.append(list(map(int,input().split())))

package = [[0] * (time + 1) for i in range(m + 1)]
for i in range(1,m + 1):
    for j in range(1,time + 1):
        if j >= herb[i - 1][0]:
            package[i][j] = max(package[i - 1][j],package[i - 1][j - herb[i - 1][0]] + herb[i - 1][1])
        else:
            package[i][j] = package[i - 1][j]
print(package[m][time])
