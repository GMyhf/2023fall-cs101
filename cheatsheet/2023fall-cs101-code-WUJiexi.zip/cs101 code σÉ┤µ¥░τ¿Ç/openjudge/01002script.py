n=int(input())

list=[]

num=[1,2,3,4,5,6,7,8,9,0]

#定义函数
def change(x):
    if x == "A" or "B" or "C":
        return "4"
    elif x == "D" or "E" or "F":
        return "3"
    elif x == "G" or "H" or "I":
        return "4"
    elif x == "J" or "K" or "L":
        return "5"
    elif x == "M" or "N" or "O":
        return "6"
    elif x == "P" or "R" or "S":
        return "7"
    elif x == "T" or "U" or "V":
        return "8"
    elif x == "W" or "X" or "Y":
        return "9"

#建立列表
for i in range(n):
    list.append(input())

new_list=[]

#遍历字符串并进行修改
for str in list:
    new_str=""
    for letter in str:
        if letter == "-":
            letter=False
        else:
            if letter in num:
                new_str+=letter
            else:
                letter=change(letter)
                new_str+=letter

    new_list.append(new_str)

new_list.sort()
print(new_list)
