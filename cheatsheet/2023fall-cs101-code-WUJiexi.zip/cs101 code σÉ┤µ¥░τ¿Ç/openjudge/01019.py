'''
2300015897
吴杰稀
光华管理学院
'''
import math
list = []
for i in range(1,50000):
    list.append(i*(i + 1)//2)
cases = int(input())
for i in range(cases):
    find_index = int(input())
    n = int(math.sqrt(2*find_index + 1/4))
    if 2*find_index == n**2 + n:
        print(find_index - list[n - 2])
    else:
        print(find_index - list[n - 1])