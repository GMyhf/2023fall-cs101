'''
2300015897
'''
def change(x,t):
    if x == 1:
        return 1
    cnt = 0
    for i in range(t,x + 1):
        if x % i == 0:
            cnt += change(x // i,i)
    return cnt

n = int(input())
for i in range(n):
    print(change(int(input()),2))


