'''
2300015897
'''
from collections import deque
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and maze[x][y] != 2:
        return True
    return False
step,flag = 0,0
dx,dy = [0,1,0,-1],[1,0,-1,0]

def bfs(x,y):
    global step,flag
    q = deque([(x,y)])
    while q:
        cnt = len(q)
        for i in range(cnt):
            front = q.popleft()
            for i in range(4):
                nx = front[0] + dx[i]
                ny = front[1] + dy[i]
                if not is_valid(nx,ny):
                    continue

                if maze[nx][ny] == 1:
                    flag = 1
                    step += 1
                    return

                maze[front[0]][front[1]] = 2
                q.append((nx,ny))
        step += 1

n,m = map(int,input().split())
maze = [[int(x) for x in input().split()] for i in range(n)]
if maze[0][0] == 1:
    print("0")
else:
    bfs(0,0)
    if flag == 1:
        print(step)
    else:
        print("NO")