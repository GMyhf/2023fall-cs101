'''
2300015897
'''
from collections import deque
dx,dy = [1,0,-1,0],[0,-1,0,1]

def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != "#":
        return True
    return False

def bfs(x,y):
    global area
    maze[x][y] = "#"
    area = 1
    q = deque([[x,y]])
    #print(q)
    while q:
        cnt = len(q)

        for i in range(cnt):
            front = q.popleft()
            #print(front)
            for j in range(4):
                nx = front[0] + dx[j]
                ny = front[1] + dy[j]

                if is_valid(nx,ny):
                    maze[nx][ny] = "#"
                    area += 1
                    q.append([nx,ny])

while True:
    n,m = map(int,input().split()) #n是列，m是行
    if n == 0 and m == 0:
        break
    maze = [[x for x in input()] for i in range(m)]
    s,t = 0,0
    for i in range(m):
        for j in range(n):
            if maze[i][j] == "@":
                s,t = i,j
                break
    bfs(s,t)
    print(area)