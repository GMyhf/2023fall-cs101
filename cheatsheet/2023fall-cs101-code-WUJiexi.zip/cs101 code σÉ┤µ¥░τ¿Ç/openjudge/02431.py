'''
2300015897
'''
import heapq
n = int(input())
stop = []
for i in range(n):
    pos,fuel = map(int,input().split())
    stop.append((pos,fuel))
l,p = map(int,input().split())
stop.append((0,0))
stop.sort(reverse = True)
cur = p
now = l
cnt = 0
que = []
for i in range(n + 1):
    di = now - stop[i][0]
    while cur < di:
        if not que:
            print(-1)
            exit()
        cur -= heapq.heappop(que)
        cnt += 1
    cur -= di
    now = stop[i][0]
    heapq.heappush(que,-stop[i][1])
print(cnt)