'''
2300015897
吴杰稀
光华管理学院
'''
dx = [1,0,-1,0]
dy = [0,1,0,-1]
k = 0
n = int(input())
x,y = 0,0
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < n and matrix[x][y] != -1:
        return True
    return False

matrix = [[int(x) for x in input().split()] for i in range(n)]
ans = ''
for i in range(n * n):
    if matrix[x][y] == 0:
        break
    nx = x + dx[k]
    ny = y + dy[k]
    ans += chr(matrix[x][y])
    matrix[x][y] = -1
    if is_valid(nx,ny):
        x,y = nx,ny
    if not is_valid(nx,ny):
        k = (k + 1) % 4
        nx = x + dx[k]
        ny = y + dy[k]
        x,y = nx,ny
print(ans)