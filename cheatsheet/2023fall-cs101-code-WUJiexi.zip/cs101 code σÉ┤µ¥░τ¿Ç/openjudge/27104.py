'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
arr = [int(x) for x in input().split()]
lst = []
for i in range(n) :
    lst.append([i-arr[i]-0.5,i+arr[i]+0.5])
lst.sort(key=lambda x:x[0])
cnt = ans = mx = l = 0
while l < n - 1:
    mx = 0
    while cnt < n and lst[cnt][0] <= l:
        mx = max(mx,lst[cnt][1])
        cnt += 1
    ans += 1
    l = mx
print(ans)