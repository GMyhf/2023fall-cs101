'''
2300015897
'''
import math
primes = []
is_prime = [True] * (10000 + 1)
for i in range(2, 10000 + 1):
    if is_prime[i]:
        primes.append(i)
    for j in range(len(primes)):
        if i * primes[j] > 10000:
            break
        is_prime[i * primes[j]] = False
        if i % primes[j] == 0:
            break
primes = set(primes)
n,m = map(int,input().split())
for i in range(n):
    grade = [int(x) for x in input().split()]
    valid = 0
    for _ in grade:
        if math.sqrt(_) in primes:
            valid += _
    if valid == 0:
        print(0)
    else:
        res = valid / len(grade)
        print(f"{res:.2f}")
