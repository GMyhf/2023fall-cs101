'''
2300015897
吴杰稀
光华管理学院
'''
length = int(input())
sequence = list(map(int,input().split()))
t = max(sequence)
num_list = [0] * (t + 1)
for _ in sequence:
    num_list[_] = 1

def find(x):
    if x > t:
        return t
    if num_list[x] == 1:
        return x
    i,j = 0,0
    flag_i,flag_j = 0,0
    for i in range(1,x + 1):
        if num_list[x - i] == 1:
            flag_i = 1
            break
    for j in range(1,t - x + 1):
        if num_list[x + j] == 1:
            flag_j = 1
            break
    if flag_i == 0:
        return x + j
    elif flag_j == 0:
        return x - i
    else:
        if i == j:
            return x - i
        elif i > j:
            return x + j
        elif i < j:
            return x - i

cases = int(input())
for i in range(cases):
    res = find(int(input()))
    print(res)
