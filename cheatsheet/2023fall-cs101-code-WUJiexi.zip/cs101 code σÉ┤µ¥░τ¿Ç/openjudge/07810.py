'''
2300015897
'''
n = int(input())
def exam(x):
    if x % 19 == 0:
        return "Yes"
    if '19' in str(x):
        return "Yes"
    return "No"
for i in range(n):
    print(exam(int(input())))