n=int(input())

list=[]

num=["1","2","3","4","5","6","7","8","9","0"]

#定义函数
def change(x):
    if x in ["A","B","C"]:
        return "2"
    elif x in ["D","E","F"]:
        return "3"
    elif x in ["G","H","I"]:
        return "4"
    elif x in ["J","K","L"]:
        return "5"
    elif x in ["M","N","O"]:
        return "6"
    elif x in ["P","S","R"]:
        return "7"
    elif x in ["V","T","U"]:
        return "8"
    elif x in ["Y","W","X"]:
        return "9"

#建立列表
for i in range(n):
    list.append(input())

new_list=[]

#遍历字符串并进行修改
for str in list:
    new_str=""
    for letter in str:
        if letter == "-":
            letter=False
        elif letter in num:
            new_str+=letter
        else:
            letter=change(letter)
            new_str+=f"{letter}"

    new_list.append(new_str)

new_list.sort()

set=set(new_list)

if len(set)==n:
    print("No duplicates.")

phone_dict={}

for number in new_list:
    if number not in phone_dict:
        phone_dict[number]=1
    else:
        phone_dict[number]+=1
        
for number,key in phone_dict.items():
    if key>1:
        print(f"{number[0:3]}"+"-"+f"{number[3:]}"+f" {key}")
    
