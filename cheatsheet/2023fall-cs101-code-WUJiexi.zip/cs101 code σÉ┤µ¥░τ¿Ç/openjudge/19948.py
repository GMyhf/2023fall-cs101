'''
2300015897
吴杰稀
光华管理学院
'''
n,m = map(int,input().split())
student = list(map(int,input().split()))
student.sort()
difference = [0] * (n - 1)
for i in range(n - 1):
    difference[i] = student[i + 1] - student[i]
difference.sort(reverse = True)
max_num = student[-1] - student[0]
if m == 1:
    print(max_num)
else:
    blank = sum(difference[:(m - 1)])
    print(max_num - blank)