'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
altitude = list(map(int,input().split()))
dp_down = [1] * n
altitude.reverse()
for i in range(1,n):
    for j in range(i):
        if altitude[j] <= altitude[i]:
            dp_down[i] = max(dp_down[i],1 + dp_down[j])
print(max(dp_down))