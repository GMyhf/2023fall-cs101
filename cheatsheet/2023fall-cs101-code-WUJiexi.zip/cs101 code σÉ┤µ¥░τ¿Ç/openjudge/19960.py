'''
2300015897
'''
def change(num):
    for i in range(1,7):
        num[i][0] = (num[i][0] + 1) % 6
        num[i][1] = (num[i][1] + 1) % 6
        for j in range(2):
            if num[i][j] == 0:
                num[i][j] = 6
    num.sort()
    return num
def change_letter(x):
    if x == "a":
        return 1
    if x == "b":
        return 2
    if x == "c":
        return 3
    if x == "d":
        return 4
    if x == "e":
        return 5
    if x == "f":
        return 6
def change_num(x):
    if x == 1:
        return "a"
    if x == 2:
        return "b"
    if x == 3:
        return "c"
    if x == 4:
        return "d"
    if x == 5:
        return "e"
    if x == 6:
        return "f"
l = sorted([list(map(int,input().split())) for i in range(6)] + [[0,0]])
m = sorted([list(map(int,input().split())) for i in range(6)] + [[0,0]])
r = sorted([list(map(int,input().split())) for i in range(6)] + [[0,0]])
reflect = [[0,0]]
for i in range(3):
    a,b = map(int,input().split())
    reflect.extend([[a,b],[b,a]])
reflect.sort()
string = input()

cntl,cntm,cntr = 0,0,0
res = ''
for i in range(len(string)):
    if cntl == 6:
        m = change(m)
        cntm += 1
        cntl = 0
    if cntm == 6:
        r = change(r)
        cntm = 0
    step1 = l[change_letter(string[i])][1]
    step2 = m[step1][1]
    step3 = r[step2][1]
    step4 = reflect[step3][1]
    for i in range(1,7):
        if r[i][1] == step4:
            step5 = r[i][0]
            break
    for i in range(1, 7):
        if m[i][1] == step5:
            step6 = m[i][0]
            break
    for i in range(1, 7):
        if l[i][1] == step6:
            step7 = l[i][0]
            break
    res += change_num(step7)
    cntl += 1
    l = change(l)
print(res)