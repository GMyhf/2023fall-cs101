def calculate_max_ability(N, a, b, c):
    dp = [[0, 0, 0] for _ in range(N+1)]  # 创建一个二维数组用于存储最大能力值和

    dp[1][0] = a[0]  # 第一个同学坐在第一个机位上只能获得a值

    for i in range(2, N+1):
        dp[i][0] = max(dp[i-1][0] + a[i-1], dp[i-1][1] + a[i-1], dp[i-1][2] + a[i-1])  # 当前同学坐在机位i上只能获得a值
        dp[i][1] = max(dp[i-1][0] + b[i-1], dp[i-1][1] + b[i-1])  # 当前同学坐在机位i上只能获得b值
        dp[i][2] = max(dp[i-1][1] + c[i-1], dp[i-1][2] + c[i-1])  # 当前同学坐在机位i上只能获得c值

    max_ability = max(dp[N][0], dp[N][1], dp[N][2])
    return max_ability

# 输入机位数N
N = int(input())

# 输入a值、b值和c值
a = list(map(int, input().split()))
b = list(map(int, input().split()))
c = list(map(int, input().split()))

max_ability = calculate_max_ability(N, a, b, c)
print(max_ability)