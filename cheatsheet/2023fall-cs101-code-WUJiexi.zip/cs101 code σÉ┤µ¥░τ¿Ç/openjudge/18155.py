'''
2300015897
'''
def dfs(x):
    for num in s:
        if num > x or x % num != 0 or num in v:
            continue
        elif num == x:
            return True
        else:
            v.add(num)
            if dfs(x // num):
                return True
            v.discard(num)
    return False
t = int(input())
s = [int(x) for x in input().split()]
v = set()
print("YES" if dfs(t) else "NO")