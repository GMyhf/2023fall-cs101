'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
x_list,y_list = [],[]
for i in range(cases):
    x,y = map(int,input().split())
    x_list.append(x)
    y_list.append(y)
res = sum(x_list) + min(y_list)
print(res)