'''
2300015897
'''
def is_valid(x,y):
    if 0 <= x < 5 and 0 <= y < 6:
        return True
    return False

dx = [0,0,1,0,-1]
dy = [0,1,0,-1,0]
def push(x,y,t):
    for i in range(5):
        nx = x + dx[i]
        ny = y + dy[i]
        if is_valid(nx,ny):
            t[nx][ny] = (t[nx][ny] + 1) % 2

lamp = [[int(x) for x in input().split()] for i in range(5)]

def change():
    global ans
    for a in range(2):
        for b in range(2):
            for c in range(2):
                for d in range(2):
                    for e in range(2):
                        for f in range(2):
                            ans = [[0] * 6 for _ in range(5)]
                            lamp_copy = [x.copy() for x in lamp]
                            if a:
                                ans[0][0] = 1
                                push(0, 0,lamp_copy)
                            if b:
                                ans[0][1] = 1
                                push(0, 1,lamp_copy)
                            if c:
                                ans[0][2] = 1
                                push(0, 2,lamp_copy)
                            if d:
                                ans[0][3] = 1
                                push(0, 3,lamp_copy)
                            if e:
                                ans[0][4] = 1
                                push(0, 4,lamp_copy)
                            if f:
                                ans[0][5] = 1
                                push(0, 5,lamp_copy)

                            for i in range(1,5):
                                for j in range(6):
                                    if lamp_copy[i - 1][j] == 1:
                                        ans[i][j] += 1
                                        push(i,j,lamp_copy)

                            if sum(lamp_copy[-1]) == 0:
                                return ans
change()
for _ in ans:
    print(*_)