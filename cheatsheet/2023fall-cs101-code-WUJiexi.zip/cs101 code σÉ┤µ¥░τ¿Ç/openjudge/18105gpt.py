'''
2300015897
'''
def hIndex(citations):
    citations.sort(reverse=True)
    n = len(citations)
    h = 0
    for i in range(n):
        if citations[i] >= i + 1:
            h = i + 1
        else:
            break
    return h

citations = [int(x) for x in input().split()]
h_index = hIndex(citations)
print(h_index)