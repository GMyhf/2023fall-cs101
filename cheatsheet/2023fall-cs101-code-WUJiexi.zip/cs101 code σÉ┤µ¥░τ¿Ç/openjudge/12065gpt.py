def f(x):
    return x**3 - 5*x**2 + 10*x - 80

def find_root(a, b, tolerance=1e-9):
    while abs(b - a) > tolerance:
        c = (a + b) / 2
        if f(c) == 0:
            return c
        elif f(c) * f(a) < 0:
            b = c
        else:
            a = c
    return (a + b) / 2

# 调用函数并打印结果
root = find_root(-10, 10)
print(round(root, 9))
