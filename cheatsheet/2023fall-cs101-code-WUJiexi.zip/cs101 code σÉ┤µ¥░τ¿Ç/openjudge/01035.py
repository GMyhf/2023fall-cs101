'''
2300015897
吴杰稀
光华管理学院
'''
model_dict = {}
search_list = []
while True:
    n = input()
    if n == "#":
        break
    model_dict[n] = len(n)

while True:
    s = input()
    if s == "#":
        break
    search_list.append(s)

for keys in search_list:
    candidate=[]
    if keys in model_dict:
        print(f"{keys} is correct")
    else:
        for m_keys,m_values in model_dict.items():
            if m_values == len(keys):
                sum=0
                for i in range(len(keys)):
                    if keys[i] != m_keys[i]:
                        sum += 1
                if sum == 1:
                    candidate.append(m_keys)
            elif m_values == len(keys) - 1:
                if keys[:-1] == m_keys:
                    candidate.append(m_keys)
                else:
                    i=-1
                    while True:
                        i += 1
                        if keys[i] != m_keys[i]:
                            novel_keys = keys[:i] + keys[i+1:]
                            if m_keys == novel_keys:
                                candidate.append(m_keys)
                            break
            elif m_values == len(keys) + 1:
                if m_keys[:-1] == keys:
                    candidate.append(m_keys)
                else:
                    i = -1
                    while True:
                        i += 1
                        if keys[i] != m_keys[i]:
                            new_keys = m_keys[:i] + m_keys[i + 1:]
                            if keys == new_keys:
                                candidate.append(m_keys)
                            break
        result=" ".join(candidate)
        print(f"{keys}: {result}")
#注意：每给一行数据输出一次