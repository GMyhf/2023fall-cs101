'''
2300015897
吴杰稀
光华管理学院
'''
def quzheng(y,a):
    return y // a

def zeller(x):
    c = int(x[:2])
    y = int(x[2:4])
    m = int(x[4:6])
    d = int(x[-2:])
    if m == 1 or m == 2:
        if y == 0:
            c -= 1
            y = 99
            m += 12
        else:
            m += 12
            y -= 1
    add_up = 0
    add_up += y
    add_up += quzheng(y,4)
    add_up += quzheng(c,4)
    add_up -= 2*c
    add_up +=quzheng(26*(m+1),10)
    add_up += d
    add_up -= 1
    return add_up

week_list = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
cases = int(input())
for i in range(cases):
    date = input()
    print(week_list[zeller(date)%7])