'''
2300015897
'''
n = int(input())
line = [int(x) for x in input().split()]
