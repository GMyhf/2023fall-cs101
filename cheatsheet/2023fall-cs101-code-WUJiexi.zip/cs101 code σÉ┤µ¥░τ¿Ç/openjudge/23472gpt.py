def is_palindrome(s):
    return s == s[::-1]

def find_palindrome_dates(target_date):
    result = []
    year = int(target_date[:4])
    month = int(target_date[4:6])
    day = int(target_date[6:8])

    current_date = 10000101
    while current_date <= int(target_date):
        date_str = str(current_date)
        if len(date_str) < 8:
            date_str = '0' * (8 - len(date_str)) + date_str  # 补齐位数
        if date_str[4:6] <= '12' and date_str[6:8] <= '31':  # 确保月份和日期的合法性
            if is_palindrome(date_str):
                result.append(date_str)
        year = int(date_str[:4])
        month = int(date_str[4:6])
        day = int(date_str[6:8])
        if month == 12 and day == 31:
            year += 1
            month = 1
            day = 1
        elif day == 31:
            month += 1
            day = 1
        else:
            day += 1
        current_date = year * 10000 + month * 100 + day

    return result

# 测试
target_date = input()
palindrome_dates = find_palindrome_dates(target_date)
print(' '.join(palindrome_dates))