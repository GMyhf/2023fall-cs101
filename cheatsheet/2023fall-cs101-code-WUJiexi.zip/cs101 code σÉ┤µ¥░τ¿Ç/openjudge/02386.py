'''
2300015897
'''
from collections import deque

dx = [-1,0,1,-1,1,-1,0,1]
dy = [1,1,1,0,0,-1,-1,-1]

def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and lake[x][y] == "W":
        return True
    return False

def bfs(x,y):
    q = deque([(x,y)])
    while q:
        t = len(q)
        for i in range(t):
            front = q.popleft()
            for i in range(8):
                nx = front[0] + dx[i]
                ny = front[1] + dy[i]
                if is_valid(nx,ny):
                    q.append((nx,ny))
                    lake[nx][ny] = "."

n,m = map(int,input().split())
lake = [[x for x in input()] for i in range(n)]
cnt = 0
for i in range(n):
    for j in range(m):
        if lake[i][j] == "W":
            lake[i][j] = "."
            bfs(i,j)
            cnt += 1
print(cnt)