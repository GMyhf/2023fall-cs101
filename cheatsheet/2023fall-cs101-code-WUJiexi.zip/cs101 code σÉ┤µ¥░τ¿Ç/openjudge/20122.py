'''
2300015897
吴杰稀
光华管理学院
'''
cases,date = map(int,input().split())
company = []
for i in range(cases):
    dates = list(map(int,input().split()))
    dates.append(date)
    dates.sort(reverse = True)
    company.append(dates)
for _ in company:
    t = _.index(date)
    if t == 0:
        print("3")
    elif t == 1:
        print("2")
    elif t == 2:
        print("1")
    elif t == 3:
        print("-4")
    elif t == 4:
        print("-3")


