'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
max = int( (3*n)//5 )
t = 3*n - 5*max
if t == 4:
    print(5*max)
elif t == 3:
        print(5*max)
elif t == 2:
        print(5*max)
elif t == 1:
    if (2*n-1)%3 == 0:
        print(5*max)
    else:
        print(5*(max-1))
else:
    if (2*n)%3 == 0:
        print(5*max)
    else:
        print(5*(max-1))