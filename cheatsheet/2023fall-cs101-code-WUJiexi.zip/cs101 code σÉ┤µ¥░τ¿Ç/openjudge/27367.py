'''
2300015897
'''
n,m = map(int,input().split())
info = []
for i in range(n):
    inform = [int(x) for x in input().split()]
    up = 0
    cnt = 0
    for i in range(1,m + 1):
        if inform[i] >= 90:
            cnt += 1
        if i >= 2:
            if inform[i] > inform[i - 1]:
                up += inform[i] - inform[i - 1]
    info.append([-cnt,-up,inform[0]])
info.sort()
for _ in info:
    print(_[-1])