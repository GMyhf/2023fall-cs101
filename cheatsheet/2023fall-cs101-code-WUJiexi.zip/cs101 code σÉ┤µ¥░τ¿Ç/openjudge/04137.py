'''
2300015897
'''
n = int(input())
for i in range(n):
    string,k = input().split()
    s = []
    k = int(k)
    q = [0,0,0,0,0,0,0,0,0]
    for _ in string:
        q[int(_) - 1] += 1
        s.append(int(_))
    t = 0
    j = -1
    while t < k:
        if q[j] != 0:
            for i in range(len(string)):
                if s[i] == 10 + j:
                    q[j] -= 1
                    s[i] = 0
                    t += 1
                    j = -1
                    break
        j -= 1
    res = ''
    for _ in s:
        if _ != 0:
            res += str(_)
    print(res)