'''
2300015897
吴杰稀
光华管理学院
'''
l, n, m = map(int, input().split())
rock = [0]
for i in range(n):
    rock.append(int(input()))
rock += [l]
l, r = 0, l
mid = (l + r) // 2

while l <= r:
    check_point = 0
    remove = 0

    for i in range(1, n + 2):
        if rock[i] - check_point < mid:
            remove += 1
        else:
            check_point = rock[i]

    if remove <= m:
        l = mid + 1

    else:
        r = mid - 1

    mid = (l + r) // 2

print(mid)