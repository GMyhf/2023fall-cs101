t = int(input())
num_list = [int(x) for x in input().split()]
num_list.sort()
l,r = 0,len(num_list) - 1
ans = 200000
gap = 100000 - 2
while l < r:
    check = num_list[l] + num_list[r]
    if check == t:
        ans = check
        break
    if abs(check - t) < gap:
        ans = check
        gap = abs(check - t)
    elif abs(check - t) == gap:
        ans = min(ans,check)
    if check > t:
        r -= 1
    elif check < t:
        l += 1
print(ans)