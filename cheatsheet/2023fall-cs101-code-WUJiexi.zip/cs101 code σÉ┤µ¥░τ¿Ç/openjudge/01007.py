#输入字符串长度及字符串数量
n,m=map(int,input().split())

#输入DNA序列
list=[]
for _ in range(m):
    list.append(input())

#计算逆序数
dict={}
for x in range(m):

    reverse_num=0

    for i in range(1,n):
        for j in range(i+1,n+1):
            if list[x][i-1]>list[x][j-1]:
                reverse_num+=1

    dict[list[x]]=reverse_num

#定义函数
def change(a,b):
    if dict[a]>dict[b]:
        a,b=b,a
    return a,b

#执行函数
for w in range(m):
    for v in range(w+1,m):
        list[w],list[v]=change(list[w],list[v])

#输出
for u in range(m):
    print(list[u])