def calculate_max_activities(n, activities):
    activities.sort(key=lambda x: x[1])  # Sort activities by end time
    max_activities = 0
    end_time = -1

    for activity in activities:
        start_time, finish_time = activity
        if start_time > end_time:
            max_activities += 1
            end_time = finish_time

    return max_activities

# Example usage
n = int(input())
activities = []
for _ in range(n):
    start_time, end_time = map(int, input().split())
    activities.append((start_time, end_time))
max_activities = calculate_max_activities(n, activities)
print(max_activities)