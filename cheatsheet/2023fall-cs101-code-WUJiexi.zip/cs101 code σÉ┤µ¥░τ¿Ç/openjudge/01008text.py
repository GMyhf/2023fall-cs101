n=int(input())

#建立列表
def month_convert(x):
    if x=='pop':
        month=1
    elif x == 'no':
        month=2
    elif x == 'zip':
        month = 3
    elif x == 'zotz':
        month=4
    elif x == 'tzec':
        month=5
    elif x == 'xul':
        month=6
    elif x == 'yoxkin':
        month=7
    elif x == 'mol':
        month=8
    elif x == 'chen':
        month=9
    elif x == 'yax':
        month=10
    elif x == 'zac':
        month=11
    elif x == 'ceh':
        month=12
    elif x == 'mac':
        month=13
    elif x == 'kankin':
        month=14
    elif x == 'muan':
        month=15
    elif x == 'pax':
        month=16
    elif x == 'koyab':
        month = 17
    elif x == 'cumhu':
        month=18
    else:
        month=19
    return month
#haab用数字0-19
Tzolkin_list=['imix','ik','akbal','kan','chicchan','cimi','manik',\
              'lamat','muluk','ok','chuen','eb','ben','ix',\
              'mem','cib','caban','eznab','canac','ahau']
#tzolkin用数字1-13

#输入数据,数据读取与转换
Haab_datebase = []
for i in range(n):
    str = input()
    temp = str[0:2]
    if "." in temp:
        temp = str[0]
        str = str[3:]
    else:
        str = str[4:]
    print(str)
    num = int(temp)
    haab_month = ""
    haab_year = ""
    for _ in str:
        if _ in ['0','1','2','3','4','5','6','7','8','9']:
            haab_year += _
        elif _ == " ":
            num += 1
        else:
            haab_month += _
    exact_month = month_convert(haab_month)
    exact_date = num + (exact_month-1)*20+365*int(haab_year)
    Haab_datebase.append(exact_date)