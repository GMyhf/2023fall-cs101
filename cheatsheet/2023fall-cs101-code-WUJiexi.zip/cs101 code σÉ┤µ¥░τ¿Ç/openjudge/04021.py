'''
2300015897
吴杰稀
光华管理学院
'''
def removal(num):
    changed_num = sorted(num)
    i,j,k = 0,0,0
    for _ in num:
        if _ < 0:
            i += 1
        elif _ == 0:
            j += 1
        elif _ > 0:
            k += 1
    if j >= 2:
        return num[0]
    if j == 1:
        if k > 0:
            if i % 2 != 0:
                if num[0] != 0:
                    return num[0]
                else:
                    return num[1]
            elif i % 2 == 0:
                return 0
        elif k == 0:
            if i % 2 != 0:
                if num[0] != 0:
                    return num[0]
                else:
                    return num[1]
            elif i % 2 == 0:
                return 0
    if j == 0:
        if k > 0:
            if i % 2 != 0:
                return changed_num[i - 1]
            elif i % 2 == 0:
                return changed_num[i]
        elif k == 0:
            if i % 2 != 0:
                return changed_num[i - 1]
            elif i % 2 == 0:
                return changed_num[0]

cases = int(input())
for i in range(cases):
    length = int(input())
    num_list = list(map(int,input().split()))
    res = removal(num_list)
    print(res)