'''
2300015897
'''
n,turns = map(int,input().split())
award = [100]*n
result = [[[],[]] for i in range(n)]
for i in range(turns):
    w,l = map(int,input().split())
    result[w][0] += [l]
    result[l][1] += [w]
def change(res):
    while True:
        flag = 0
        for i in range(n):
            if len(res[i][0]) == 0 and len(res[i][1]) != 0:
                flag = 1
                while res[i][1]:
                    team = res[i][1].pop()
                    res[team][0].remove(i)
                    award[team] = max(award[team],award[i] + 1)
        if flag == 0:
            return sum(award)

print(change(result))
