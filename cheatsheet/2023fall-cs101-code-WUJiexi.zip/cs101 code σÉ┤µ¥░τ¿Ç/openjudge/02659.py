'''
2300015897
吴杰稀
光华管理学院
'''
row,column,cases = map(int,input().split())
matrix = [[0]*column for i in range(row)]

def bomb(x,y,r,t):
    x_min = max(1,int(x - r // 2))
    x_max = min(row,int(x + r // 2))
    y_min = max(1,int(y - r // 2))
    y_max = min(column,int(y + r // 2))

    if t == 1:
        for i in range(x_min - 1,x_max):
            for j in range(y_min - 1,y_max):
                matrix[i][j] += 1
    elif t == 0:
        for i in range(x_min - 1,x_max):
            for j in range(y_min - 1,y_max):
                matrix[i][j] -= 1

for i in range(cases):
    x,y,r,t = map(int,input().split())
    bomb(x,y,r,t)

max_tag = 0
for _ in matrix:
    for i in _:
        if i > max_tag:
            max_tag = i

times = 0
for _ in matrix:
    for i in _:
        if i == max_tag:
            times += 1

print(times)
