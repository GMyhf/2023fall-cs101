m, n = map(int, input().split())
a = []
a.append([0]*(n+2))
for i in range(m):
    a.append([0] + [int(x) for x in input().split()] + [0])
a.append([0]*(n+2))
for i in range(1, m+1):
    for j in range(1, n+1):
        if a[i][j] == 0:
            a[i][j] = a[i][j-1] + 1 #宽度累加
        else:
            a[i][j] = 0 #种树了的地方因为没办法算数字,记为0
# 遍历每一个位置，向上回溯的方式，求以该位置为最右下⻆的树群的最大值
ans = 0
width = 0
for i in range(1, m+1):
    for j in range(1, n+1):
        if a[i][j] == 0:
            continue
        width = a[i][j]  # 设置为档期的宽度
        ans = max(ans, width*1);
        for k in range(i - 1, 0, -1):
            if a[k][j] == 0:
                break  # 如果搜到树，则说明不用再往上了
            else:
                width = min(a[k][j], width)  # 更新可以盖房子的宽度
                ans = max(ans, width * (i - k + 1))
print(ans)