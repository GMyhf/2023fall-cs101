'''
2300015897
吴杰稀
光华管理学院
'''
end = int(input())
res = []
for i in range(1001,end//10000 + 1):
    year = str(i)
    month = year[-1]+year[-2]
    date = year[1] + year[0]
    year,month,date = int(year),int(month),int(date)
    flag = 0
    if 1 <= month <= 12:
        if month in [1,3,5,7,8,10,12]:
            if 1 <= date <= 31:
                flag = 1
        elif month in [4,6,9,11]:
            if 1 <= date <= 30:
                flag = 1
        else:
            if year % 4 == 0:
                if year % 100 == 0 and year % 400 != 0:
                    if 1 <= date <= 28:
                        flag = 1
                else:
                    if 1 <= date <= 29:
                        flag = 1
            else:
                if 1 <= date <= 28:
                    flag = 1
        if flag == 1:
            ans = str(year) + str(year)[::-1]
            ans = int(ans)
            res.append(ans)
res.sort()
print(*res)