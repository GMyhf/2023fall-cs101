'''
2300015897
吴杰稀
光华管理学院
'''

cancer_graph = []
n = int(input())
for i in range(n):
    new_list = list(map(int,input().split()))
    cancer_graph.append(new_list)
for _ in cancer_graph:
    if sum(_) != n*255:
        j = 0
        i = n - 1
        while True:
            if _[j] == 255:
                _[j] = 0
                j += 1
            elif _[j] == 0:
                break
        while True:
            if _[i] == 255:
                _[i] = 0
                i -= 1
            elif _[i] == 0:
                break
add_up = 0
for _ in cancer_graph:
    if sum(_) != n*255:
        add_up += int(sum(_)//255)
print(add_up)