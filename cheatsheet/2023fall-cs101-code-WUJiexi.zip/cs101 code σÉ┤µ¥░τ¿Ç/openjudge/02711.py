'''
2300015897
吴杰稀
光华管理学院
'''

def longest_one(num):
    size = len(num)
    if size <= 1:
        return [1]
    dp1 = [1] * size
    dp2 = [1] * size
    for i in range(size):
        for j in range(i):
            if num[i] > num[j]:
                dp1[i] = max(dp1[i],dp1[j] + 1)
    num.reverse()
    for i in range(size):
        for j in range(i):
            if num[i] > num[j]:
                dp2[i] = max(dp2[i],dp2[j] + 1)
    dp2.reverse()
    total_list = [dp1[i] + dp2[i] for i in range(size)]
    return total_list

n = int(input())
num_list = list(map(int,input().split()))
res = longest_one(num_list)
print(n - max(res) + 1)