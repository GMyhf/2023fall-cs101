'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
num_list = []
for i in range(n):
    num_list.append(list(map(int,input().split())))
value_list = []
x,y = 0,0
while n - 2*x > 0:
    value = 0
    for i in range(x,n - x):
        for j in range(y,n - y):
            value += num_list[i][j]
    value_list.append(value)
    x += 1
    y += 1
for i in range(len(value_list) - 1):
    value_list[i] = value_list[i] - value_list[i + 1]
print(max(value_list))