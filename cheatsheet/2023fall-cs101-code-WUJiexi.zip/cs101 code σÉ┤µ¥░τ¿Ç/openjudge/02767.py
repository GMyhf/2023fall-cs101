'''
2300015897
吴杰稀
光华管理学院
'''
mingwen = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
miwen = "VWXYZABCDEFGHIJKLMNOPQRSTU"
letter_dict = {}
for i in range(len(mingwen)):
    letter_dict[mingwen[i]] = miwen[i]
string = input()
res = ""
for _ in string:
    if _ in mingwen:
        res += letter_dict[_]
    else:
        res += _
print(res)