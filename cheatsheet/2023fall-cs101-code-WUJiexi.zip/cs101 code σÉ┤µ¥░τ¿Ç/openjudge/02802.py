'''
2300015897
'''
from heapq import heappop,heappush

dx = [0,1,0,-1]
dy = [1,0,-1,0]

def is_valid(x,y):
    if 0 <= y < n + 2 and 0 <= x < m + 2 and ma[x][y] != "X":
        return True
    return False

def bfs(x,y):
    q = [(0,-1,x,y)]
    while q:
        step,dir,x1,y1 = heappop(q)
        ma[x1][y1] = "X"
        if x1 == ex and y1 == ey:
            return f"{step} segments."
        for i in range(4):
            nx,ny = x1 + dx[i],y1 + dy[i]
            ndir = i
            if ndir != dir:
                nstep = step + 1
            else:
                nstep = step
            if is_valid(nx,ny) or nx == ex and ny == ey:
                heappush(q,(nstep,ndir,nx,ny))
    return "impossible."

t = 0
while True:
    t += 1
    n,m = map(int,input().split())
    if n == m == 0:
        break
    maze = [[' ']*(n + 2)]
    for i in range(m):
        maze += [[' '] + [x for x in input()] + [' ']]
    maze += [[' ']*(n + 2)]
    k = 0
    print(f"Board #{t}:")
    while True:
        ma = [x.copy() for x in maze]
        k += 1
        y,x,ey,ex = map(int,input().split())
        if y == x == ey == ex == 0:
            break
        print(f"Pair {k}: {bfs(x,y)}")
    print()
