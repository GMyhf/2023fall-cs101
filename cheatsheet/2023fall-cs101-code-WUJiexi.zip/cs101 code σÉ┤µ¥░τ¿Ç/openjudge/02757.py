'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
altitude = list(map(int,input().split()))
dp_up = [1] * n
dp_down = [1] * n
for i in range(1,n):
    for j in range(i):
        if altitude[j] < altitude[i]:
            dp_up[i] = max(dp_up[i],1 + dp_up[j])
print(max(dp_up))