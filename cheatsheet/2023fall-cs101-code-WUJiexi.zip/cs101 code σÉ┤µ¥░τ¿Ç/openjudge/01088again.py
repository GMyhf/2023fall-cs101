'''
2300015897
'''
dx,dy = [1,0,-1,0],[0,-1,0,1]
def is_valid(x,y):
    if 0 <= x < r and 0 <= y < c:
        return True
    return False

def dfs(x,y):
    global res
    if res[x][y] > 0:
        return res[x][y]

    for i in range(4):
        nx = x + dx[i]
        ny = y + dy[i]
        if is_valid(nx,ny):
            if altitude[nx][ny] > altitude[x][y]:
                res[x][y] = max(res[x][y],dfs(nx,ny) + 1)

    return res[x][y]

r,c = map(int,input().split())
altitude = [[int(x) for x in input().split()] for i in range(r)]
res = [[0]*c for i in range(r)]
ans = 0
for i in range(r):
    for j in range(c):
        ans = max(ans,dfs(i,j))
print(ans + 1)