'''
2300015897
吴杰稀
光华管理学院
'''
line,row = map(int,input().split())
matrix = []
add_up = 0
for i in range(line):
    matrix.append(list(map(int,input().split())))
x,y = map(int,input().split())
matrix[x - 1],matrix[y - 1] = matrix[y - 1],matrix[x - 1]
add_up += sum(matrix[0]) + sum(matrix[-1])
for i in range(1,line-1):
    add_up += matrix[i][0] + matrix[i][-1]
print(add_up)