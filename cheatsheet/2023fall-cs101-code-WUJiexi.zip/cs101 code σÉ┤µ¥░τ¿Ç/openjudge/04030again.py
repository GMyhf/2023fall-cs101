'''
2300015897
吴杰稀
光华管理学院
'''
temp = ' '  + input().lower() + ' '
string = ' ' + input().lower() + ' '
string_list = [x for x in string.split()]
dic = {}
if string.find(temp) == -1:
    print("-1")
else:
    for _ in string_list:
        dic[_] = dic.get(_,0) + 1
    print(dic[temp[1:-1]],string.find(temp))