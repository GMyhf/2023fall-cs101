'''
2300015897
吴杰稀
光华管理学院
'''
p = int(input())
price = sorted([int(x) for x in input().split()])
i = 0
j = len(price) - 1
if p < price[0]:
    print("0")
else:
    tmp = p
    while i <= j:
        while i <= j:
            tmp -= price[i]
            if tmp >= 0:
                i += 1
            else:
                break
        if i > j:
            break
        tmp += price[j]
        j -= 1
        if tmp < 0:
            break
        i += 1
    print(i + 1- (len(price) - j))



