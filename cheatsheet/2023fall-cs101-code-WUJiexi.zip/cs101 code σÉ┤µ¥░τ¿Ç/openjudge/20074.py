'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
male,female = [0],[0]
for i in range(cases):
    inform = list(map(str,input().split()))
    inform[0],inform[1] = int(inform[0]),int(inform[1])
    low = 18.5
    high = 24.9
    if inform[2] == "M":
        if inform[1] < (inform[0]/100)**2 * low:
            change = (inform[0]/100)**2 * low - inform[1]
            if change % 8 == 0:
                male.append(change // 8)
            else:
                male.append(change // 8 + 1)
        elif inform[1] > (inform[0]/100)**2 * high:
            change = inform[1] - (inform[0] / 100) ** 2 * high
            if change % 5 == 0:
                male.append(change // 5)
            else:
                male.append(change // 5 + 1)
    elif inform[2] == "F":
        if inform[1] < (inform[0]/100)**2 * low:
            change = (inform[0]/100)**2 * low - inform[1]
            if change % 8 == 0:
                female.append(change // 8)
            else:
                female.append(change // 8 + 1)
        elif inform[1] > (inform[0]/100)**2 * high:
            change = inform[1] - (inform[0] / 100) ** 2 * high
            if change % 5 == 0:
                female.append(change // 5)
            else:
                female.append(change // 5 + 1)
print(int(max(male)),int(max(female)))