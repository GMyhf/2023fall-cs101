times=int(input())

for i in range(times):

    n=int(input())

    a=0

    for j in range(1,n+1):

        sum=0

        for x in range(1,j+1):
            if j%x==0:
                sum+=1
            
        if sum%2 != 0:
            a+=1

    print(a)