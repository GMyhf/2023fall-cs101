'''
2300015897
'''
n = int(input())
a,b,c,d = [0]*4000,[0]*4000,[0]*4000,[0]*4000
sum1,sum2 = [],[]
for i in range(n):
    a[i],b[i],c[i],d[i] = map(int,input().split())
dic = {}
for i in range(n):
    for j in range(n):
        dic[a[i] + b[j]] = dic.get(a[i] + b[j],0) + 1
cnt = 0
for i in range(n):
    for j in range(n):
        cnt += dic.get(-c[i] - d[j],0)
print(cnt)
