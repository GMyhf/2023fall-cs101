def maxSubarraySum(nums, n):
    left = right = 0
    total = 0
    max_sum = float('-inf')

    while right < n:
        total += nums[right]
        while total / (right - left + 1) > 520 and left <= right - 1:
            total -= nums[left]
            left += 1
        max_sum = max(max_sum, total)
        right += 1

    return max_sum

n = int(input())
values = list(map(int, input().split()))
result = maxSubarraySum(values, n)
print(result)