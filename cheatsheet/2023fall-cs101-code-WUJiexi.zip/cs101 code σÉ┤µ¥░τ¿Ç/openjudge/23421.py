'''
2300015897
'''
n,b = map(int,input().split())
p = [int(x) for x in input().split()]
w = [int(x) for x in input().split()]
dp = [0]*(b + 1)
for i in range(n):
    for j in range(b,0,-1):
        if j >= w[i]:
            dp[j] = max(dp[j],dp[j - w[i]] + p[i])
print(dp[-1])