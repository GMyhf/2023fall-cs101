'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
dic = {}
for i in range(n):
    n,m,d = input().split()
    m,d = int(m),int(d)
    dic[(m,d)] = dic.get((m,d),[]) + [n]
res = []
for key,value in dic.items():
    res.append([key,value])
res.sort()
for _ in res:
    if len(_[1]) > 1:
        print(_[0][0],_[0][1],*_[1])