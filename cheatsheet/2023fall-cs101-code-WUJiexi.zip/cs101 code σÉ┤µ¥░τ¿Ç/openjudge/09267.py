'''
2300015897
吴杰稀
光华管理学院
'''
n,m = map(int,input().split())
dp = [0] * 51
dp[0] = 1
dp[1] = 2
for i in range(2,51):
    if i < m:
        dp[i] = 2 * dp[i - 1]
    elif i == m:
        dp[i] = 2 * dp[i - 1] - 1
    elif i > m:
        dp[i] = 2 * dp[i - 1] - dp[i - m - 1]
print(dp[n])