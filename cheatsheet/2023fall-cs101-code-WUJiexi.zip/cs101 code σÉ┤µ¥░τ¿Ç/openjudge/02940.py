'''
2300015897
吴杰稀
光华管理学院
'''
a,n = map(int,input().split())
s = n*str(a)
res = 0
while len(s) >= 1:
    res += int(s)
    s = s[1:]
print(res)