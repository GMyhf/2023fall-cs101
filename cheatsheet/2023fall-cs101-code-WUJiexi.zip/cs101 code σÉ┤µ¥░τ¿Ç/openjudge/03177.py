'''
2300015897
吴杰稀
光华管理学院
'''

def divided_exactly(x,y):
    if x % y == 0:
        return True
    else:
        return False

def prime(n):
    if n < 2:
        return False
    else:
        for i in range(2,int(n**0.5) + 1):
            if divided_exactly(n,i):
                return False
        return True
a,b = map(int,input().split())
x = min(a,b)
y = max(a,b)

prime_list = []
for i in range(x,y + 1):
    if prime(i):
        prime_list.append(i)
print(len(prime_list))