m,time = map(int,input().split())
herb = []
for i in range(m):
    herb.append(list(map(int,input().split())))
package = [0] * (time + 1)
for i in range(1,m + 1):
    for j in range(time,0,-1):
        if j >= herb[i - 1][0]:
            package[j] = max(package[j],package[j - herb[i - 1][0]] + herb[i - 1][1])
        else:
            package[j] = package[j]
print(package[time])