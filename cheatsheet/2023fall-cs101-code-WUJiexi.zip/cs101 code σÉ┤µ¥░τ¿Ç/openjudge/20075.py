'''
2300015897
'''
m,n,p = map(int,input().split())
dx,dy = [1,0,-1,0],[0,-1,0,1]
from heapq import heappop,heappush
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and maze[x][y] != 2 and not v[x][y]:
        return True
    return False

def bfs(x,y):
    q = [(0,x,y)]
    while q:
        step,x1,y1 = heappop(q)
        if maze[x1][y1] == 2:
            return "NO"
        if maze[x1][y1] == 1:
            return step
        v[x1][y1] = True
        for i in range(4):
            nx,ny = x1 + dx[i],y1 + dy[i]
            if is_valid(nx,ny):
                nstep = step + 1
                heappush(q,(nstep,nx,ny))
    return "NO"
maze = [[int(x) for x in input().split()] for i in range(m)]
for i in range(p):
    v = [[False]*n for i in range(m)]
    sx,sy = map(int,input().split())
    print(bfs(sy - 1,sx - 1))
