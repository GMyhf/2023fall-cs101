'''
2300015897
'''
n = int(input())
def search():
    global result
    result = [1] * (n+1)
    for i in range(2,n+1):
        if i % 2 == 0:
            result[i] = (result[i - 1] + result[i // 2])%10**9
        else:
            result[i] = result[i - 1]%10**9
search()
print(result[n])