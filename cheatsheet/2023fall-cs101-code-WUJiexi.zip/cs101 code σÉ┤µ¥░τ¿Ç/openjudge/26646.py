'''
2300015897
参考X
'''
def generate_intervals(pos,width):
    tmp = []
    for start in range(max(0,pos - width + 1),min(m,x + 1)):
        end = start + width
        if end <= m:
            tmp.append((start,end))
    return tmp

n,m = map(int,input().split())
mx = m
plan,info = [],[]
for i in range(n):
    plan += [tuple(map(int,input().split()))]
for x,y in plan:
    info.extend(generate_intervals(x,y))
info.sort(key = lambda x:(x[1],x[0]))
cnt = 0
end = 0
for s,e in info:
    if s >= end:
        end = e
        cnt += 1
print(cnt)


