'''
2300015897
'''
from collections import deque
in_queue = [False]*100010
def get_step(x,y):
    step = 0
    q = deque()
    q.append(x)
    while True:
        cnt = len(q)
        for i in range(cnt):
            front = q.popleft()
            if front == y:
                return step
            in_queue[front] = True
            if front - 1 >= 0 and not in_queue[front - 1]:
                q.append(front - 1)
            if front + 1 <= 100000 and not in_queue[front + 1]:
                q.append(front + 1)
            if 2 * front <= 100000 and not in_queue[2*front]:
                q.append(2*front)
        step += 1
n, k = map(int,input().split())
print(get_step(n,k))