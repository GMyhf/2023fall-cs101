'''
2300015897
'''
n = int(input())
num = list(map(int,input().split()))
index_l = [i for i in range(1,n + 1)]
new = list(zip(num,index_l))
new.sort(key = lambda x:x[0])
res = []
a = 0
for i in range(n):
    a += new[i][0] * (n - i - 1)
    res.append(new[i][1])
print(*res)
print(f"{a/n:.2f}")