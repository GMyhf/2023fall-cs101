'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    a,b,c,r = map(int,input().split())
    if a > b:
        a,b = b,a
    res = b - a
    if c + r <= a:
        print(res)
    elif c - r >= b:
        print(res)
    else:
        if c - r >= a and c + r <= b:
            res -= 2*r
            print(res)
        elif c - r >= a and c + r > b:
            res = c - r - a
            print(res)
        elif c - r < a and c + r <= b:
            res = b - c- r
            print(res)
        elif c - r < a and c + r > b:
            res = 0
            print(res)