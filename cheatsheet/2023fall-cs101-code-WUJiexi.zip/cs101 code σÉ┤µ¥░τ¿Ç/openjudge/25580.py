'''
2300015897
吴杰稀
光华管理学院
'''
H,L,n = map(int,input().split())
v_list = list(map(int,input().split()))
v_list.sort(reverse=True)
l = len(v_list)
if l % 2 == 0:
    mid = l // 2
else:
    mid = (l - 1) // 2 + 1
t = v_list[mid - 1]
time = L / t
res = H - 0.5 * 10 * (time ** 2)
print(f"{res:.2f}")
