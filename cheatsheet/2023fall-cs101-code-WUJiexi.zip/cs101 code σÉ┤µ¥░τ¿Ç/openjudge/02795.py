'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    max_weight = int(input())
    types = int(input())
    value_list = list(map(int,input().split()))
    average_list = []
    for i in range(types):
        n = value_list[2 * i]
        average = value_list[2 * i + 1] / value_list[2 * i]
        average_list.append([average,n])
    average_list.sort(key = lambda x: x[0],reverse=True)
    res,bring,i = 0,0,0
    while bring <= max_weight and i < types:
        if max_weight >= bring + average_list[i][1]:
            res += average_list[i][0]*average_list[i][1]
            bring += average_list[i][1]
            i += 1
        else:
            res += average_list[i][0] * (max_weight - bring)
            break
    print(f"{res:.2f}")