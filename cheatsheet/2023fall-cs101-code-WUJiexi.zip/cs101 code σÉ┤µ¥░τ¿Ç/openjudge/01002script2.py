def change(x):
    if x == "D" or "E" or "F":
        x="3"
        return "3"
    elif x == "G" or "H" or "I":
        x="4"
        return "4"
    elif x == "J" or "K" or "L":
        return "5"
    elif x == "M" or "N" or "O":
        return "6"
    elif x == "P" or "R" or "S":
        return "7"
    elif x == "T" or "U" or "V":
        return "8"
    else:
        return "9"

t=input()
t=change(t)
print(t)