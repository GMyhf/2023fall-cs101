'''
2300015897
吴杰稀
光华管理学院
'''
month_list = [31,28,31,30,31,30,31,31,30,31,30,31]
cases = int(input())
for i in range(cases):
    start_month,start_day,number,end_month,end_day = map(int,input().split())
    accurate_start = sum(month_list[:(start_month-1)]) + start_day
    accurate_end = sum(month_list[:(end_month-1)]) + end_day
    lenth = accurate_end - accurate_start
    new_number = number * (2**lenth)
    print(new_number)