'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
p = []
for i in range(n):
    c,w = map(int,input().split())
    p.append([c,w,c + w])
p.sort(key=lambda x:x[1],reverse=True)
res,cnt = p[0][2],p[0][0]
for i in range(1,n):
    res = max(res,cnt + p[i][2])
    cnt += p[i][0]
print(res)
