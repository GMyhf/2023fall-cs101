'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    try:
        t=0
        code=input()
        code=code.lstrip()
        flag=1

        if code[0] in ["@","."]:
            flag=0
        elif code[-1] in ["@","."]:
            flag=0
        
        sum=0
        for _ in code:
            if _ =="@":
                sum+=1

        if sum!=1:
            flag=0

        for i in range(len(code)):
            if code[i]=="@":
                t=i
        if t+1 <= len(code)-1:
            if code[t+1]==".":
                flag=0
        if t-1 >= 0:
            if code[t-1]==".":
                flag=0

        times=0
        for j in range(t+1,len(code)):
            if code[j]==".":
                times+=1
            
        if times==0:
            flag=0   

        if flag==1:
            print("YES")
        else:
            print("NO")

    except:
        break
