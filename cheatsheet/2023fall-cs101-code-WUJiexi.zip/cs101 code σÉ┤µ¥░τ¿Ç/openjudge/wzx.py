words_input = []
try:
    while True:
        word = input()
        if not word:
            break
        words_input.append(word)
except EOFError:
    pass
words_input.sort()
words_dict = {}
for word in words_input:
    if word in words_dict:
        words_dict[word] += 1
    else:
        words_dict[word] = 1
res = []
for key,value in words_dict.items():
    res.append([key,value])
res.sort(key = lambda x:x[1],reverse= True)
for _ in res:
    print(_[0])