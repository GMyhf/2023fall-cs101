'''
2300015897
吴杰稀
光华管理学院
'''
length = int(input())
value_list = [0] * (length + 1)
put_in = list(map(int,input().split()))
for i in range(1,length + 1):
    value_list[i] = put_in[i - 1]
for i in range(1,length + 1):
    value_list[i] += value_list[i - 1]
for i in range(1,length + 1):
    value_list[i] -= 520 * i
position_dict = {}
for i in range(length + 1):
    if value_list[i] not in position_dict:
        position_dict[value_list[i]] = [i]
    else:
        position_dict[value_list[i]].append(i)
res = 0
for keys,values in position_dict.items():
    if len(values) >= 2:
        if values[-1] - values[0] > res:
            res = values[-1] - values[0]
print(res * 520)