'''
2300015897
吴杰稀
光华管理学院
'''
def counter(m,n):
    if m <= 1 or n == 1:
        return 1
    elif m < n:
        return counter(m,m)
    else:
        return counter(m,n - 1) + counter(m - n,n)
cases= int(input())
for i in range(cases):
    m,n = map(int,input().split())
    print(counter(m,n))