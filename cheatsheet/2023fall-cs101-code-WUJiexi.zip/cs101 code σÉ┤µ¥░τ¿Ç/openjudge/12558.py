'''
2300015897
吴杰稀
光华管理学院
'''
def count_lines(x,y):
    lines = 0
    if island_map[x][y - 1] == 0:
        lines += 1
    if island_map[x][y + 1] == 0:
        lines += 1
    if island_map[x + 1][y] == 0:
        lines += 1
    if island_map[x - 1][y] == 0:
        lines += 1
    return lines

n,m = map(int,input().split())
island_map = [[0] * (m + 2) for i in range(n + 2)]
for i in range(1,n + 1):
    island = list(map(int,input().split()))
    for j in range(1,m + 1):
        island_map[i][j] = island[j - 1]

ans = 0
for i in range(1,n + 1):
    for j in range(1, m + 1):
        if island_map[i][j] == 1:
            ans += count_lines(i,j)
print(ans)
