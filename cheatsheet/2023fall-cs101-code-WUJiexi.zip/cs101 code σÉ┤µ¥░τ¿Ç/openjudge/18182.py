'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    num,most,blood = map(int,input().split())
    skill_dict = {}
    moment_list = []
    for i in range(num):
        moment,harm = map(int,input().split())
        if moment not in moment_list:
            moment_list.append(moment)
        if moment in skill_dict:
            skill_dict[moment].append(harm)
        else:
            skill_dict[moment] = [harm]
    moment_list.sort()
    j = 0
    while j < len(moment_list):
        skill = skill_dict[moment_list[j]]
        skill.sort(reverse=True)
        if most >= len(skill):
            total_harm = sum(skill)
        else:
            total_harm = sum(skill[:most])
        blood -= total_harm
        if blood <= 0:
            print(moment_list[j])
            break
        j += 1
    if blood > 0:
        print("alive")

