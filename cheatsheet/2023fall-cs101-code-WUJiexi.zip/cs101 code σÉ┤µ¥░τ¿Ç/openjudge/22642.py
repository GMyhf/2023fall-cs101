n,k=map(int,input().split())

list=[]
for i in range(n):
    list.append(float(input()))

#二分法
add_up=0
for j in list:
    add_up+=j*100
end=int(add_up*100/k)
start=100
#判定是否能有足够大于1cm的网线
flag=True
least=0
for _ in list:
    least+=_//1
if least<k:
    print("0.00")
    flag=False

#二分循环
while flag:
    sum=0
    for _ in list:
        sum+=_*100//((start+end)/2)
    if sum>=k:
        start=int((start+end)/2)
    else:
        end=int((start+end)/2)

    if end-start<=1:
        break

if flag==True:
    print(f"{start/100:.2f}")