'''
2300015897
吴杰稀
光华管理学院
'''
string = input().lower()
s_list = [x for x in string]
words_dict = {}
for _ in s_list:
    words_dict[_] = words_dict.get(_,0) + 1
res = []
for key,value in words_dict.items():
    res.append([key,value])
res.sort(key = lambda x:x[1],reverse = True)
print(*res[0])
