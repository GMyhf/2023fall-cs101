x,y,m,n,l=map(int,input().split())

if x==y:
    False
else:
    if m==n:
        print("Impossible")
    if m>n:
        if x>y:
            if (y+l-x)%(m-n)==0:
