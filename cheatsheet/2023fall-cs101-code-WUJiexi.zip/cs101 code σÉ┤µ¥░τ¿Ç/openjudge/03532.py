'''
2300015897
吴杰稀
光华管理学院
'''
length = int(input())
num_list = list(map(int,input().split()))
dp = num_list.copy()
for i in range(1,length):
    for j in range(i):
        if num_list[i] > num_list[j]:
            dp[i] = max(dp[i],dp[j] + num_list[i])
print(max(dp))