'''
2300015897
吴杰稀
光华管理学院
'''
string_a = input()
string_list = []
for _ in string_a:
    string_list.append(ord(_) - ord("a"))
k = int(input())
t = ord("z")
length = len(string_list)
add_up = 0
for i in range(length):
    add_up += string_list[- i - 1] * (26**(i))
add_up += k + 1
for i in range(length):
    string_list[i] = add_up // (26**(length - i - 1))
    add_up -= (add_up // (26**(length - i - 1))) * (26**(length - i - 1))
res = ''
for _ in string_list:
    res += chr(_ + ord("a"))
print(res)