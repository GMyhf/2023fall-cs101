'''
2300015897
吴杰稀
光华管理学院
'''
n,x,y = map(int,input().split())
name_dict = {}
for i in range(n):
    course,name,score = input().split()
    score = int(score)
    if name in name_dict:
        name_dict[name][0] += 1
        name_dict[name][1] += score
    else:
        name_dict[name] = [1,score]

m = int(input())
for i in range(m):
    name = input()
    if name_dict[name][0] >= x and name_dict[name][1] > y * name_dict[name][0]:
        print("yes")
    else:
        print("no")