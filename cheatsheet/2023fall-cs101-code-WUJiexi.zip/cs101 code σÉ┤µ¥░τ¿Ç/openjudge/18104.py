'''
2300015897
吴杰稀
光华管理学院
'''
expectation = [int(x) for x in input().split()]
weight = [int(x) for x in input().split()]
expectation.sort()
weight.sort()
i,j =0,0
ans = 0
while i <= len(expectation) - 1 and j <= len(weight) - 1:
    if weight[j] >= expectation[i]:
        ans += 1
        i += 1
        j += 1
    elif weight[j] < expectation[i]:
        j += 1
print(ans)