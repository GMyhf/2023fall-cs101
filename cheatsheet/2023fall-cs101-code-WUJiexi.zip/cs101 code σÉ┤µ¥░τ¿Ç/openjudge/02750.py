a=int(input())
if a%2!=0:
    print("0 0")
else:
    min=a//4+(a%4)//2
    max=a//2
    print(f"{min} {max}")