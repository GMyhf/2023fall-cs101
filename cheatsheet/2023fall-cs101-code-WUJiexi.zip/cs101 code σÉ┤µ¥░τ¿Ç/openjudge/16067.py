'''
2300015897
'''
while True:
    n = int(input())
    if n == 0:
        break
    time = [[int(x) for x in input().split()] for i in range(n)]
    time.sort(key = lambda x:x[1])
    cnt = 0
    end = -1
    for _ in time:
        if _[0] >= end:
            cnt += 1
            end = _[1]
    print(cnt)
