'''
2300015897
吴杰稀
光华管理学院
'''
def cantor_expansion(permutation):
    result = 1
    for i in range(n):
        count = 0
        for j in range(i + 1, n):
            if permutation[j] < permutation[i]:
                count += 1
        result += count * fact[n - i - 1]
    return result
