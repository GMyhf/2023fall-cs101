'''
2300015897
'''
from collections import deque
dx,dy = [1,0,-1,0],[0,-1,0,1]

def is_valid(x,y,yellow):
    if 0 <= x < n and 0 <= y < n and maze[x][y] == yellow:
        return True
    return False

def bfs(x,y,yellow):
    maze[x][y] = "#"
    q = deque([[x,y]])
    #print(q)
    while q:
        cnt = len(q)

        for i in range(cnt):
            front = q.popleft()
            #print(front)

            for j in range(4):

                nx = front[0] + dx[j]
                ny = front[1] + dy[j]

                if is_valid(nx,ny,yellow):
                    maze[nx][ny] = "#"
                    q.append([nx,ny])

cases = int(input())
for i in range(cases):
    n = int(input())
    maze = [[x for x in input()] for i in range(n)]
    cntr,cntb = 0,0
    for i in range(n):
        for j in range(n):
            if maze[i][j] == "r":
                bfs(i,j,"r")
                cntr += 1
            elif maze[i][j] == "b":
                bfs(i,j,"b")
                cntb += 1
    print(cntr,cntb)