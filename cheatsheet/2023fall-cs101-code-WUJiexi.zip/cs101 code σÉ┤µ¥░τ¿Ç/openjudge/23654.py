year=int(input())

while True:
    year+=1

    e=year//10000
    ei=year-10000*e
    d=ei//1000
    di=ei-1000*d
    c=di//100
    ci=di-100*c
    b=ci//10
    bi=ci-10*b
    a=bi

    if a+b+c+d+e == 20:
        break

print(year)
