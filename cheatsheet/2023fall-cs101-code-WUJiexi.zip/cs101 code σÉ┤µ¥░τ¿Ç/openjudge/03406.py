'''
2300015897
'''
n,b = map(int,input().split())
h = []
for i in range(n):
    h += [int(input())]
h.sort()
cnt = 0
for i in range(n - 1,-1,-1):
    cnt += h[i]
    if cnt >= b:
        print(n - i)
        break
