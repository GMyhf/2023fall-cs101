'''
2300015897
'''
while True:
    try:
        n = int(input())
        if n == 0:
            break
        info = []
        for i in range(n):
            info.append(tuple(map(int,input().split())))
        info.sort(key = lambda x:x[1])
        info.sort()
        cnt = 0
        nowd,nowc = float('-inf'),float('inf')
        for i in range(n):
            di,ci = info[i]
            if nowd == di:
                if ci <= nowc:
                    cnt += 1
                    nowc = ci
            else:
                if ci < nowc:
                    cnt += 1
                    nowc = ci
                    nowd = di
        print(cnt)
    except:
        break