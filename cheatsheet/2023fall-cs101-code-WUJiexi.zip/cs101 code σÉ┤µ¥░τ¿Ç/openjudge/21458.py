'''
2300015897
'''
n,m = map(int,input().split())
dp = [float('-inf')]*(n + 1)
t,w = [],[]
for i in range(m):
    x,y = map(int,input().split())
    t += [x]
    w += [y]

for i in range(1,m + 1):
    for j in range(n,-1,-1):
        if j == t[i - 1]:
            dp[j] = max(dp[j],dp[j - t[i - 1]] + w[i - 1],w[i - 1])
        elif j > t[i - 1]:
            dp[j] = max(dp[j], dp[j - t[i - 1]] + w[i - 1])
print(dp[-1] if dp[-1] > 0 else "-1")
