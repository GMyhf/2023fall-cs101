'''
2300015897
吴杰稀
光华管理学院
'''
lenth = int(input())
num_list = list(map(int,input().split()))
dp = [1] * (lenth + 1)
for i in range(1,lenth):
    for j in range(i):
        if num_list[i] > num_list[j]:
            dp[i] = max(dp[i],dp[j] + 1)
print(max(dp))