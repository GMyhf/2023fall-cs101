'''
2300015897
吴杰稀
光华管理学院
'''
n,k = map(int,input().split())
num = [int(x) for x in input().split()]
num.sort(reverse = True)
num_dic = {1:0,2:0,3:0,4:0}
for i in range(k):
    t = num[i] % 4
    num_dic[4] += num[i] // 4
    if t != 0:
        num_dic[t] += 1
t = min(num_dic[4],n)
flag = 0
#4个不够放
if t == n:
    left = 2*(num_dic[4] - n) + num_dic[1] + num_dic[2] + 2*num_dic[3]
    if 2 * n >= left:
        flag = 1
#4个均够放
elif t < n:
    s = min(n - t,num_dic[3])
    #3个均够放
    if s == num_dic[3]:
        empty1 = 2 * (num_dic[3] + num_dic[4])
        empty2 = 4 * (n - num_dic[3] - num_dic[4])
        if num_dic[2] <= empty1:
            if num_dic[1] <= empty1 - num_dic[2] + empty2:
                flag = 1
        else:
            num_dic[2] -= empty1
            if 3 * num_dic[1] >= num_dic[2]:
                if num_dic[1] + num_dic[2] <= empty2:
                    flag = 1
            else:
                num_dic[2] -= 3*num_dic[1]
                if empty2 - 4*num_dic[1] >= 4/3 * num_dic[2]:
                    flag = 1
    #3个不够放
    elif s < num_dic[3]:
        left = 2 * num_dic[3] + num_dic[1] + num_dic[2]
        if 2 * n >= left:
            flag = 1
print("YES" if flag else "NO")

