def find_pair_with_given_sum(arr, target):
    num_to_index = {}
    for i, num in enumerate(arr):
        complement = target - num
        if complement in num_to_index:
            return [min(num, complement), max(num, complement)]
        num_to_index[num] = i
    return ["No"]

n = int(input())
arr = list(map(int, input().split()))
m = int(input())

result = find_pair_with_given_sum(arr, m)
print(*result)