'''
2300015897
吴杰稀
光华管理学院
'''
start = 0
end = 6

start_y = start**3 - 5*(start**2) + 10*start - 80
end_y = end**3 - 5*(end**2) + 10*end - 80

while True:
    t = round((start + end) / 2, 10)
    y = t ** 3 - 5 * (t ** 2) + 10 * t - 80
    if end_y*y >0:
        start = t
    else:
        end = t
    if end - start <= 0.000000001:
        break
print(end,start)