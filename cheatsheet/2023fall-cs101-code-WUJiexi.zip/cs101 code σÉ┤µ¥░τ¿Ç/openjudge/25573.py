'''
2300015897
'''
s = input()
n = len(s) + 1
R,B = [0] * n,[0] * n
if s[0] == "R":
    R[1],B[1] = 0,1
else:
    R[1],B[1] = 1,0
for i in range(2,n):
    if s[i - 1] == "R":
        R[i] = R[i - 1]
        B[i] = min(R[i - 1],B[i - 1]) + 1
    else:
        R[i] = min(R[i - 1],B[i - 1]) + 1
        B[i] = B[i - 1]
print(R[-1])