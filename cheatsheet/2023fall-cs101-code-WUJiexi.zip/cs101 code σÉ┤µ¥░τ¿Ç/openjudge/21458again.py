'''
2300015897
'''
T,n = map(int,input().split())
exer = []
for i in range(n):
    t,w = map(int,input().split())
    exer.append((t,w))
dp = [float('-inf')]*(T + 1)
for i in range(1,n + 1):
    for j in range(T,0,-1):
        if j == exer[i - 1][0]:
            dp[j] = max(dp[j - exer[i - 1][0]] + exer[i - 1][1],dp[j],exer[i - 1][1])
        elif j > exer[i - 1][0]:
            dp[j] = max(dp[j - exer[i - 1][0]] + exer[i - 1][1],dp[j])
print(dp[-1] if dp[-1] > 0 else -1)