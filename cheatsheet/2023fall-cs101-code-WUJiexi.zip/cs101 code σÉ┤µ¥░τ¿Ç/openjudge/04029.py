'''
2300015897
吴杰稀
光华管理学院
'''
string = input()
new_string = ''
if string[0] == "-":
    new_string += "-"
    string = string[1:]
new_string += str(int(string[::-1]))
print(new_string)