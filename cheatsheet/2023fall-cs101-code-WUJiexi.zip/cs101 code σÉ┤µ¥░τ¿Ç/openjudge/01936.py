while True:
    try:
        s,t=input().split()
        list_s=[]
        list_t=[]
        for i in s:
            list_s.append(i)

        for j in t:
            if list_s != []:
                if j ==list_s[0]:
                    list=list_s.pop(0)

        if list_s==[]:
            print("Yes")
        else:
            print("No")

    except:
        break