'''
2300015897
'''
cases = int(input())
for i in range(cases):
    e,f = map(int,input().split())
    n = int(input())
    coins = []
    for i in range(n):
        p,w = map(int,input().split())
        coins.append((-p,-w))
    dp = [float('-inf')] * (f - e + 1)
    for i in range(n):
        p = coins[i][0]
        t = -coins[i][1]
        for j in range(t,f - e + 1):
            if j == t:
                dp[j] = max(dp[j],p)
            elif j > t:
                dp[j] = max(dp[j],dp[j - t] + p)
    if dp[-1] >= -999999:
        print(f"The minimum amount of money in the piggy-bank is {-dp[-1]}.")
    else:
        print("This is impossible.")