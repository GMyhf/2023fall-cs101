'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
rating = list(map(int,input().split()))
res = n
if n == 1:
    print("1")
else:
    down,up = 0,0
    if rating[0] > rating[1]:
        down += 1
    elif rating[0] < rating[1]:
        up += 1
    for i in range(1,n - 1):
        if rating[i] > rating[i + 1]:
            if up > 0:
                down = 0
                res += (up)*(up + 1) // 2
                up = 0
            else:
                down += 1
        elif rating[i] < rating[i + 1]:
            if down > 0:
                up += 1
                res += (down)*(down + 1) // 2
                down = 0
            else:
                up += 1
        elif rating[i] == rating[i + 1]:
            res += (down)*(down + 1) // 2 + (up)*(up + 1) // 2
            up,down = 0,0
    if down > 0 and rating[n - 2] > rating[n - 1]:
        res += (down)*(down + 1) // 2
    elif up > 0 and rating[n - 2] < rating[n - 1]:
        res += (up)*(up + 1) // 2
    print(res)


