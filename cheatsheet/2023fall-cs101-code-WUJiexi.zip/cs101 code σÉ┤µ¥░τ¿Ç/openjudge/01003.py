
while True:
    len=float(input())

    if len==0.00:
        break

    n=2
    sum=1/2

    while sum < len:
        sum+=1/(n+1)
        n+=1
        if sum >= len:
            break
    
    if len <= 1/2:
        print("1 card(s)")
    
    else:
        print(f"{n-1} card(s)")



