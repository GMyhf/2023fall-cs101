'''
2300015897
吴杰稀
光华管理学院
'''
dict_average = {}
cases,capacity = map(int,input().split())
for _ in range(cases):
    value,weight = map(int,input().split())
    average = value / weight
    if average in dict_average:
        dict_average[average] += weight
    else:
        dict_average[average] = weight
list_average = [i for i in dict_average.keys()]
list_average.sort(reverse=True)
add_up,i = 0,0
bring_value = 0
total = 0
while True:
    add_up += dict_average[list_average[i]]
    bring_value += list_average[i] * dict_average[list_average[i]]
    if capacity - add_up <= 0:
        bring_value -= list_average[i] * (add_up - capacity)
        break
    i += 1
    if i > len(dict_average) - 1:
        break
print(f"{bring_value:.1f}")
