def cantor_expansion(permutation):
    result = 1
    for i in range(n):
        count = 0
        for j in range(i + 1, n):
            if permutation[j] < permutation[i]:
                count += 1
        result += count * fact[n - i - 1]
    return result

n = int(input())
fact = [1] * (n + 1)
for i in range(2, n + 1):
    fact[i] = (fact[i - 1] * i) % 998244353
num = [int(x) for x in input().split()]
print(cantor_expansion(num)%998244353)
