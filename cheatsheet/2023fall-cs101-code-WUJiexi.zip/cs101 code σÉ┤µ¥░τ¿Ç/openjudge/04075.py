'''
2300015897
吴杰稀
光华管理学院
'''
def turn_matrix(matrix):
    new_matrix = [[0]*n for i in range(n)]
    for i in range(n):
        for j in range(n):
            new_matrix[i][n - j - 1] = matrix[j][i]
    return new_matrix
cases = int(input())
for i in range(cases):
    n = int(input())
    matrix = []
    for i in range(n):
        matrix.append(list(map(int,input().split())))
    ans = turn_matrix(matrix)
    for _ in ans:
        print(*_)