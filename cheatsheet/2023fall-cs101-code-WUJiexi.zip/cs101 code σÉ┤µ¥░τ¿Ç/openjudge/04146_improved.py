'''
2300015897
吴杰稀
光华管理学院
'''
for n in range(1,101):
    sum_list = []

    for a1 in range(n+1):
        for a2 in range(n+1):
            for a3 in range(n+1):
                if (a1 + a2)%2 == 0 and (a2 + a3)%3 == 0 and (a1 + a2 + a3)%5 == 0:
                    sum_list.append(a1+a2+a3)
    sum_list.sort()
    print(sum_list[-1])