'''
2300015897
'''
while True:
    n = int(input())
    if n == 0:
        break
    tri = [[int(x) for x in input().split()] for i in range(n)]
    #print(triangle)
    px,py = map(int, input().split())
    ntri = []
    for i in range(px - 1, n):
        tmp = []
        for j in range(py - 1, py + i + 1 - px):
            tmp.append(tri[i][j])
        ntri.append(tmp)
    #print(new_triangle)
    l = len(ntri)
    #print(l)
    #print(ntri)
    #if l == 1:
    #    print(ntri[0][0])
    #else:
    for i in range(l - 2,-1,-1):
        for j in range(len(ntri[i])):
            ntri[i][j] = max(ntri[i + 1][j],ntri[i + 1][j + 1],ntri[i][j])
    print(ntri[0][0])