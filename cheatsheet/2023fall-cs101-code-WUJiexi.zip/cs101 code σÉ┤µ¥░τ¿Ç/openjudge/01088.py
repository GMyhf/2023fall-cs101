'''
2300015897
吴杰稀
光华管理学院
'''
dx = [0,1,0,-1]
dy = [1,0,-1,0]
def dfs(maze,x,y):
    global res

    if res[x][y] > 0:
        return res[x][y]

    for i in range(4):
        nx = x + dx[i]
        ny = y + dy[i]
        if maze[nx][ny] > maze[x][y]:
            res[x][y] = max(res[x][y],dfs(maze,nx,ny) + 1)

    return res[x][y]

row,col = map(int,input().split())
#加保护圈
altitude = [[0]*(col + 2)]
for i in range(row):
    altitude.append([0] + [int(x) for x in input().split()] + [0])
altitude.append([0]*(col + 2))
res = [[0]*(col + 2) for i in range(row + 2)]
ans = 0
for i in range(1,row + 1):
    for j in range(1,col + 1):
        ans = max(ans,dfs(altitude,i,j))
print(ans + 1)
