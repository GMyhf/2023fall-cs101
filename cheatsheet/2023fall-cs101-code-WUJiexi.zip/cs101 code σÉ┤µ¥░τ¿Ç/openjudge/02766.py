'''
2300015897
'''
n = int(input())
info,num = [],[]
while len(info) < n**2:
    info.extend(list(map(int,input().split())))
for i in range(n):
    num.append([x for x in info[n*i:n*(i + 1)]])
dp = [[0]*n for i in range(n)]
dp[0][0] = num[0][0]
