'''
2300015897
吴杰稀
光华管理学院
'''
n =int(input())
position_list = []
for i in range(n):
    a,b= map(int,input().split())
    position_list.append([a,b])
position_list.sort(key = lambda x:x[0])
old = position_list[0][-1]
flag = 1
l = position_list[0][0]
for i in range(1,len(position_list)):
    new = position_list[i][0]
    if new > old:
        print("no")
        flag = 0
        break
    old = max(old,position_list[i][1])
if flag:
    r = old
    print(l,r)