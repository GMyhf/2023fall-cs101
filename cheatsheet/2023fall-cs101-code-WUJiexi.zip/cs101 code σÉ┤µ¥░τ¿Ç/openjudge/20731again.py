'''
2300015897
'''
m,n = map(int,input().split())
num = [[int(x) for x in input().split()] for i in range(m)]
l1,l2 = map(int,input().split())
num[l1 - 1],num[l2 - 1] = num[l2 - 1],num[l1 - 1]
dx,dy = [0,1,0,-1],[1,0,-1,0]
i,j,k = 0,0,0
res = num[0][0]
v = [[False] * n for i in range(m)]
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n:
        return True
    return False
while True:
    nx,ny = i + dx[k],j + dy[k]
    if not is_valid(nx,ny):
        k = (k + 1) % 4
        nx, ny = i + dx[k], j + dy[k]
    v[i][j] = True
    if v[nx][ny] == True:
        break
    res += num[nx][ny]
    i,j = nx,ny
print(res)