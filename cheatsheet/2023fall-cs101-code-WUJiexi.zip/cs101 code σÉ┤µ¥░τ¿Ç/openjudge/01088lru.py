#dfs+lru_cache(dp)，最长路
from functools import lru_cache
r,c=map(int,input().split())
mat=[]
mat.append([10001]*(c+2))
for i in range(r):
    mat.append([10001]+list(map(int,input().split()))+[10001])
mat.append([10001]*(c+2))
dx=[1,-1,0,0]
dy=[0,0,1,-1]
#print(mat)
@lru_cache(maxsize=1024)
def dp(x,y):
    ans=1
    for i in range(4):
        nx=x+dx[i]
        ny=y+dy[i]
        if mat[x][y]>mat[nx][ny]:
            ans=max(ans,1+dp(nx,ny))
    return ans
ans=0
for i in range(1,r+1):
    for j in range(1,c+1):
        ans=max(ans,dp(i,j))
        #print(i,j,dp(i,j))
print(ans)