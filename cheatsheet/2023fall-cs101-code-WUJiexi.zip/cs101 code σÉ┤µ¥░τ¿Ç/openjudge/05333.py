'''
2300015897
'''
import heapq
n = int(input())
l = [int(input()) for i in range(n)]
l.sort()
res = 0
while len(l) > 1:
    a = heapq.heappop(l)
    b = heapq.heappop(l)
    heapq.heappush(l,a + b)
    res += a + b
print(res)
