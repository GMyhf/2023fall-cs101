'''
2300015897
'''
cases = int(input())

for i in range(cases):
    n = int(input())
    time = []
    for j in range(n):
        s,e = map(int,input().split())
        time.append((s, 1))
        time.append((e, -1))
    time.sort()
    mx = 0
    cnt = 0
    for _ in time:
        cnt += _[1]
        mx = max(mx,cnt)
    print(mx)