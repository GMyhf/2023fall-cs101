a=int(input())
b=int(input())
c=f"{a+b}"
l=len(c)
for i in range(l):
    while c[i] == 0:
        c[i] = False
        if c[i] != 0:
            break
print(c)
