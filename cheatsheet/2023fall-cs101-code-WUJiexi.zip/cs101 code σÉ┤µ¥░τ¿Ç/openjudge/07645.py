'''
2300015897
'''
dx,dy = [0,1,0,-1],[1,0,-1,0]
m,n = map(int,input().split())
num = [[int(x) for x in input().split()] for i in range(m)]
v = [[False]*n for i in range(m)]
def is_valid(x,y):
    if 0 <= x < m and 0 <= y < n and not v[x][y]:
        return True
    return False

i,j,k,add_up = 0,0,0,1
while add_up <= m*n:
    print(num[i][j])
    nx,ny = i + dx[k],j + dy[k]
    if not is_valid(nx,ny):
        k = (k + 1) % 4
        nx, ny = i + dx[k], j + dy[k]
    v[i][j] = True
    add_up += 1
    i = nx
    j = ny