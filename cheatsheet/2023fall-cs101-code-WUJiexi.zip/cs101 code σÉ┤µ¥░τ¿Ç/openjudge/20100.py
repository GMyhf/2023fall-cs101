'''
2300015897
'''
n = int(input())
ds = [int(x) for x in input().split()]
t_records = [int(x) for x in input().split()]
ts = [int(x) for x in input().split()]
info = []
for i in range(n - 1):
    d,t_record,t = ds[i],t_records[i],ts[i]
    v_record = d/t_record
    v = d/t
    info.append((v_record,v,t_record,t))

v_max = 0
t_min = 10000
cnt = 0

for _ in info:
    v_record,v,t_record,t = _
    flag = 0
    if v > v_max:
        if v > v_record:
            flag = 1
        v_max = max(v_max,v)
    if t < t_min:
        if t < t_record:
            flag = 1
        t_min = min(t_min,t)
    if flag:
        cnt += 1
print(cnt)