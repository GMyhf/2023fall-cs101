'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    n,m=map(int,input().split())
    if n == 0 and m == 0:
        break
    monkey_list = [i for i in range(1,n+1)]
    while len(monkey_list) != 1:
        t = len(monkey_list)
        monkey_list.remove(monkey_list[m%t-1])

        if m %t == 0:
            monkey_list = monkey_list
        else:
            monkey_list = monkey_list[m%t-1:] + monkey_list[:m%t-1]

    print(monkey_list[0])

