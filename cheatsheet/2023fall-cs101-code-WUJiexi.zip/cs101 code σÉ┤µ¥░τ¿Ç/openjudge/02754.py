'''
2300015897
吴杰稀
光华管理学院
'''
res = []
def recurse(path = [],i = 0,col = [],diag_1 = set(),diag_2 = set()):
    if i == 8:
        res.append(path)
        return
    for j in range(8):
        if j not in col and i - j not in diag_1 and i + j not in diag_2:
            recurse(path + [j + 1],i + 1,col + [j],diag_1|{i - j},diag_2|{i + j})
recurse()
n = int(input())
for i in range(n):
    dex = int(input())
    print(''.join([str(x) for x in res[dex - 1]]))