'''
2300015897
吴杰稀
光华管理学院
'''

def jiecheng(x):
    res = 1
    for i in range(1,x + 1):
        res= res * i
    return res
cases = int(input())
for i in range(cases):
    n,m = map(int,input().split())
    if m - n < n:
        n = m - n
    ans = jiecheng(m) // (jiecheng(n) * jiecheng(m - n))
    print(ans)