money=[]
sum=0
for i in range(12):
    money.append(float(input()))
for i in range(12):
    sum+=money[i]
average=sum/12
print(f"${average:.2f}")