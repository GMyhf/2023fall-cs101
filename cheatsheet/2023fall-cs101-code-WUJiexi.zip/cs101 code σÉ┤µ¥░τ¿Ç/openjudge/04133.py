'''
2300015897
吴杰稀
光华管理学院
'''
def change(x,y,z):
    for i in range(max(0,y - d),min(1025,y + d + 1)):
        for j in range(max(0,x - d),min(1025,x + d + 1)):
            map_list[i][j] += z

d = int(input())
n = int(input())
map_list= [[0] * 1025 for i in range(1025)]
for i in range(n):
    x,y,num = map(int,input().split())
    change(x,y,num)
key = 1
dict_key = {}
for i in range(1025):
    for j in range(1025):
        if map_list[i][j] >= key:
            key = map_list[i][j]
            if key not in dict_key:
                dict_key[key] = 1
            else:
                dict_key[key] += 1
print(dict_key[key],key)


