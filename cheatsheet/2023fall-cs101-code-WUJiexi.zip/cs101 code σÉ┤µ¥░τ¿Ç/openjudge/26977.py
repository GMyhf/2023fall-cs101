'''
2300015897
'''
n = int(input())
height = [0] +[int(x) for x in input().split()] + [0]
maxl,maxr = [height[0]] * (n + 2),[height[-1]] * (n + 2)
for i in range(1,n + 1):
    maxl[i] = max(maxl[i - 1],height[i])
for j in range(n,0,-1):
    maxr[j] = max(maxr[j + 1],height[j])
#print(height)
#print(maxl)
#print(maxr)
res = 0
for i in range(1,n + 1):
    if min(maxl[i],maxr[i]) - height[i] > 0:
        res += min(maxl[i],maxr[i]) - height[i]
print(res)