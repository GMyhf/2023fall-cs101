res = []
def recurse(path = [],i = 0,col = [],diag_1 = set(),diag_2 = set()):
    if i == n:
        res.append(path)
        return
    for j in range(n):
        if j not in col and i - j not in diag_1 and i + j not in diag_2:
            recurse(path + [j],i + 1,col + [j],diag_1|{i - j},diag_2|{i + j})

n = int(input())
recurse()
if res:
    for _ in res:
        print(' '.join([str(x) for x in _]))
else:
    print("NO ANSWER")