'''
2300015897
吴杰稀
光华管理学院
'''
tokens = [x for x in input().split()]
num_stack = []
while tokens:
    tmp = tokens.pop(-1)
    if tmp in ["+","-","*","/"]:
        c = num_stack.pop(-1)
        d = num_stack.pop(-1)
        if tmp == "+":
            num_stack.append(c + d)
        elif tmp == "-":
            num_stack.append(c - d)
        elif tmp == "*":
            num_stack.append(c * d)
        elif tmp == "/":
            num_stack.append(c / d)
    else:
        num_stack.append(float(tmp))

print(f"{num_stack[0]:.6f}")