'''
2300015897
'''
t,n,m = map(int,input().split())
rock = [0] + [int(input()) for i in range(n)] + [t]

l,r = 0,t
mid = (l + r) // 2
while l <= r:
    check = 0
    cnt = 0

    for i in range(1,len(rock)):
        if rock[i] - check < mid:
            cnt += 1
        else:
            check = rock[i]

    if cnt > m:
        r = mid - 1
        mid = (l + r) // 2

    else:
        l = mid + 1
        mid = (l + r) // 2

print(mid)