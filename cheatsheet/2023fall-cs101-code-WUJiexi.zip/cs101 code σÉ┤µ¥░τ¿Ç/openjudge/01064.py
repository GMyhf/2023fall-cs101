'''
2300015897
吴杰稀
光华管理学院
'''
n,k = map(int,input().split())
wires = []
for i in range(n):
    wires.append(100*float(input()))
total_lenth = sum(wires)
if k > total_lenth:
    print("0.00")
else:
    start = 1
    end = int(total_lenth/k)+1
    while end - start > 1:
        mid = (start+end)/2
        add_up = 0
        for _ in wires:
            add_up += _ // mid
        if add_up < k:
            end = int(mid)
        else:
            start = int(mid)
    print(f"{start/100:.2f}")
