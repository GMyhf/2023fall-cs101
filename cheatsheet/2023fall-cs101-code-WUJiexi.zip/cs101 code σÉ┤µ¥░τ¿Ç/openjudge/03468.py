'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    try:
        n = int(input())
        time_list = [int(x) for x in input().split()]
        time_list.sort()
        if n == 2:
            print(f"{time_list[0]:.1f}")
        else:
            temp = 0
            for i in range(n - 1):
                temp += time_list[i]
            if temp >= time_list[-1]:
                ans = (temp + time_list[-1])/2
                print(f"{ans:.1f}")
            else:
                ans = temp
                print(f"{temp:.1f}")
    except:
        break