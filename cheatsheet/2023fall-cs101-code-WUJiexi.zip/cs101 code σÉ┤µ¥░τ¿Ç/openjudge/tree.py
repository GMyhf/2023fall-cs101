l,y =input().split()
L=int(l)
M=int(y)
liebiao=[m for m in range(L+1)]

for i in range(M):
    S,E=input().split()
    s=int(S)
    e=int(E)

    for j in range(s,e+1):
        liebiao[j]=-1

n=liebiao.count(-1)

tree=L+1-n
print(tree)