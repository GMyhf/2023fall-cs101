'''
2300015897
光华管理学院
'''
n, m = map(int, input().split())
shopping_list = {}
total_money = 0
for i in range(n):
    num, cost = map(int, input().split())
    if num in shopping_list:
        shopping_list[num] += cost
    else:
        shopping_list[num] = cost
    total_money += cost
discount_list = []
for i in range(m):
    j = 0
    string = str(input())
    while string[j] != "-":
        j += 1
        if j == len(string) - 1:
            break
    discount_list.append([string[:j], string[j + 1:]])
discount_money = 0
discount_money += total_money // 200 * 30

for keys,values in shopping_list.items():
    if values >= int(discount_list[keys - 1][0]):
        discount_money += int(discount_list[keys - 1][1])


print(total_money - discount_money)