'''
2300015897
吴杰稀
光华管理学院
'''
while True:
    dic = {}
    for i in range(10):
        dic[i] = 0
    s = input()
    if not s:
        break
    for i in range(len(s)):
        if s[i] in "0123456789":
            dic[int(s[i])] += 1
    for key,value in dic.items():
        if value != 0:
            print(f"{key}:{value}")