'''
2300015897
吴杰稀
光华管理学院
'''
s = [x for x in input()]
res = []
tmp = ''
flag = 0
for i in range(len(s)):
    if s[i] in "1234567890":
        tmp += s[i]
        flag = 1
    else:
        flag = 0
        if tmp:
            res.append(int(tmp))
            tmp = ''
if flag == 1:
    res.append(int(tmp))
for _ in res:
    print(_)