'''
2300015897
吴杰稀
光华管理学院
'''
length = int(input())
value_list = list(map(int,input().split()))
value = [0] * length
add_up = 0
for i in range(length):
    add_up += value_list[i]
    value[i] = add_up
res = 520
for i in range(length):
    if i != 0:
        for j in range(i,length):
            value[j] = value[j] - value_list[i - 1]
    for j in range(length):
        if value[j] % 520 == 0:
            if value[j] > res:
                res = value[j]
print(res)
