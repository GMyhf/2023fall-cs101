'''
2300015897
'''
n,w = map(int,input().split())
skill = sum(list(map(int,input().split())))
can_kill = []
for i in range(n):
    x,y = map(int,input().split())
    if skill >= x:
        can_kill.append(y)
can_kill.sort()
print(can_kill)
add_up = 0
k = 0
for _ in can_kill:
    add_up += _
    if add_up > w:
        break
    k += 1
print(k)