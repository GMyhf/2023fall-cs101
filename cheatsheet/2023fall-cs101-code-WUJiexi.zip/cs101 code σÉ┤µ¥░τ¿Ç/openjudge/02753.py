'''
2300015897
吴杰稀
光华管理学院
'''
#构建斐波那契数列
num_list = [1,1]
i = 1
j = 1
while True:
    j += num_list[i-1]
    num_list.append(j)
    i += 1
    if i == 21:
        break

cases = int(input())
for i in range(cases):
    rank = int(input())
    print(num_list[rank-1])