'''
2300015897
'''
n,m = map(int,input().split())
h = [[0]*(m + 2)]
for i in range(n):
    h += [[0] + [int(x) for x in input().split()] + [0]]
h += [[0]*(m + 2)]
l,r,up,down = [[0]*(m + 2) for i in range(n + 2)],[[0]*(m + 2) for i in range(n + 2)],\
    [[0]*(m + 2) for i in range(n + 2)],[[0]*(m + 2) for i in range(n + 2)]
for i in range(1,n + 1):
    for j in range(1,m + 1):
        l[i][j] = max(l[i][j - 1],h[i][j])
    for j in range(m,0,-1):
        r[i][j] = max(r[i][j + 1],h[i][j])
for j in range(1,m + 1):
    for i in range(1,n + 1):
        up[i][j] = max(up[i - 1][j],h[i][j])
    for i in range(n,0,-1):
        down[i][j] = max(down[i + 1][j],h[i][j])
res = 0
for i in range(1,n + 1):
    for j in range(1,m + 1):
        if h[i][j] < min(l[i][j],r[i][j],up[i][j],down[i][j]):
            res += min(l[i][j],r[i][j],up[i][j],down[i][j]) - h[i][j]
print(res)