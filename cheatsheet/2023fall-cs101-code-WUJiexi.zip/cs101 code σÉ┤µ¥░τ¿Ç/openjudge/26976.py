'''
2300015897
吴杰稀
光华管理学院
'''
l =int(input())
num_list = list(map(int,input().split()))
now = num_list[0]
if l < 2:
    print("1")
else:
    res = 1
    type = 0
    for i in range(1,l):
        if type == 1:
            if num_list[i] - now > 0:
                now = num_list[i]
            elif num_list[i] - now < 0:
                type = -1
                res += 1
                now = num_list[i]
        elif type == -1:
            if num_list[i] - now < 0:
                now = num_list[i]
            elif num_list[i] - now > 0:
                type = 1
                res += 1
                now = num_list[i]
        else:
            if num_list[i] - now > 0:
                type = 1
                res += 1
                now = num_list[i]
            elif  num_list[i] - now < 0:
                type = -1
                res += 1
                now = num_list[i]
    print(res)


