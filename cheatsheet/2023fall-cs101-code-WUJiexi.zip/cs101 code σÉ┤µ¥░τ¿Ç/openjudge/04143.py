'''
2300015897
'''
n = int(input())
array = [int(x) for x in input().split()]
array.sort()
t = int(input())
l,r = 0,n - 1
flag = 0
while l < r:
    if array[l] + array[r] > t:
        r -= 1
    elif array[l] + array[r] < t:
        l += 1
    else:
        flag = 1
        break
if flag == 1:
    print(array[l],array[r])
else:
    print("No")