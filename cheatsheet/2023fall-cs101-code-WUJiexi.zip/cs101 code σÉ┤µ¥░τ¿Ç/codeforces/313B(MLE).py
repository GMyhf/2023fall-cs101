'''
2300015897
吴杰稀
光华管理学院
'''
string = "0" + str(input())
length = len(string)
dp = [[0] * len(string) for i in range(len(string))]
i = length - 2
while i >= 1:
    for j in range(i + 2,len(string)):
        dp[i][j] += dp[i + 1][j]
    if string[i] == string[i + 1]:
        for j in range(i + 1,len(string)):
            dp[i][j] += 1
    i -= 1
cases = int(input())
for i in range(cases):
    l,r = map(int,input().split())
    print(dp[l][r])