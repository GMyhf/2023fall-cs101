for t in range(int(input())):
    str = input()
    if str == "()":
        print("NO")
        continue
    print("YES")