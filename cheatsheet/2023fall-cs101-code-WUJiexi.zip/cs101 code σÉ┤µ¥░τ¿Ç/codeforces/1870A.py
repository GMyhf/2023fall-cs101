cases = int(input())
for i in range(cases):
    n,k,x = map(int,input().split())
    if k - 2 >= x or k > n:
        print("-1")
    else:
        add_up = 0
        if n == k:
            add_up = int((k-1)*k/2)
        else:
            add_up += int((k-1)*k/2)
            left_numbers = n - k
            if k != x:
                add_up += left_numbers * x
            else:
                add_up += left_numbers * (x-1)
        print(add_up)
