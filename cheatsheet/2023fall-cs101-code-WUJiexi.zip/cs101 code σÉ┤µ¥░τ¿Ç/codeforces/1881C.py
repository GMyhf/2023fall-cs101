'''
2300015897
吴杰稀
光华管理学院
'''
def caculator(word_list):
    ans = 0
    i = 0
    for x in range(n//2):
        for y in range(n//2):
            t = max(ord(word_list[x][y]),ord(word_list[n - y - 1][x]),ord(word_list[n - x - 1][n - y - 1]),ord(word_list[y][n - x - 1]))
            ans += 4*t - ord(word_list[x][y]) - ord(word_list[n - y - 1][x]) - ord(word_list[n - x - 1][n - y - 1]) - ord(word_list[y][n - x - 1])
    return ans
cases= int(input())
res = []
for i in range(cases):
    n = int(input())
    shuru = []
    for i in range(n):
        shuru.append([x for x in input()])
    res.append(caculator(shuru))
for _ in res:
    print(_)