'''
2300015897
'''
n = int(input())
h1 = [int(x) for x in input().split()]
h2 = [int(x) for x in input().split()]
dp = [[0]*3 for i in range(n + 1)]
for i in range(1,n + 1):
    dp[i][0] = max(dp[i - 1][1],dp[i - 1][2])
    dp[i][1] = max(dp[i - 1][0],dp[i - 1][2]) + h1[i - 1]
    dp[i][2] = max(dp[i - 1][0],dp[i - 1][1]) + h2[i - 1]
print(max(dp[n]))