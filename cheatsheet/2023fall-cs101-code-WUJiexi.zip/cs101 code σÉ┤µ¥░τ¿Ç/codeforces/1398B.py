n = int(input())
for i in range(n):
    s = input()
    list = []
    sum = 0
    for j in range(len(s)):
        if s[j] == "0":
            list.append(sum)
            sum=0
        elif s[j] == "1" and j != len(s)-1:
            sum+=1
        elif s[-1] == "1":
            sum += 1
            list.append(sum)
    if list!=[]:
        if 0 in list:
            list.remove(0)
        list.sort(reverse = True)

        add_up = 0
        for m in range(len(list)):
            if m%2 == 0:
                add_up += list[m]

        print(add_up)
    else:
        print("0")
