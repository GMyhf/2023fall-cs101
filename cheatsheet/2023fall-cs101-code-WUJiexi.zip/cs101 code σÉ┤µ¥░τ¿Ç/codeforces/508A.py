'''
2300015897
吴杰稀
光华管理学院
'''
def matrix_break(i,j):
    if matrix[i][j] == matrix[i-1][j-1] == matrix[i][j-1] == matrix[i-1][j] == 1:
        return True
    elif matrix[i][j] == matrix[i+1][j+1] == matrix[i][j+1] == matrix[i+1][j] == 1:
        return True
    elif matrix[i][j] == matrix[i-1][j+1] == matrix[i][j+1] == matrix[i-1][j] == 1:
        return True
    elif matrix[i][j] == matrix[i+1][j-1] == matrix[i][j-1] == matrix[i+1][j] ==1:
        return True
    else:
        return False

row, column, cases = map(int, input().split())
#避免index out of range
matrix = [[0]*(column + 2) for i in range(row + 2)]
moves = 0
flag = 1
while moves < cases:
    moves += 1
    a,b = map(int,input().split())
    matrix[a][b] = 1
    if matrix_break(a,b):
        flag = 0
        break
if flag == 0:
    print(moves)
else:
    print("0")

