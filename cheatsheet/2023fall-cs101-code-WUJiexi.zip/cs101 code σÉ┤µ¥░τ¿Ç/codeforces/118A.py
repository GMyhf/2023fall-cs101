'''
2300015897
吴杰稀
光华管理学院
'''
vowels = ["a","o","y","e","u","i"]
str_1 = input()
str_1 = str_1.lower()
new_str=""
for _ in str_1:
    if _ not in vowels:
        new_str += "."
        new_str += _
print(new_str)