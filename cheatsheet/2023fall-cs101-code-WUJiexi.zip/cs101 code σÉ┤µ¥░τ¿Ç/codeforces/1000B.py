'''
2300015897
吴杰稀
光华管理学院
'''
n, m = map(int, input().split())
a = [0] + [int(x) for x in input().split()] + [m]
tot = ans = s = 0
for i in range(1, len(a), 2):
    tot += a[i] - a[i-1]
ans = tot         #总开灯时间
for i in range(2, len(a), 2):
    s += a[i-1] - a[i-2]   #前 i 次开灯时间
    if a[i] > a[i-1] + 1:   #若关灯时长大于 1
        t = tot -s     #导出后 n-i 次开灯时间
        ans = max(ans, s + m-a[i-1]-t - 1) #之前奇数项+之后偶数项-1
print(ans)
