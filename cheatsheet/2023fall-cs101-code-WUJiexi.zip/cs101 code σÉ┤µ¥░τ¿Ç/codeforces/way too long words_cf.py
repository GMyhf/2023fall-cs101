'''
2300015897
吴杰稀
光华管理学院
'''
n=int(input())

list=[]

for i in range(n):
    list.append(input())

for str in list:
    if len(str) <= 10:
        print(str)
    else:
        print(f"{str[0]}"+f"{len(str)-2}"+f"{str[-1]}")