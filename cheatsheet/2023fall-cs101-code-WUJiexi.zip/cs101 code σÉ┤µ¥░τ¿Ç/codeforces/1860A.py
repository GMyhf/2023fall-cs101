cases = int(input())
for _ in range(cases):
    brackets = input()
    if brackets == "()":
        print("NO")
    else:
        if "((" in brackets or "))" in brackets:
            new_string = "()"*len(brackets)
        else:
            new_string = "("*len(brackets) + ")"*len(brackets)
        print("YES")
        print(new_string)