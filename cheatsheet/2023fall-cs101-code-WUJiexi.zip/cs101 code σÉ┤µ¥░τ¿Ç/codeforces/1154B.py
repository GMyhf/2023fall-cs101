n = int(input())
num = list(map(int,input().split()))
num.sort()
minus = []
num_set = set(num)
if len(num_set) >= 4:
    print(-1)
elif len(num_set) == 1:
    print(0)
else:
    for i in range(n-1):
        t = num[i+1] - num[i]
        if t != 0:
            minus.append(t)
    minus_set = set(minus)

    if len(num_set) == 2:
        if minus[0] % 2 == 0:
            print(f"{minus[0] // 2}")
        else:
            print(minus[0])
    else:
        if len(minus_set) == 1:
            print(minus[0])
        else:
            print(-1)
