'''
2300015897
吴杰稀
光华管理学院
'''
string = "0" + str(input())
length = len(string)
#只考虑1到n之间构成的对数，则n,m之间用m-n即可
dp = [0] * length
for i in range(2,len(string)):
    if string[i] == string[i - 1]:
        dp[i] += 1
    dp[i] += dp[i-1]

cases = int(input())
for i in range(cases):
    l,r = map(int,input().split())
    print(dp[r] - dp[l])