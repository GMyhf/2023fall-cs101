'''
2300015897
吴杰稀
光华管理学院
'''
choices = int(input())
shops = list(map(int,input().split()))
shops.sort()
t = max(shops)

j = 0
budgets = []
while j <= choices - 1:
    if j == 0:
        budgets += [j] * shops[j]
    else:
        budgets += [j] * (shops[j] - shops[j - 1])
    j += 1
budgets.append(choices)

cases = int(input())
for i in range(cases):
    money = int(input())
    if money > t:
        print(choices)
    else:
        print(budgets[money])