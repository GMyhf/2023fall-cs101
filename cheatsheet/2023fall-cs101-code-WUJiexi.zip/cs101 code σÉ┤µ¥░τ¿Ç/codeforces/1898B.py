'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    l =int(input())
    num_list = [int(x) for x in input().split()]
    ans = 0
    old = num_list[-1]
    for i in range(l - 2,-1,-1):
        if num_list[i] > old:
            if num_list[i] % old != 0:
                times = num_list[i] // old + 1
                old = int(num_list[i] / times)
            else:
                times = num_list[i] // old
            ans += times - 1
        else:
            old = num_list[i]
    print(ans)