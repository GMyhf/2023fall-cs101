'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
num_list = list(map(int,input().split()))
num_list.sort()
i = 0
happy_num  = 0
total_time = 0
while i <= len(num_list) - 1:
    if num_list[i] >= total_time:
        total_time += num_list[i]
        happy_num += 1
    i += 1
print(happy_num)
