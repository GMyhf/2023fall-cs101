'''
2300015897
吴杰稀
光华管理学院
'''
total_list = []
import math

for i in range(5):
    list1 = list(map(int,input().split()))
    line_add_up = sum(list1)
    if line_add_up == 1:
        y_position = i
    total_list.append(list1)

for i in range(5):
    row_add_up = total_list[0][i] + total_list[1][i] + total_list[2][i] + \
                 total_list[3][i] + total_list[4][i]
    if row_add_up == 1:
        x_position = i

times = abs(x_position - 2) + abs(y_position - 2)
print(times)