'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
res = []
for i in range(cases):
    length = int(input())
    delivery = list(map(int,input().split()))
    personal = list(map(int, input().split()))
    if length == 1:
        res.append(min(delivery[0],personal[0]))
    else:
        combination = list(zip(delivery,personal))
        combination.sort(reverse = True)
        time = combination[0][1]
        ans = combination[0][0]
        if time < ans:
            for i in range(1,length):
                time += combination[i][1]
                if time >= combination[i][0]:
                    ans = max(time - combination[i][1],combination[i][0])
                    break
                ans = time
        res.append(ans)
for _ in res:
    print(_)