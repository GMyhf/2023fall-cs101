'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    s = int(input())
    monster_list = list(map(int,input().split()))
    monster_list.sort()
    add_up = sum(monster_list)
    mid = add_up // 2
    if add_up % 2 != 0:
        mid += 1

    cur_s = 0
    ans = 0
    for i in range(s):
        cur_s += monster_list[i]
        if cur_s >= mid:
            ans = mid + (s - i - 1)
            if mid < cur_s:
                ans += 1
            break

    print(ans)

