zero_list = []
one_list = []
num_str = input()
zero,one = 1,1
i = 0
while True:
    if i + 1 == len(num_str):
        if num_str[-1] == "1":
            one_list.append(one)
        else:
            zero_list.append(zero)
        break
    if num_str[i+1] == num_str[i] and num_str[i] == "0":
        zero += 1
    elif num_str[i+1] == num_str[i] and num_str[i] == "1":
        one += 1
    elif num_str[i+1] == "1" and num_str[i] == "0":
        zero_list.append(zero)
        zero = 1
    else:
        one_list.append(one)
        one = 1
    i += 1
new_list = zero_list + one_list
flag = 0
for _ in new_list:
    if int(_) >= 7:
        flag += 1
if flag == 0:
    print("NO")
else:
    print("YES")