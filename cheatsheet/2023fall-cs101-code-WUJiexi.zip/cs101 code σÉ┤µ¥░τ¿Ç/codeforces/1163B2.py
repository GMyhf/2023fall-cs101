'''
2300015897
'''
dic = {}
n = int(input())
color = [int(x) for x in input().split()]
res = 1
mx = 0
cnt = 1
different = 0
dic = {}
for i in range(n):
    if color[i] not in dic:
        different += 1
    dic[color[i]] = dic.get(color[i],0) + 1
    if dic[color[i]] > mx:
        mx = dic[color[i]]
        cnt = 1
    elif dic[color[i]] == mx:
        cnt += 1

    if mx == 1:
        res = i + 1
    if cnt == 1 and different*(mx - 1) == i:
        res = i + 1
    if cnt == different - 1 and (different - 1)*mx == i:
        res = i + 1
print(res)

