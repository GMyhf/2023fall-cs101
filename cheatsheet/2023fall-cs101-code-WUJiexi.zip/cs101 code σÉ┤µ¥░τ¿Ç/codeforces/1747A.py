cases = int(input())
for i in range(cases):
    lenth = input()
    num_list = list(map(int,input().split()))
    s1 = 0
    s2 = 0
    for _ in num_list:
        if _ >0:
            s1 += _
        else:
            s2 += _
    if s1 + s2 > 0:
        print(s1 + s2)
    else:
        print(-s1 - s2)