'''
2300015897
吴杰稀
光华管理学院
'''
n,m = map(int,input().split())
num_list = list(map(int,input().split()))
original_list = []
for i in range(m):
    original_list.append(int(input()))
times_list = []
num_dict = {}
l = n - 1
add_up = 0
while l >= 0:
    if num_list[l] not in num_dict:
        num_dict[num_list[l]] = 1
        add_up += 1
    times_list.append(add_up)
    l -= 1

for i in original_list:
    print(times_list[-i])
