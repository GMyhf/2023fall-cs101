week = ["A","B","C","A","C","B","A"]
def min(x,y,z):
    element_list = [x,y,z]
    min = element_list[0]
    for i in range(2):
        if element_list[i + 1] < min:
            min = element_list[i + 1]
    return min
a,b,c = map(int,input().split())
#处理数据
if b > c:
    if b > c + 2:
        b = c + 2
if c > b:
    if c > b + 2:
        c = b + 2
if a > int(1.5*b) + 2:
    a = int(1.5*b) + 2
if b > int(2*a/3) + 2:
    b = int(2*a/3) + 2
if a > int(1.5*c) + 2:
    a = int(1.5*c) + 2
if c > int(2*a/3) + 2:
    c = int(2*a/3) + 2

list_abc = [a,b,c]

t = min(list_abc[0]//3,list_abc[1]//2,list_abc[2]//2)
list_abc[0] = list_abc[0] - 3*t
list_abc[1] = list_abc[1] - 2*t
list_abc[2] = list_abc[2] - 2*t
day_list = []

for j in range(7):
    a,b,c = list_abc[0],list_abc[1],list_abc[2]
    days = 7*t
    while True:
        if week[j%7] == "A":
            a -= 1
            if a >= 0:
                days += 1
                j += 1
            else:
                break
        elif week[j%7] == "B":
            b -= 1
            if b >= 0:
                days += 1
                j += 1
            else:
                break
        elif week[j%7] == "C":
            c -= 1
            if c >= 0:
                days += 1
                j += 1
            else:
                break
    day_list.append(days)
day_list.sort()
print(day_list[-1])