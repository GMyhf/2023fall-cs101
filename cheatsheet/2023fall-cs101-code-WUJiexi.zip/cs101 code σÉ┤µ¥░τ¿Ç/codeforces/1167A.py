times = int(input())
for i in range(times):
    m= input()
    n=list(input())
    m = int(m)
    if m<11:
        print("NO")
    elif m == 11 and n[0] != "8":
        print("NO")
    elif m == 11 and n[0] == "8":
        print("YES")
    else:
        n.reverse()
        new_list=n[10:]
        if "8" not in new_list:
            print("NO")
        else:
            print("YES")
