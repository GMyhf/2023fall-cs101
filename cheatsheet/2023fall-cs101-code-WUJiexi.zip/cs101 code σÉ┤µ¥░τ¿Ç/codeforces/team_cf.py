n=int(input())

flag=0

for i in range(n):
    a,b,c=map(int,input().split())
    t=a+b+c
    if t >= 2:
        flag+=1

print(flag)
