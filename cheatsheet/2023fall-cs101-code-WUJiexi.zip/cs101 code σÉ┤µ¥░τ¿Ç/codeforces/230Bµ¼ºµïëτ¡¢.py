import math
def oulashai(n):
    prime = []
    is_prime = [True] * (n + 1)
    for i in range(2,n + 1):
        if is_prime[i]:
            prime.append(i)
        for j in range(len(prime)):
            if i * prime[j] > n:
                break
            is_prime[i * prime[j]] = False
            if i % prime[j] == 0:
                break
    return prime

new_set = set(oulashai(10**6))
cases = int(input())
num_list = list(map(int,input().split()))
for i in range(cases):
    if math.sqrt(num_list[i]) == int(math.sqrt(num_list[i])) and int(math.sqrt(num_list[i])) in new_set:
        print("YES")
    else:
        print("NO")