'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
num_list = list(map(int,input().split()))
dp = [0] * (max(num_list) + 2)
times = [0] * (max(num_list) + 2)
for _ in num_list:
    times[_] += _
dp[1] = times[1]
for i in range(2,max(num_list) + 2):
    dp[i] = max(dp[i - 1],dp[i - 2] + times[i])
print(dp[-1])