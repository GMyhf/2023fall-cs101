'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    n,x = map(int,input().split())
    array = list(map(int,input().split()))
    if sum(array) % x != 0:
        print(n)
    else:
        left,right = 0,0
        #left:
        for i in range(len(array)):
            if array[i] % x != 0:
                left = n - (i + 1)
                break
        #right:
        for j in range(len(array)-1,-1,-1):
            if array[j] % x != 0:
                right = j
                break
        if max(left,right) != 0:
            print(max(left,right))
        else:
            print("-1")

