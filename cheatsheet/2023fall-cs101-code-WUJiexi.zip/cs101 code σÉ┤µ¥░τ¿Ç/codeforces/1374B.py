cases = int(input())
for i in range(cases):
    n = int(input())
    if n == 1:
        print("0")
    else:
        #计算有几个三作为因子
        add_3 = 0
        t_3 = n
        while t_3 % 3 == 0:
            add_3 += 1
            t_3 = t_3 // 3

        add_2 = 0
        t_2 = n
        while t_2 % 2 == 0:
            add_2 += 1
            t_2  = t_2 // 2
        if n // ((2 ** add_2) * (3 ** add_3)) == 1:
            if add_3 < add_2:
                print("-1")
            else:
                total_times = add_3 + add_3 - add_2
                print(total_times)
        else:
            print("-1")