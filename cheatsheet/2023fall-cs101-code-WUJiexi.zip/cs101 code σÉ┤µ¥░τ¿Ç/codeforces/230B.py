'''
2300015897
吴杰稀
光华管理学院
'''
def exactly_divided(x,y):
    if x % y == 0:
        return True
    else:
        return False

def is_prime(x):
    if x < 2:
        return False
    else:
        for i in range(2,int(x**(1/2))+1):
            if exactly_divided(x,i):
                return False
        return True

cases = int(input())
num_list = list(map(int,input().split()))
for _ in num_list:
    if _ == 1:
        print("NO")
    elif _ == (int(_**0.5))**2:
        if int(_**0.5) <= 10:
            if is_prime(int(_**0.5)):
                print("YES")
            else:
                print("NO")
        elif int(_**0.5) > 10 and str(int(_**0.5))[-1] not in {"0","2","4","5","6","8"}:
            if is_prime(int(_**0.5)):
                print("YES")
            else:
                print("NO")
        else:
            print("NO")
    else:
        print("NO")




