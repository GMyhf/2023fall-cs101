'''
2300015897
吴杰稀
光华管理学院
'''
n,a,b,c = map(int,input().split())
length_list = list({a,b,c})
length_list.sort()
l = len(length_list)

package = [[0] * (n + 1) for i in range(l + 1)]
for j in range(1,n + 1):
    for i in range(1,l + 1):
        if j == length_list[i - 1]:
            package[i][j] = 1
        elif j > length_list[i - 1]:
            add = 0
            for k in range(l):
                if package[k + 1][j - length_list[i - 1]] > add:
                    add = package[k + 1][j - length_list[i - 1]]
            if add != 0:
                package[i][j] = 1 + add
res = 0
for k in range(l):
    if package[k + 1][-1] > res:
        res = package[k + 1][-1]
print(res)