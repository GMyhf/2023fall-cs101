'''
2300015897
吴杰稀
光华管理学院
'''
def exam(a,b):
    new_string = a + b
    add_up = 0
    for _ in range(t//2):
        add_up += int(new_string[_])
    if add_up == flag // 2:
        return True
    else:
        return False

l = int(input())
ans = l
ticket_pieces = list(map(int,input().split()))
pieces_string = [str(_) for _ in ticket_pieces]
odd,even = [],[]

for i in range(l):
    add_up = 0
    for _ in pieces_string[i]:
        add_up += int(_)
    t = len(pieces_string[i])
    if t % 2 == 0:
        even.append([pieces_string[i],t,add_up])
    else:
        odd.append([pieces_string[i],t,add_up])
#预处理结束

len_list = [even,odd]
for k in len_list:
    l = len(k)
    for i in range(-2,-l - 1,-1):
        for j in range(l + i + 1,l):
            t = k[i][1] + k[j][1]
            flag = k[i][2] + k[j][2]
            if flag % 2 == 0:
                if exam(k[i][0],k[j][0]):
                    ans += 1
                if exam(k[j][0],k[i][0]):
                    ans += 1
print(ans)
