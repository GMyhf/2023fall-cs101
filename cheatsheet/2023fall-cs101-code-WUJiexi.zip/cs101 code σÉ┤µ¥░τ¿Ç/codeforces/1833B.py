cases = int(input())
for i in range(cases):
    n,k = map(int,input().split())
    a = list(map(int,input().split()))
    b = list(map(int, input().split()))
    a = [[a[i],i] for i in range(n)]
    a.sort()
    b.sort()
    final = [0]*n
    for i in range(n):
        final[a[i][1]] = b[i]
    print(*final)