'''
2300015897
吴杰稀
光华管理学院
'''
#参考Huang Yuansen
s = int(input())
num_list = list(map(int,input().split()))

if sum(num_list) % 3 != 0:
    print(0)
else:
    solutions = 0
    t = sum(num_list) // 3
    l_points = []
    l_sum,r_sum = 0,0
    for i in range(s):
        l_sum += num_list[i]
        if l_sum == t:
            l_points.append(i)
    #运用dp数组，省去判断r和l大小关系的时间，用打表来减少时间
    dp = [0] * s
    for j in range(-1,- s - 1,-1):
        r_sum += num_list[j]
        if r_sum == t:
            dp[j] += 1

    for i in range(-2,- s - 1,-1):
        dp[i] += dp[i + 1]

    for _ in l_points:
        if _ < s - 2:
            solutions += dp[_ + 2]
    print(solutions)