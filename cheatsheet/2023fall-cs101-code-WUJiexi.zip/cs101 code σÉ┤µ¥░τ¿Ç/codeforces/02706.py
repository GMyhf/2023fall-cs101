'''
2300015897
'''
p = int(input())
t = pow(2,p) - 1
l = len(str(t))
mod = t % (10**500)

ans = ['0']*(500 - l) + [x for x in str(t)]
print(l)
for i in range(10):
    print(''.join(ans[50*i:50*(i + 1)]))