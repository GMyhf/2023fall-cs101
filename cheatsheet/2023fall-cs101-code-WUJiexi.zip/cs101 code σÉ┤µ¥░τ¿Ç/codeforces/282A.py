'''
2300015897
吴杰稀
光华管理学院
'''

lines = int(input())
sum = 0
for i in range(lines):
    operation = input()
    ope_list = [_ for _ in operation]
    ope_list.remove("X")
    code = ''.join(ope_list)
    if code == "++":
        sum += 1
    else:
        sum -= 1
print(sum)