'''
2300015897
'''
n,t = map(int,input().split())
p = [int(x) for x in input().split()]
l = sum(p)
if l < t:
    print("0")
else:
    p.sort()
    dp = [[0]*(l + 1) for i in range(n + 1)]
    res = l

    for i in range(n + 1):
        dp[i][0] = 1

    for i in range(1,n + 1):
        for j in range(1, l + 1):
            dp[i][j] = dp[i - 1][j]
            if j == p[i - 1]:
                dp[i][j] = 1
            elif j > p[i - 1]:
                if dp[i - 1][j] != 0 or dp[i - 1][j - p[i - 1]] != 0:
                    dp[i][j] = 1
            if j >= t and dp[i][j]:
                res = min(res,j)
                break
    print(res)




