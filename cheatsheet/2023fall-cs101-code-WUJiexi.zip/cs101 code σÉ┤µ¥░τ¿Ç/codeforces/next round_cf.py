'''
2300015897
吴杰稀
光华管理学院
'''

n,k=map(int,input().split())

list=list(map(int,input().split()))

line=list[k-1]

sum=0

for _ in list:
    if _>0 and _ >= line:
        sum+=1

print(sum)
