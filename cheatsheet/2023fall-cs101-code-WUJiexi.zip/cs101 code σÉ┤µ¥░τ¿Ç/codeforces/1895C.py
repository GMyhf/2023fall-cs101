'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
numbers = [k for k in input().split()]
dic = {}
for _ in numbers:
    s,w = 0,0
    w = len(_)
    for number in _:
        s += int(number)
    dic[(w,s)] = dic.get((w,s),0) + 1
ans = 0
for i in range(n):
    s = 0
    w = len(numbers[i])
    for number in numbers[i]:
        s += int(number)
    ans += dic.get((w,s),0)
    if w >= 3:
        ans += dic.get((w - 2,s - 2 * int(numbers[i][0])),0)
        ans += dic.get((w - 2,s - 2 * int(numbers[i][-1])),0)
        if w == 5:
            ans += dic.get((1,s - 2 * (int(numbers[i][0]) + int(numbers[i][1]))),0)
            ans += dic.get((1,s - 2 * (int(numbers[i][-1]) + int(numbers[i][-2]))),0)
print(ans)

