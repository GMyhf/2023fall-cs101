n,m = map(int,input().split())
value_list = list(map(int,input().split()))
value_list.sort()
add_up = 0
for i in range(m):
    if value_list[i] < 0:
        add_up -= value_list[i]
print(add_up)