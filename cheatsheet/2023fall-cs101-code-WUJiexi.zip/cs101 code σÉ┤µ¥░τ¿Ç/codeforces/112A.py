'''
2300015897
吴杰稀
光华管理学院
'''


str1=input()
str2=input()
str1=str1.lower()
str2=str2.lower()
if str1>str2:
    print(1)
elif str1==str2:
    print(0)
else:
    print(-1)
