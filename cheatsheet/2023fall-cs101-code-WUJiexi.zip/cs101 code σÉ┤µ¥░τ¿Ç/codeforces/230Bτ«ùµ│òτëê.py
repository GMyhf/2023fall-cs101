'''
2300015897
吴杰稀
光华管理学院
'''
from random import randrange
def checkcomposite(a,k,d,n):
    x = pow(a,d,n)
    if x == 1 or x == n - 1:
        return False
    for _ in range(k-1):
        x = pow(x,2,n)
        if x == n - 1:
            return False
    return True
def miller_rabin(n):
    if n == 2 or n == 3:
        return True
    if n % 2 == 0:
        return False
    k = 0
    d = n - 1
    while d % 2 == 0:
        k += 1
        d = d//2
    for _ in range(2):
        a = randrange(2,n - 1)
        if (checkcomposite(a,k,d,n)):
            return False
    return True

cases = int(input())
num_list = list(map(int,input().split()))
for _ in num_list:
    if _ == 1:
        print("NO")
    elif _ == (int(_**0.5))**2:
        if int(_**0.5) <= 10:
            if miller_rabin(int(_**0.5)):
                print("YES")
            else:
                print("NO")
        elif int(_**0.5) > 10 and str(int(_**0.5))[-1] not in {"0","2","4","5","6","8"}:
            if miller_rabin(int(_**0.5)):
                print("YES")
            else:
                print("NO")
        else:
            print("NO")
    else:
        print("NO")

