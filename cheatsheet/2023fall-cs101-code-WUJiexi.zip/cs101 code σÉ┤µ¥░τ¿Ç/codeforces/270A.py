'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    angle = int(input())
    t = 180 - angle
    if 360 % t == 0 and 360 // t >= 3:
        print("YES")
    else:
        print("NO")