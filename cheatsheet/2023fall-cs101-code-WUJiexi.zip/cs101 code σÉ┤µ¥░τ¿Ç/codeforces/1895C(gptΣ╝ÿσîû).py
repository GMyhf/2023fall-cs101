def exam(a,b):
    new_string = str(a) + str(b)
    add_up = 0
    for char in new_string:
        add_up += int(char)
    return add_up == flag // 2

l = int(input())
dp = [0] * l
dp[0] += l
ticket_pieces = list(map(int,input().split()))
ticket_pieces_strings = [str(num_ticket) for num_ticket in ticket_pieces]

for i in range(l):
    add_up = 0
    for char in ticket_pieces_strings[i]:
        add_up += int(char)
    ticket_pieces[i] = [ticket_pieces[i], len(ticket_pieces_strings[i]), add_up]

for i in range(-2, -l-1, -1):
    for j in range(l-i-1, l):
        t = ticket_pieces[i][1] + ticket_pieces[j][1]
        flag = ticket_pieces[i][2] + ticket_pieces[j][2]
        if t % 2 == 0 and flag % 2 == 0:
            if exam(ticket_pieces[i][0],ticket_pieces[j][0]):
                dp[i] += 1
            if exam(ticket_pieces[j][0],ticket_pieces[i][0]):
                dp[i] += 1
    dp[i] += dp[i + 1]

print(dp[0])