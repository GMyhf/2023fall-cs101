'''
2300015897
吴杰稀
光华管理学院
'''
def two_pointers(num):
    l,r = 0,len(num) - 1
    min_num,max_num = 1,len(num)
    while l < r:
        if num[l] == min_num:
            l += 1
            min_num += 1
        elif num[l] == max_num:
            l += 1
            max_num -= 1
        elif num[r] == min_num:
            r -= 1
            min_num += 1
        elif num[r] == max_num:
            r -= 1
            max_num -= 1
        else:
            break
    if l < r:
        print(l+1,r+1)
    else:
        print(-1)

cases = int(input())
for i in range(cases):
    lenth = int(input())
    num_list = list(map(int,input().split()))
    two_pointers(num_list)