'''
2300015897
吴杰稀
光华管理学院
'''
string = input()
new_string = ""
gap = ord('a') - ord('A')

i = string[0]

if 'a' <= i <= 'z':
    i = chr(ord(i) - gap)

new_string = i + string[1:]

print(new_string)
