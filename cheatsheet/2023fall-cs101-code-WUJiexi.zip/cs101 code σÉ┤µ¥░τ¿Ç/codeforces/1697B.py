n,q = map(int,input().split())
price_list = list(map(int,input().split()))
price_list.sort(reverse=True)
p = [0]
for i in range(len(price_list)):
    p.append(p[i] + price_list[i])

for j in range(q):
    x,y = map(int,input().split())
    print(p[x] - p[x-y])