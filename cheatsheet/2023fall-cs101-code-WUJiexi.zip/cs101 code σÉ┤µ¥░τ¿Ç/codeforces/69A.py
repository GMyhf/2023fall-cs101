'''
2300015897
吴杰稀
光华管理学院
'''
lines = int(input())
vectors_list_0 = []
vectors_list_1 = []
vectors_list_2 = []
for i in range(lines):
    nums_list = list(map(int,input().split()))
    vectors_list_0.append(nums_list[0])
    vectors_list_1.append(nums_list[1])
    vectors_list_2.append(nums_list[2])
if sum(vectors_list_0) == 0 and sum(vectors_list_1) == 0 and sum(vectors_list_2) == 0:
    print("YES")
else:
    print("NO")