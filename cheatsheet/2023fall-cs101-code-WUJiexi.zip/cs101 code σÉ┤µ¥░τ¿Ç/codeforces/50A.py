m,n=map(int,input().split())
num=m*n/2
num=int(num)
print(num)