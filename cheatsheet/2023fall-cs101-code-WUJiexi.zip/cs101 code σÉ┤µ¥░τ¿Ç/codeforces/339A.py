'''
2300015897
吴杰稀
光华管理学院
'''

equation = input()
equ_list = [_ for _ in equation if _ != "+"]
equ_list.sort()
new_equation = '+'.join(equ_list)
print(new_equation)