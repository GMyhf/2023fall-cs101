n = int(input())
matrix = [[1]*(n + 1) for i in range(n + 1)]
res = 1

for i in range(2,n + 1):
    for j in range(2,n + 1):
        matrix[i][j] = matrix[i - 1][j] + matrix[i][j - 1]
        res = max(res,matrix[i][j])
print(res)