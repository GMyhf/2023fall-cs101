cases = int(input())
for i in range(cases):
    n = int(input())
    num_list = [i for i in range(1,n+1)]
    num_list.sort()
    if n % 2 == 0:
        i = 0
        while True:
            num_list[i],num_list[i + 1] = num_list[i + 1],num_list[i]
            i += 2
            if (i+1) >= n:
                break
        print(' '.join(str(i) for i in num_list))
    else:
        if n == 1:
            print("-1")
        elif n == 3:
            print("-1")
        else:
            num_list.sort()
            num_list = num_list[-2:] + num_list[:-2]
            print(' '.join(str(i) for i in num_list))