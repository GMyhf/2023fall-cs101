numbers  = int(input())
coin_list = list(map(int,input().split()))
coin_list.sort()
t = 1
while True:
    l_list = coin_list[-t:]
    r_list = coin_list[:numbers - t]
    if sum(l_list) <= sum(r_list):
        t += 1
    else:
        break
print(t)