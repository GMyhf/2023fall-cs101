n,m = map(int,input().split())
if n % 2 == 0:
    t1 = n // 2
    t2 = n // 2
elif n % 2 == 1:
    t1 = (n + 1) // 2
    t2 = (n - 1) // 2
if m <= t1:
    print(2*m - 1)
else:
    print(2 * (m - t1))
