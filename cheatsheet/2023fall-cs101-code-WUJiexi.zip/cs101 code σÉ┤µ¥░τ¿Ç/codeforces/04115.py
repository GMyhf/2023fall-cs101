'''
2300015897
'''
from heapq import heappush,heappop
m,n,b = map(int,input().split())

def is_valid(x,y,b):
    if 0 <= x < m and 0 <= y < n:
        if maze[x][y] == "#" and b == 0:
            return False
        return True
    return False

dx = [1,0,-1,0]
dy = [0,-1,0,1]

def bfs(t,x,y,b):
    q = [(t,-b,x,y)]
    v = [[False] * n for i in range(m)]
    while q:
        t1,b1,x1,y1 = heappop(q)
        v[x1][y1] = True
        b1 = -b1
        for i in range(4):
            nt = t1 + 1
            nx = x1 + dx[i]
            ny = y1 + dy[i]
            if nx == ex and ny == ey:
                return nt
            if is_valid(nx,ny,b1) and not v[nx][ny]:
                if maze[nx][ny] == "#":
                    nb = b1 - 1
                else:
                    nb = b1
                v[nx][ny] = True
                nb = -nb
                heappush(q,(nt,nb,nx,ny))
    return "-1"
maze = [[x for x in input()] for i in range(m)]
sx,sy,ex,ey = 0,0,0,0
for i in range(m):
    for j in range(n):
        if maze[i][j] == "@":
            sx,sy = i,j
        elif maze[i][j] == "+":
            ex,ey = i,j
print(bfs(0,sx,sy,b))