p = input()
i = 0
while True:
    if i == len(p):
        print("NO")
        break
    if p[i] == "H" or p[i] == "Q" or p[i] == "9":
        print("YES")
        break
    i += 1
