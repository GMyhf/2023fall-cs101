'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    num = int(input())
    height_list = list(map(int,input().split()))
    height_list.sort()
    mid = num//2
    l,r = mid - 1,mid
    while l >= 1:
        if height_list[l] == height_list[l - 1]:
            l -= 1
        else:
            break
    while r < num:
        if height_list[r - 1] == height_list[r]:
            r += 1
        else:
            break
    print(max(l*(num - l),r*(num - r),mid))