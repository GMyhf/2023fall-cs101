num = list(map(int,input().split()))
num.sort()
element = []
for i in range(3):
    t = num[-1] - num[i]
    element.append(t)
print(' '.join(str(_) for _ in element))