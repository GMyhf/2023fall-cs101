'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())
for i in range(cases):
    a1 , a2 ,a3 ,a4 = map(int,input().split())
    alice,bob,total_time = a1 + 1,a1 + 1,a1
    if alice > 1 and bob > 1:
        t = min(a2 ,a3)
        total_time += 2 * t
        a2 -= t
        a3 -= t
        if a2 == 0 and a3 == 0:
            total_time += min(alice,bob,a4)
        elif a2 == 0:
            if bob -a3 <= 0:
                total_time += bob
            else:
                total_time += min(bob, a3 + a4)
        elif a3 == 0:
            if alice - a2 <= 0:
                total_time += alice
            else:
                total_time += min(alice, a2 + a4)
    else:
        total_time = 1
    print(total_time)
