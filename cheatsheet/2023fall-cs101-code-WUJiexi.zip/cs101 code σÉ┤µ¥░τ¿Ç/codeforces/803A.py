'''
2300015897
吴杰稀
光华管理学院
'''
n,k = map(int,input().split())
matrix = [[0]*n for i in range(n)]
if k > n*n:
    print(-1)
elif k == 0:
    for _ in matrix:
        print(*_)
else:
    i,j,put_in = 0,0,0
    while i < n and j < n:
        if i == j:
            put_in += 1
        elif i != j:
            put_in += 2

        if put_in == k:
            matrix[i][j],matrix[j][i] = 1,1
            break
        elif i != j and put_in == k + 1:
            matrix[i + 1][i + 1] = 1
            break

        matrix[i][j],matrix[j][i] = 1,1
        if j == n - 1:
            i += 1
            j = i
        else:
            j += 1
    for _ in matrix:
        print(*_)

