'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
information = list(map(int,input().split()))
dp = [0] * (n + 1)
change = 0
for i in range(1,len(information) + 1):
    if information[i - 1] == 0:
        dp[i] = dp[i - 1] + 1
        change = 0
    elif information[i - 1] == 1:
        if change != 1:
            dp[i] = dp[i - 1]
            change = 1
        else:
            dp[i] = dp[i - 1] + 1
            change = 0
    elif information[i - 1] == 2:
        if change != 2:
            dp[i] = dp[i - 1]
            change = 2
        else:
            dp[i] = dp[i - 1] + 1
            change = 0
    elif information[i - 1] == 3:
        dp[i] = dp[i - 1]
        if change == 1:
            change = 2
        elif change == 2:
            change = 1
print(dp[-1])
