'''
2300015897
吴杰稀
光华管理学院
'''
n = int(input())
student_dict = {}
student_list = list(map(int,input().split()))
for _ in student_list:
    if _ in student_dict:
        student_dict[_] += 1
    else:
        student_dict[_] = 1
taxi = 0

if 4 in student_dict:
    taxi += student_dict[4]

if 3 in student_dict:
    taxi += student_dict[3]
    if 1 in student_dict:
        student_dict[1] -= student_dict[3]
        if student_dict[1] < 0:
            student_dict[1] = 0

if 2 in student_dict:
    taxi += int(student_dict[2]//2)
    student_dict[2] = student_dict[2] % 2
    if student_dict[2] != 0:
        taxi += 1
    if 1 in student_dict:
        student_dict[1] -= 2*student_dict[2]
        if student_dict[1] < 0:
            student_dict[1] = 0

if 1 in student_dict:
    if student_dict[1] % 4 == 0:
        taxi += student_dict[1]//4
    else:
        taxi += student_dict[1]//4 + 1

print(taxi)

