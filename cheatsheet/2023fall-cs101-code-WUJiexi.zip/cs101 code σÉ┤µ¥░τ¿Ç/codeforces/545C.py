'''
2300015897
吴杰稀
光华管理学院
'''
cases = int(input())

tree_list = []
for i in range(cases):
    tree_list.append(list(map(int,input().split())))

end = tree_list[0][0]
i,add_up = 1,2

while i < len(tree_list) - 1:
    if tree_list[i][0] - tree_list[i][1] > end:
        end = tree_list[i][0]
        add_up += 1
    else:
        if tree_list[i][0] + tree_list[i][1] < tree_list[i + 1][0]:
            end = tree_list[i][0] + tree_list[i][1]
            add_up += 1
        else:
            end = tree_list[i][0]
    i += 1

if cases >= 2:
    print(add_up)
else:
    print(cases)
