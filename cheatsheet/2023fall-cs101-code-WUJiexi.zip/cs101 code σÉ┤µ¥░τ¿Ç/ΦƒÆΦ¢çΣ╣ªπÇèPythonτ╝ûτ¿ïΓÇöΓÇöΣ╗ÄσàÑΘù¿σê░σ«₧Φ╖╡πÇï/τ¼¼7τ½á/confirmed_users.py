#待验证用户列表
#一个用于储存已验证用户的列表
unconfirmed_users=['alice','brian','candace']
confirmed_users=[]

#验证每个用户，直到待验证用户列表被清空
#将每个经过验证的用户都移到已验证用户列表中
while unconfirmed_users:#不断运行，直到列表unconfirmed_users变成空的
    current_user=unconfirmed_users.pop()

    print(f"Verifying user:{current_user.title()}")
    confirmed_users.append(current_user)

#显示所有已验证的用户
print("\nThe following users have been confirmed:")
for confirmed_user in confirmed_users:
    print(confirmed_user.title())