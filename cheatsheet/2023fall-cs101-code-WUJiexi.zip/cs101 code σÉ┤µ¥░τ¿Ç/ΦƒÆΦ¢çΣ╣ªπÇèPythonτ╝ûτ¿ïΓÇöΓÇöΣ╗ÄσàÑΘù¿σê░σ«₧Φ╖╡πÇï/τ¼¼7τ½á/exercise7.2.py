number = int(input("请输入用餐人数： "))
if number >= 8:
    print("None table is available.")
else:
    print("There are available tables.")