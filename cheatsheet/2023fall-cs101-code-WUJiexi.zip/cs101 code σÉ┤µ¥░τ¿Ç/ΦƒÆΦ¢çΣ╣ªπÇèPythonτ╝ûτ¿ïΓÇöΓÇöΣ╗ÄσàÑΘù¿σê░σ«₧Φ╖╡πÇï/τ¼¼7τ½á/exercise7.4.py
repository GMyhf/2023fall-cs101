ingredient="\nPlease enter the name of a topping you want to add."
ingredient+="\nEnter 'quit' when you are finished."
message=""
while message!='quit':
    message = input(ingredient)
    
    if message!='quit':
        print(f"We'll add {message} to you")
