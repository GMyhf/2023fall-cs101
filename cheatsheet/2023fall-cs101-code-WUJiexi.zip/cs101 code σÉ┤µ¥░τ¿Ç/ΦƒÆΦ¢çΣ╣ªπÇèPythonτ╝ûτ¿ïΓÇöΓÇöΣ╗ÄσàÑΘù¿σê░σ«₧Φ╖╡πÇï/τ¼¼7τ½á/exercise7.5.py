message="\n请输入年龄(整数),"
message+="输入'quit'以终止运行本程序"
while True:
    age=input(message)
    if age=='quit':
        break
    else:
        age=int(age)
        if age <= 3:
            charge=0
        elif age <= 12:
            charge=10
        else:
            charge=15
    print(f"Your ticket fee is {charge}$.")
