dict1={}

active=True

while active:

    name=input("\nWhat's your name? ")
    resort=input("\nIf you could visit one place in the world,where would you go? ")

    dict1[name]=resort.title()

    repeat=input("\nWould you like to let another user to response?(yes/no) ")

    if repeat=='no':
        active=False

for name,resort in dict1.items():
    print(f"{name.title()}'s favorite place is {resort.title()}.")