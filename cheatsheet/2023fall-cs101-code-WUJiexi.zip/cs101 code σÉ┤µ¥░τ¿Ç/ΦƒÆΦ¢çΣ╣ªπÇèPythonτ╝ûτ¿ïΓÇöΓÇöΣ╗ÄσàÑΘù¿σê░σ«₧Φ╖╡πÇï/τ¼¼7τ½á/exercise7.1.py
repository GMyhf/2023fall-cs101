wanted_car=input("Which car do you want to rent? ")
print(f"Let me see if I can find you a {wanted_car}.")