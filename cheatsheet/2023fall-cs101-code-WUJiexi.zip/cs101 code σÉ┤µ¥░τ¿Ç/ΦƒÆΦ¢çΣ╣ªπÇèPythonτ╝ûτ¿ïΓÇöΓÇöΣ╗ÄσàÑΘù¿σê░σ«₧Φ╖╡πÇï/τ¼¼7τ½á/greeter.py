name=input("Please enter your name: ")
print(f"Hello,{name.title()}!")

#将提示赋给一个变量，再将该变量传递给函数input()
#创建多行字符串用+=
prompt="If you tell us who you are,we can personalize the messages you see."
prompt+="\nWhat is your first name?"

name=input(prompt)
print(f"Hello,{name}!")
