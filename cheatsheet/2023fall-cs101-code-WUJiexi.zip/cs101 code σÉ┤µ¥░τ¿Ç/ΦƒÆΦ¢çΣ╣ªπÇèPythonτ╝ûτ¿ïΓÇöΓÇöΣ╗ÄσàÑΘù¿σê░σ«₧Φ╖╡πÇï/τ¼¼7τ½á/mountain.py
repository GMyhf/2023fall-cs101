responses={}

#设置flag
polling_active=True

while polling_active:

    #输入提示词
    name=input("\nWhat's your name? ")
    response=input("\nWhich mountain would you like to climb someday? ")

    #将回答添加到字典中
    responses[name]=response

    #看看是否还有人要调查
    repeat=input("Would you like to let another person respond?(yes/no) ")
    if repeat=='no':
        polling_active=False

#调查结果输出
print("\n---Poll Results---")
for name,response in responses.items():
    print(f"{name.title()} would like to climb {response.title()}.")