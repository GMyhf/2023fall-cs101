height=input("How tall are you,in inches? ")#提问后预留一个空格，便与阅读
height=int(height)

if height >= 48:
    print("\nYou are tall enough to ride!")

else:
    print("\nYou'll be able to ride when you're a little older.")