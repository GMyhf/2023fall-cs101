#十的倍数
number=int(input("请输入一个正整数: "))
if number%10 == 0:
    print(f"{number}是十的倍数")
else:
    print(f"{number}不是十的倍数")