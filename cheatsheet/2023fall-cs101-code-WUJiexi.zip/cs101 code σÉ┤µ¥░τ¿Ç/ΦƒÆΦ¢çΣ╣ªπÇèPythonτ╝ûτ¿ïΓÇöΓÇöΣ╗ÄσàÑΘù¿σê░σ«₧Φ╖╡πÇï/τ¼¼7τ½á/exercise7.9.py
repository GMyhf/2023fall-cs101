sandwich_orders=['chicken sandwich','pastrami sandwich','pork sandwich','pastrami sandwich','tuna sandwich','pastrami sandwich']
finished_orders=[]

print("Pastrami sandwich has been sold out.")
while 'pastrami sandwich' in sandwich_orders:
    sandwich_orders.remove('pastrami sandwich')

for sandwich in sandwich_orders:
    print(f"I made your {sandwich.title()}")

while sandwich_orders:
    removed_sandwich=sandwich_orders.pop()
    finished_orders.append(removed_sandwich.title())

print(f"We've made you {finished_orders}")