#名言
print('Albert Einstein once said,"A person who never made a mistake never tried anything new."')