#个性化消息
name=input("请输入一个人的名字：")
print("Hello %s,would you like to learn some Python today?"%name)