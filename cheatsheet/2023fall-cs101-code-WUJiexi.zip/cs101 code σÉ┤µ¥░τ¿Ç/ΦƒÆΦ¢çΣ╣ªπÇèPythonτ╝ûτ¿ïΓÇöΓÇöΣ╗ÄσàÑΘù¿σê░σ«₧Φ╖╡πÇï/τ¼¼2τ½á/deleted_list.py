motorcycles=["honda","yamaha","suzuki"]
del motorcycles[0]
print(motorcycles)  