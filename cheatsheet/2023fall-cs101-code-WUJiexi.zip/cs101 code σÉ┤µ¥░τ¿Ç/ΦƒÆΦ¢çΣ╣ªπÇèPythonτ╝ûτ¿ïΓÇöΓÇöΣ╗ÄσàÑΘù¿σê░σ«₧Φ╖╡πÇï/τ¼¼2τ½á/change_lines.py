#\n表示添加换行符
#\t表示添加制表符
print("Languages:\n\tPython\n\tC\n\tJavascript")
print("a")
print("\n")#print()自带换行功能
print("b")