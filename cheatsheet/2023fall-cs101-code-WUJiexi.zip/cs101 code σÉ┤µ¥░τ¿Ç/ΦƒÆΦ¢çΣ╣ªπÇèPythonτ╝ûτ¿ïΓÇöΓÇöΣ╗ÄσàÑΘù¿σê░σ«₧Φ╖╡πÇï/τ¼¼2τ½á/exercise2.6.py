#名言2
famous_person=input("请输入一个人的姓名：")
message=input("请输入一句名言：")
print('%s once said,"%s"'%(famous_person,message))