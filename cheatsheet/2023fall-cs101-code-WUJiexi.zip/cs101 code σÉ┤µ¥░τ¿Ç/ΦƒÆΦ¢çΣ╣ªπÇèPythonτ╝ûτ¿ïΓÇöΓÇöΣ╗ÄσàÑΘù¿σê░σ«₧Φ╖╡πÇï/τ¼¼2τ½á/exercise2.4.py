#调整名字的大小写
name=input("请输入一个人的英文名：")
print(name.title())
print(name.upper())
print(name.lower())