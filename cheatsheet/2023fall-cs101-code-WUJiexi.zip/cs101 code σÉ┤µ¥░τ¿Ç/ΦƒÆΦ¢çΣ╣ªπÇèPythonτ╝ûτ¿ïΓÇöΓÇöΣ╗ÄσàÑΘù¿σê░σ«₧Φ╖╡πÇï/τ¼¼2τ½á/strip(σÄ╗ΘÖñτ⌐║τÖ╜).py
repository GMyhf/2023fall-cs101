favorite_language=" python world "
#.rstrip去除尾部空白
print(favorite_language.rstrip())
#.lstrip去除头部空白
print(favorite_language.lstrip())
#.strip去除所有空白
print(favorite_language.strip())