name="ada lovelace"

#首字母大写
print(name.title())

name="Ada Lovelace"
#全部大写
print(name.upper())

#全部小写——储存数据，统一变量
print(name.lower())