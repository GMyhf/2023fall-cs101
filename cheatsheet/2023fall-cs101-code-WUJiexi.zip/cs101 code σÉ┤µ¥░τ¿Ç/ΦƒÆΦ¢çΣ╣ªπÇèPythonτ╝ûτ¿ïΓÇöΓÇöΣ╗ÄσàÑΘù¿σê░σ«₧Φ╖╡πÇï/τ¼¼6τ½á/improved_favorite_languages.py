favorite_languages={
    'jen':['python','ruby'],
    'sarah':['c'],
    'edward':['ruby','go'],
    'phil':['python','haskell'],
    }
for name,languages in favorite_languages.items():
    print(f"\n{name.title()}'s favorite language are:")
    for language in favorite_languages[name]:
        print("\t"+language)