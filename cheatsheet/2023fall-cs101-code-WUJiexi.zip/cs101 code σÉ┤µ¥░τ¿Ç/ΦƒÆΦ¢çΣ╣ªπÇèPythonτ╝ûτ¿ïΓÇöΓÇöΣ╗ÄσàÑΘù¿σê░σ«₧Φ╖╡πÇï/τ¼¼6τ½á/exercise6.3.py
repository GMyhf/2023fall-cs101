terms={
    'title':'首字母大写',
    'upper':'全部大写',
    'del':'删除',
    'insert':'插入',
    'sort':'排序'
}
for fx,definition in terms.items():
    print(f"{fx}\n\t{definition}")