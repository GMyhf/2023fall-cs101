cities={
    'New York':{
        'country':'America',
        'population':'8.82 million',
        'fact':'全美密度最高的城市',
        },
    'Beijing':{
        'country':'China',
        'population':'21.8 million',
        'fact':'中国首都',
        },
    'Sydney':{
        'country':'Australia',
        'population':'5.12 million',
        'fact':'澳大利亚首都',
        },
    }
for city,city_information in cities.items():
    print(f"\n{city}")
    country=f"{city_information['country']}"
    population=f"{city_information['population']}"
    fact=f"{city_information['fact']}"
    print(f"\t{country}\n\t{population}\n\t{fact}")