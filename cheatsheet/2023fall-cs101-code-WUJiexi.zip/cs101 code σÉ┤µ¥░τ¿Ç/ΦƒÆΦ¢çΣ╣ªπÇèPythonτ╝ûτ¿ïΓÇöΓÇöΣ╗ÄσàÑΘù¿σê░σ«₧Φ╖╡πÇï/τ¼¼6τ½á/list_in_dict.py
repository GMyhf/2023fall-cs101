#储存所点披萨的信息
pizza={
    'crust':'thick',
    'toppings':['mushrooms','extra cheese']
    }
#概述所点的披萨
print(f"You ordered a {pizza['crust']}-pizza "
      "with the following toppings:")
#当字符串很长时，可以在合适的位置分行，只需要在每行末尾都加上引号，且除了第一行外的其他各行都在行首加上引号并缩进

for topping in pizza['toppings']:
    print("\t"+topping)