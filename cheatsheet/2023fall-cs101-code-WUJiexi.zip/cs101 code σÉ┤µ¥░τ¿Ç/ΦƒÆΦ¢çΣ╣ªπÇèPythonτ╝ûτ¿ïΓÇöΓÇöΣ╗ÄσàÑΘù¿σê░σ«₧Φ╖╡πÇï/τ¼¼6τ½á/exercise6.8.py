pets={
    'dog':'Peter',
    'cat':'kitty',
    'snake':'Tom',
    'bear':'Tonny',
    }
for pet,owner in pets.items():
    print(f"{pet.title()}'s owner is {owner}.")