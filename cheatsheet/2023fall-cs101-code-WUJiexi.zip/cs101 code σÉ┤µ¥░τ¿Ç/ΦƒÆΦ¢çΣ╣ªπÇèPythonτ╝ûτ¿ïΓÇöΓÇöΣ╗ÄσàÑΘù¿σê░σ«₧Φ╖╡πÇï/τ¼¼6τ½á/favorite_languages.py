favorite_languages={
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python',
    }
language=favorite_languages['sarah'].title()
print(f"Sarah's favorite language is {language}")

#遍历所有键值对(不要忘了在字典后面加.items())
for name,language in favorite_languages.items():
    print(f"{name.title()}'s favorite language is {language}.title.")