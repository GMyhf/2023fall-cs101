alien_0={'color':'green','speed':'slow'}
#get()括号内两个参数，第一个是键，第二个是指定的键不存在时返回的默认值
point_value=alien_0.get('point','No point value assigned')
print(point_value)
point_value=alien_0.get('point')#如果不指定第二个参数，若字典中没有指定键，直接返回None
print(point_value)
#字典中存在指定键时，可以考虑方括号法
print(alien_0['speed'])