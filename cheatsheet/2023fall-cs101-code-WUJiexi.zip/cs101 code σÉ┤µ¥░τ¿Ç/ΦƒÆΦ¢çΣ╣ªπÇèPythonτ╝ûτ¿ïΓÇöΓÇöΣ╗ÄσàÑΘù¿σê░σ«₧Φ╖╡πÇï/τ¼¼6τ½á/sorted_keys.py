favorite_languages={
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python',
    }

for name in sorted(favorite_languages.keys()):
    print(f"{name.title()},thank you for taking the poll.")

#回顾
#list.sort()--按照字母顺序排列,且永久改变
#list.sort(reverse=True)--反序排列，且永久改变
#sorted(list)--临时改变
#sorted(list,reverse=True)--临时改变