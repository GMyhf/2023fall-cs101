favorite_languages={
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python'
    }

for language in favorite_languages.values():
    print(language.title())

#合并相同项，使用集合set()
for language in set(favorite_languages.values()):
    print(language.title())

#集合的创建
languages={'python','ruby','python','c'}
print(languages)