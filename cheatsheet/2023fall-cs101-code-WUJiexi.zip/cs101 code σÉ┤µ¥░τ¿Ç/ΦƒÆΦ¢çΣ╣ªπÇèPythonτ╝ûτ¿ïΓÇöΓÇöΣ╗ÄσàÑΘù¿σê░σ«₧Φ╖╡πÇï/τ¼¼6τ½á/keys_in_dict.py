favorite_languages={
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python',
    }

#遍历键时，.keys()可加可不加
for name in favorite_languages.keys():
    print(name.title())
for name in favorite_languages:
    print(name.title())