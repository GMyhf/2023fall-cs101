alien_0={'color':'green','points':5}

print(alien_0['color'])
print(alien_0['points'])

new_points=alien_0['points']
print(f"You just earned {new_points} points!")

#字典新增
alien_0['x_position']=0
alien_0['y_position']=25
print(alien_0)

#删除键值对
del alien_0['points']
print(alien_0)