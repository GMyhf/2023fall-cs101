#遍历字典中所有键值对
#格式：for key,value in dict.items():
user_0={
    'username':'efermi',
    'first':'enrico',
    'last':'fermi',
    }
for key,value in user_0.items():
    print(f"\nKey:{key}")
    print(f"Value:{value}")