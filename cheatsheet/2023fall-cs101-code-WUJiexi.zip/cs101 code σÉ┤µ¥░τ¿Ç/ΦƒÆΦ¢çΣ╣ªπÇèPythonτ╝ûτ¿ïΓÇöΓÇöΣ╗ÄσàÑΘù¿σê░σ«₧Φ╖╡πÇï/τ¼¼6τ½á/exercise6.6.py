list=['Peter','Tom','Ann','Mike','Miller','White','Black','Tonny']
names_dict={
    'peter':1,
    'Tom':2,
    'Mike':3
    }
l=len(list)
for i in range(l):
    if list[i] in names_dict.keys():
        print(f'{list[i]},thank you for participating in our investigation.\n')
    else:
        print(f'{list[i]},we are writing to invite you to our investigation.\n')