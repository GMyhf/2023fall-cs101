cars=['bmw','audi','toyota','subaru']
print(len(cars))