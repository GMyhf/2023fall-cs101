#组织列表
cars=['bmw','audi','toyota','subaru']
cars.sort()#按照字母顺序排序
print(cars)
cars.sort(reverse=True)#反方向排列
print(cars)