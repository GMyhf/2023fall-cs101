#临时排序
cars=['bmw','audi','toyota','subaru']
print("Here is the original list:")
print(cars)
print("\nHere is the sorted list:")
print(sorted(cars,reverse=True))
print("\nHere is the original list again:")
print(cars)
cars.reverse()
print(cars)