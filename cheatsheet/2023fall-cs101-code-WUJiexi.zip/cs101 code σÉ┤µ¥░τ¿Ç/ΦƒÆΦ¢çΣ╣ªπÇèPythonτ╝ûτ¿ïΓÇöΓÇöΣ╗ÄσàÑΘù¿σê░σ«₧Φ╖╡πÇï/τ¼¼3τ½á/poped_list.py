motorcycles=["honda","yamaha","suzuki"]
print(motorcycles)
# .pop()默认删除-1且弹出该元素
poped_motorcycles=motorcycles.pop(0)
print(motorcycles)
print(poped_motorcycles)
print(f"The last owned bike was a {poped_motorcycles.title()}")