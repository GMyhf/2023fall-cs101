motorcycles=["honda","yamaha","suzuki"]
motorcycles.insert(1,"ducati")
print(motorcycles)