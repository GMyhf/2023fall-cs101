#遍历列表
magicians=['alice','david','carolina']
for magician in magicians:
    print(magician.title())
for magician in magicians:
    print(magician.title(),'that was a great trick!')#也可以是print(f'{magician.title()},that was a great trick')
    print(f'{magician.title()},that was a great trick!')
    print(f"I can't wait to see your next trick,{magician.title()}. \n")
#注：print('I can't wait to see your next trick"',magician.title())是错误代码，因为无法识别三个单引号
print('Thank you,everyone.That was a great show!')#for循环后面没有缩进的代码都只执行一次