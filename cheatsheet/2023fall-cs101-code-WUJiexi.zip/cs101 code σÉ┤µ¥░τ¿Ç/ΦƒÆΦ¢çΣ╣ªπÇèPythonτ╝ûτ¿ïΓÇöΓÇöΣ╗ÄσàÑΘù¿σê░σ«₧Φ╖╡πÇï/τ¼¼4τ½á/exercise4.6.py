numbers=[number for number in range(1,21,2)]
print(numbers)
for number in numbers:
    print(number)