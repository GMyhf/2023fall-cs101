my_foods=['pizza','falafel','carrot cake']
friend_foods=my_foods#更改一个列表另一个也被改变

print("My favorite foods are:")
print(my_foods)

friend_foods[0]='apple'
print("\nMy friend's favorite food are:")
print(friend_foods)
print(my_foods)

my_foods=['pizza','falafel','carrot cake']
friend_foods=my_foods[:]#更改前者不影响后者

print("My favorite foods are:")
print(my_foods)

friend_foods[0]='apple'
print("\nMy friend's favorite food are:")
print(friend_foods)
print(my_foods)