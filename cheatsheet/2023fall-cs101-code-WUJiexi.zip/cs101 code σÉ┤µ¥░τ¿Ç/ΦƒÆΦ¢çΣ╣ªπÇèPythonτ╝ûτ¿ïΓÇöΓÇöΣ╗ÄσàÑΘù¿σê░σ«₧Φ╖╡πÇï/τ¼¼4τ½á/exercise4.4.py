numbers=[number for number in range(1,1000000+1)]
print(numbers)
print(max(numbers))
print(min(numbers))
print(sum(numbers))