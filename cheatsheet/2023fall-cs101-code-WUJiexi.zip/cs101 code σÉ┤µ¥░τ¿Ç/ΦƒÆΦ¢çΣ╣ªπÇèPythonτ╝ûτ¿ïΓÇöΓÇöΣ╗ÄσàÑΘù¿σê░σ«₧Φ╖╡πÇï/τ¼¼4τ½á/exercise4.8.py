cubics=[number**3 for number in range(1,11)]
for cubic in cubics:
    print(cubic)