#比萨
pizzas=['A','B','C']
for pizza in pizzas:
    print(f'I like {pizza}.')
print('I really love pizza!')