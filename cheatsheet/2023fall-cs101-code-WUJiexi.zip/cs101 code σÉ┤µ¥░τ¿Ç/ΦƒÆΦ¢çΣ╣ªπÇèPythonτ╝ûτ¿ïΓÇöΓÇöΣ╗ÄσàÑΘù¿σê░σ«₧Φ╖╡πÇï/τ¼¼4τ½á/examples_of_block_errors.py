#忘记缩进
magicians=['alice','david','carolina']
for magician in magicians:
print(magician.title())
#忘记缩进额外的代码行
magicians=['alice','david','carolina']
for magician in magicians:
    print(magician.title())
print(f"I can't wait to see your next trick,{magician.title()}. \n")
#不必要的缩进
message="Hello Python World!"
    print(message)
#循环后不必要的缩进
magicians=['alice','david','carolina']
for magician in magicians:
    print(magician.title(),'that was a great trick!')

    print('Thank you,everyone.That was a great show!')
#遗漏冒号
magicians=['alice','david','carolina']
for magician in magicians
    print(magician.title(),'that was a great trick!')