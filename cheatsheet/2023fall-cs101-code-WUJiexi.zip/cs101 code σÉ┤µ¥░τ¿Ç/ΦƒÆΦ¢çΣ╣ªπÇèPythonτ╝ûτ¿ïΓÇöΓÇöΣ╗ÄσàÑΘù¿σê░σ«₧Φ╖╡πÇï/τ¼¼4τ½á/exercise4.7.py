list=[number for number in range(3,31,3)]
print(list)
for number in list:
    print(number)