for number in range(1,20+1):
    print(number)