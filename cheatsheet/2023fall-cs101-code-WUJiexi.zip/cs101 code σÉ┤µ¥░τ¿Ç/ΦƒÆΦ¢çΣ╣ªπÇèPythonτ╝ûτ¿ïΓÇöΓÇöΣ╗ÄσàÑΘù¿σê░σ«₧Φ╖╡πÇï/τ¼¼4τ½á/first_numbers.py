for value in range(1,6):
    print(value)
#使用range()创建数字列表
numbers=list(range(1,6))
print(numbers)