squares=[]
for i in range(1,11):
    squares.append(i**2)
print(squares)