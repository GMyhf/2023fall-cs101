car='subaru'
print("Is car == 'subaru'?I predict True.")
print(car == 'subaru')
print("\nIs car == 'audi'?I predict False.")
print(car == 'audi')