current_users=['Peter','Jason','Mike','White','Black']
new_users=['peter','Jason','Andrew','Judy','Ann']
current_users_database=[current_user.lower() for current_user in current_users]
for new_user in new_users:
    if new_user.lower() in current_users_database:
        print("This name has been used.Please change another user name.")
    else:
        print("Registration successful!")