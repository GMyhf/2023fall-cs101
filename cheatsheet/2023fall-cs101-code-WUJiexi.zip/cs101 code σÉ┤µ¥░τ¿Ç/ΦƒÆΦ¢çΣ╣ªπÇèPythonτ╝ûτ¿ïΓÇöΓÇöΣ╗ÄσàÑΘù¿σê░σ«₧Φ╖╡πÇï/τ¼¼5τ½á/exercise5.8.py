names=['Admin','Peter','Mike','White','Black']
for name in names:
    if name == 'Admin':
        print ("Hello Admin,would you like to see a status report?")
    else:
        print("Hello Jaden,thank you for logging in again.")