age_0=22
age_1=18
#使用and检查多个条件
print((age_0 >= 21) and (age_1 >= 21))#为增加可读性，可在每个小判定两侧加上括号
print((age_0 >= 21) or (age_1 >= 21))