age=int(input("请输入年龄："))
if age <= 4:
    charge = "free of charge"
elif age <= 18:
    charge = "25$"
elif age <= 25:
    charge = "36$"
else:
    charge = "40$"
print(f"Your ticket is {charge}")
