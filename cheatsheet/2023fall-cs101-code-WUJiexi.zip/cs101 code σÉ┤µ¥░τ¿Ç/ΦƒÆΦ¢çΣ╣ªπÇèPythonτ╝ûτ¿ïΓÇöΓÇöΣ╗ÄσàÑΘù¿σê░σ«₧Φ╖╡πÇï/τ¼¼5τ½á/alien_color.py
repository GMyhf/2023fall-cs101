alien_color='red'
if alien_color == 'green':
    print("Congratulations!You gain 5 points.")