requested_toppings=['mushrooms','onions','pineapple']
#检查特定值是否包含在列表中
print('mushrooms' in requested_toppings)
print('pepperoil' in requested_toppings)
#检查特定值是否不包含在列表中
banned_users=['andrew','carolina','david']
user='marie'
if user not in banned_users:
    print(f"{user.title()},you can post a response if you wish.")