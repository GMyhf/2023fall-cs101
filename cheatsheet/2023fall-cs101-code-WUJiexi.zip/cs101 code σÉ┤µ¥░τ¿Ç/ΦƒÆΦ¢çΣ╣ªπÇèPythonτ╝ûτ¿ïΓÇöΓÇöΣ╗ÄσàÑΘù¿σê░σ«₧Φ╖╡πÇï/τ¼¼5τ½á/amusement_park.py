age=int(input("请输入年龄："))
if age < 4:
    price=0
elif age < 8:
    price=25
elif age < 65:
    price=40
else:
    price=20
print(f"Your admission fee is {price}$")