users=['Mike','Judy','Jason']
l=len(users)
if users:
    for i in range(l):
        users.pop(0)
    print(users)
else:
    print("We need to find some users!")