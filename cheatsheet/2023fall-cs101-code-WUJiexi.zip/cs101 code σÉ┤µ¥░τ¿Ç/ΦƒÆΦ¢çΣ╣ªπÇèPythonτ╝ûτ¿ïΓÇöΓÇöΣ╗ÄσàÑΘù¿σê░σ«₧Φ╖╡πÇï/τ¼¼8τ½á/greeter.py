#定义函数
"""
def greet_user():
    #显示简单的问候语
    print("Hello!")

greet_user()
"""

#改进版
def greet_user(username):
    print(f"Hello,{username.title()}!")

username=input("请输入你的名字：")
greet_user(username)