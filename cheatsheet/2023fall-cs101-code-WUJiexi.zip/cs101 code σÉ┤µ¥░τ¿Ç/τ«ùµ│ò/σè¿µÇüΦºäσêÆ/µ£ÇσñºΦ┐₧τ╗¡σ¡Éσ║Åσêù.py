l = int(input())
num = [int(x) for x in input().split()]
dp = [0] * l
dp[0] = num[0]
for i in range(l - 1):
    if dp[i] <= 0:
        dp[i + 1] = num[i + 1]
    else:
        dp[i + 1] = dp[i] +num[i + 1]
print(dp)