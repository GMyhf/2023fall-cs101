volume = int(input())
things = int(input())
value_list = []
for i in range(things):
    weight,value = map(int,input().split())
    value_list.append([weight,value])
dp = [[0] * (volume + 1) for i in range(things + 1)]
for i in range(1,things + 1):
    for j in range(1,volume + 1):
        if j >= value_list[i - 1][0]:
            dp[i][j] = max(dp[i - 1][j],dp[i - 1][j - value_list[i - 1][0]] + value_list[i - 1][1])
        else:
            dp[i][j] = dp[i - 1][j]
print(dp[things][-1])
