'''
2300015897
longest common subsequence
'''
str1,str2 = input().split()
a,b = len(str1),len(str2)
dp = [[0]*(b + 1) for i in range(a + 1)]
for i in range(1,a + 1):
    for j in range(1,b + 1):
        if str1[i - 1] == str2[j - 1]:
            dp[i][j] = dp[i - 1][j - 1] + 1
        elif str1[i - 1] != str2[j - 1]:
            dp[i][j] = max(dp[i - 1][j],dp[i][j - 1])
print(dp[a][b])