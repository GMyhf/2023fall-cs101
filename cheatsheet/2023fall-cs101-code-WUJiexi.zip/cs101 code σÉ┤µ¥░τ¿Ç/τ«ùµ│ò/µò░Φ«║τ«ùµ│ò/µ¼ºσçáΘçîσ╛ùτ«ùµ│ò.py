'''
欧几里得算法Euclidean Algorithm
'''
def Euclidean(a,b):
    if (b == 0):   #边界条件
        return a
    else:
        return Euclidean(b,a % b)
a,b = map(int,input().split())
print(Euclidean(a,b))