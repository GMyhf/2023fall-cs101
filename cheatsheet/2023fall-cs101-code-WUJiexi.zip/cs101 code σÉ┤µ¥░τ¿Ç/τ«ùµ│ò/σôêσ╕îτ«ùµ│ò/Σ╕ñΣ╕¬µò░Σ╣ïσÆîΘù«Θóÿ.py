def findSum(nums, target):
    hash_table = {}
    for i in range(len(nums)):
        print(hash_table)
        complement = target - nums[i]
        print(complement)
        if complement in hash_table:
            return [hash_table[complement], i]
        hash_table[nums[i]] = i
    return []

nums = [2, 15, 11, 7, 6, 3]  # 示例输入，可以根据实际情况修改
target = 9  # 示例输入，可以根据实际情况修改
result = findSum(nums, target)
print(result)
if result:
    print("找到使得两数之和为目标值的数：", nums[result[0]], nums[result[1]])
else:
    print("没有找到符合条件的数对")