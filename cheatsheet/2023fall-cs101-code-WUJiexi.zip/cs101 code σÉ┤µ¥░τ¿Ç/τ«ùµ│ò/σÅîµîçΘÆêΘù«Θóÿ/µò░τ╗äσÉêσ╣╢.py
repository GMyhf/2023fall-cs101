arr1 = [3,6,9,12,15]
arr2 = [2,4,7,13,14]
i,j = 0,0
ans = []
while i < len(arr1) and j < len(arr2):
    if arr1[i] < arr2[j]:
        ans.append(arr1[i])
        i += 1
    else:
        ans.append(arr2[j])
        j += 1
ans += arr1[i:] + arr2[j:]
print(ans)