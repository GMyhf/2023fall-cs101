listValue = [1,5,6,2,4,3]
listPointer = [3,2,-1,5,1,4]
head = 0 #是指向链表第一个元素的指针，需要自己定义（头指针）
next= head
while next != -1:
    print(listValue[next])
    next = listPointer[next]