listValue = [1,4,5,2]
listRight = [3,2,-1,1]
head = 0                #初始化头指针
num = 3                 #num为要插入的元素
next,last = head,head   #初始化表示插入位置的下一个元素和上一个元素的指针

def Output():           #定义用于输出链表的函数
    next = head
    while next != -1:
        print(listValue[next])
        next = listRight[next]

Output()                #查看输出前

while listValue[next] <= num and next != -1: #找到合适的插入位置
    last = next
    next = listRight[next]

listValue.append(num)                       #向数组末尾加入新元素
listRight.append(listRight[last])           #加上新元素指针指向的位置（下一个元素）
listRight[last] = len(listValue) - 1        #上一个元素的指针指向新元素

Output()
