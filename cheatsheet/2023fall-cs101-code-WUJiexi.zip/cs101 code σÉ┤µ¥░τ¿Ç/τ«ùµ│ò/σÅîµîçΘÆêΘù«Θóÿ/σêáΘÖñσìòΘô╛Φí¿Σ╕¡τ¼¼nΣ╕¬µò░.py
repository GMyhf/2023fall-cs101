listValue = [1,5,6,2,7,3]
listRight = [3,2,4,5,-1,1]
head = 0
prepos = 5   #确定要删除的元素的前一个数的位置
next = head
listRight[prepos] = listRight[listRight[prepos]]
while next != -1:
    print(listValue[next])
    next = listRight[next]
