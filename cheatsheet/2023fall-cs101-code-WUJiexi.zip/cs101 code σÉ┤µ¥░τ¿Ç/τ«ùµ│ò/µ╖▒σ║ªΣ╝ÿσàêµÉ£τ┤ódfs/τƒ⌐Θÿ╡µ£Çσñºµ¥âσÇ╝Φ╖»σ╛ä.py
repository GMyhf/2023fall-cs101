'''
2300015897
'''
dx = [0,1,0,-1]
dy = [1,0,-1,0]
temppath,optpath = [[1,1]],[]
def dfs(maze,x,y,nowvalue):
    global maxvalue,temppath,optpath
    for i in range(4):

        nx = x + dx[i]
        ny = y + dy[i]
        if nx == n and ny == m:
            nextvalue = nowvalue + maze[nx][ny]
            temppath.append([nx,ny])
            if nextvalue > maxvalue:
                maxvalue = nextvalue
                optpath = temppath.copy()
            temppath.pop()
        if maze[nx][ny] >= -100:
            nextvalue = nowvalue + maze[nx][ny]
            tmp = maze[x][y]
            maze[x][y] = -9999
            temppath.append([nx,ny])
            dfs(maze,nx,ny,nextvalue)
            maze[x][y] = tmp
            temppath.pop()

n,m = map(int,input().split())
maze = [[-9999] * (m + 2)]
for i in range(n):
    maze.append([-9999] + [int(x) for x in input().split()] + [-9999])
maze.append([-9999] * (m + 2))
maxvalue = -9999
dfs(maze,1,1,maze[1][1])
for _ in optpath:
    print(*_)