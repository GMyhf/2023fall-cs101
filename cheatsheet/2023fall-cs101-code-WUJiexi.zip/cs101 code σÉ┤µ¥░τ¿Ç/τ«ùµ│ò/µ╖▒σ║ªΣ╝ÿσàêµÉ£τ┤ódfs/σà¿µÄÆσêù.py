def dfs(step):
    if step == n + 1:
        for i in range(1, n + 1):
            print(a[i], end="")
        print()
        return
    for i in range(1, n + 1):
        if book[i] == 0:
            a[step] = i
            book[i] = 1
            dfs(step + 1)
            book[i] = 0
n = int(input())
a = [0] * (n + 1)
book = [0] * (n + 1)
dfs(1)