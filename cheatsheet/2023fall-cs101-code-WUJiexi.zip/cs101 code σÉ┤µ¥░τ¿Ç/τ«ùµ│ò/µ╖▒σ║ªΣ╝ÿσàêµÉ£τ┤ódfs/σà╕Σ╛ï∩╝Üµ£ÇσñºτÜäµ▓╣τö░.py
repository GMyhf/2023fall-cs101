#dfs算法
def maxarea_of_island(grid):
    #处理二维数组得到行列数
    row = len(grid)
    col = len(grid[0])
    #arrived为一个二维数组，用于储存正在搜索的土地是否出界且是否已经访问过
    arrived = [[False for i in range(col)] for j in range(row)]
    #记录油田最大面积
    ans = 0
    def DFS(x,y):
        if x >= 0 and x < row and y >= 0 and y < col and not arrived[x][y] and grid[x][y] == 1:
            arrived = True    #标记已经被搜索过
            return 1 + DFS(x - 1,y) + DFS(x + 1,y) + DFS(x,y - 1) + DFS(x,y + 1)
        else:
            return 0
    for i in range(row):
        for j in range(col):
            area = DFS(i,j)
            if area > ans:
                ans = area
    return ans