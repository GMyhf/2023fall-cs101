'''
2300015897
'''
flag = 0
dx = [-1, 0, 1, 0]
dy = [0, 1, 0, -1]
def dfs(maze,x,y,step):
    global flag
    for i in range(4):
        nx = x + dx[i]
        ny = y + dy[i]

        if nx == n and ny == m:
            if step == k - 1:
                flag = 1
            return

        if maze[nx][ny] == 0:
            maze[x][y] = 1
            dfs(maze,nx,ny,step + 1)
            maze[x][y] = 0

n,m,k = map(int,input().split())
maze = [[1] * (m + 2)]
for i in range(n):
    maze.append([1] + [int(x) for x in input().split()] + [1])
maze.append([1] * (m + 2))
dfs(maze,1,1,0)

if flag:
    print("Yes")
else:
    print("No")