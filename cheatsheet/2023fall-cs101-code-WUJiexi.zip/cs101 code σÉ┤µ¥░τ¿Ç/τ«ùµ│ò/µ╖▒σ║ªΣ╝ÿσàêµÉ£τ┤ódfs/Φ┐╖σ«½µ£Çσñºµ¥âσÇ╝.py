'''
2300015897
'''

visit_list = []
value_list = []
n,m = map(int,input().split())
visit_list.append([1] * (m + 2))
for i in range(n):
    visit_list.append([1] + [int(x) for x in input().split()] + [1])
visit_list.append([1] * (m + 2))
for i in range(n):
    value_list.append([int(x) for x in input().split()])
maxvalue = float('-inf')

dx = [-1,0,1,0]
dy = [0,1,0,-1]

def dfs(visit,value,x,y,nowvalue):
    global maxvalue
    for i in range(4):
        nx = x + dx[i]
        ny = y + dy[i]

        if nx == n and ny == m:
            nextvalue = nowvalue + value[nx - 1][ny - 1]
            maxvalue = max(maxvalue,nextvalue)
            continue

        if visit[nx][ny] == 0:
            visit[x][y] = 1
            nextvalue = nowvalue + value[nx - 1][ny - 1]
            dfs(visit,value,nx,ny,nextvalue)
            visit[x][y] = 0

dfs(visit_list,value_list,1,1,value_list[0][0])
print(maxvalue)