n,m = map(int,input().split())
maze = []
maze.append([-1] * (m + 2))
for i in range(n):
    maze.append([-1] + [x for x in list(map(int,input().split()))] + [-1])
maze.append([-1] * (m + 2))
maze[1][1] = -1
dx = [-1,0,1,0]
dy = [0,1,0,-1]
ans = 0


def dfs(maze,x,y):
    global ans

    for i in range(4):
        nx = x + dx[i]
        ny = y + dy[i]

        if nx == n and ny == m:
            ans += 1
            continue

        if maze[nx][ny] == 0:
            maze[nx][ny] = 1
            dfs(maze,nx,ny)
            maze[nx][ny] = 0
    return

dfs(maze,1,1)

print(ans)

