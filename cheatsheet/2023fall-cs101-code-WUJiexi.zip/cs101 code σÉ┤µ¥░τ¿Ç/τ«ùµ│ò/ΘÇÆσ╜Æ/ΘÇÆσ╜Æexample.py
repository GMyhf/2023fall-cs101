def recurse(n):
    if n < 1:
        return
    for i in range(1,n + 1):
        print(i)
    recurse(n-1)
    print("end",n)
recurse(5)