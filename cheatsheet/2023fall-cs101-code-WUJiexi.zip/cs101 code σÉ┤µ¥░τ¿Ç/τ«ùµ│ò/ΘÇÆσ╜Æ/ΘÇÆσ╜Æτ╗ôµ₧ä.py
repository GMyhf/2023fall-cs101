def recursive_function(n):
    # 边界条件
    if n < 0:
        return

    # 递归前进阶段
    print("递归前进阶段: n =", n)

    # 递归调用自身
    recursive_function(n - 1)

    # 递归返回阶段
    print("递归返回阶段: n =", n)
n = int(input())
recursive_function(n)