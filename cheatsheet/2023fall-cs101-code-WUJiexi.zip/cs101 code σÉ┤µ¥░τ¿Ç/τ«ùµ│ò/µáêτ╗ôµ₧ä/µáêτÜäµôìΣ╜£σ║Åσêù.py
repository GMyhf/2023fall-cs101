'''
2300015897
'''
n = int(input())
stack = []
for i in range(n):
    operation = input().split()
    if operation[0] == "push":
        stack.append(operation[1])
    elif operation[0] == "pop":
        if len(stack) == 0:
            print("-1")
        else:
            print(stack.pop())
