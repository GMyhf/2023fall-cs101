'''
2300015897
'''
def is_valid_pop_sequence(n, pop_sequence):
    stack = []
    now_max = 0
    for x in pop_sequence:
        x = int(x)
        if x > now_max:
            for j in range(now_max + 1, x + 1):
                stack.append(j)
            now_max = x
        if stack[-1] != x:
            return "No"
        else:
            stack.pop()
    return "Yes"
# 读取输入
n = int(input())
pop_sequence = list(map(int, input().split()))
# 调用函数进行判断
result = is_valid_pop_sequence(n, pop_sequence)
print(result)