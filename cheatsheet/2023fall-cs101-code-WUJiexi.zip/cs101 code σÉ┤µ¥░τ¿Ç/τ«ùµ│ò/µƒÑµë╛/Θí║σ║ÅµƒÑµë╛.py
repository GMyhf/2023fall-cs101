#顺序查找
arr = [1,3,5,4,2,4,6,5,1]
key = int(input()) #输入需要查找的数

for i in range(len(arr)):
    if arr[i] == key:
        print(i)
        break#确保输出第一个位置
    #关键字不在列表中
print(-1)