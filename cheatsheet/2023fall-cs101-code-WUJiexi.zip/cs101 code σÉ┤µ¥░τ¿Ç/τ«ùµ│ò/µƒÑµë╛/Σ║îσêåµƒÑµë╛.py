arr = [90,56,2,8,6,5,12,15,17,39,41,40,27,23,79,45]
#必须从小到大排序
arr.sort()
#构建左右双指针
l,r = 0,len(arr) - 1

n = int(input())

#当左指针大于右指针时循环停止
while l <= r:
    mid = (l+r) // 2
    if arr[mid] < n: #左指针移到mid+1处
        l = mid + 1
    elif arr[mid] > n:
        r = mid - 1 #右指针移到mid-1处
    else: #如果mid指向元素与key相等，则直接跳出循环
        print(mid)
        break
#while循环自然结束，说明没有找到与关键字相等的元素
print(-1)