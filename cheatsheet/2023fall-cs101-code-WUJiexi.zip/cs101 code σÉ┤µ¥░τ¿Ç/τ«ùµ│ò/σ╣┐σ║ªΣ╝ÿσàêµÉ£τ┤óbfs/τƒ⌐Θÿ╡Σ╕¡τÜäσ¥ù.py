'''
2300015897
'''
from collections import deque
dx = [0,1,0,-1]
dy = [1,0,-1,0]
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and matrix[x][y] == 1 and not in_queue[x][y]:
        return True
    return False
def bfs(x,y):
    q = deque([(x,y)])
    in_queue[x][y] = True
    while q:
        front = q.popleft()
        for i in range(4):
            nx = front[0] + dx[i]
            ny = front[1] + dy[i]
            if is_valid(nx,ny):
                in_queue[nx][ny] = True
                q.append((nx,ny))

n,m = map(int,input().split())
matrix = []
for i in range(n):
    matrix.append([int(x) for x in input().split()])
in_queue = [[False]*m for i in range(n)]
cnt = 0
for i in range(n):
    for j in range(m):
        if matrix[i][j] == 1 and not in_queue[i][j]:
            bfs(i,j)
            cnt += 1
print(cnt)