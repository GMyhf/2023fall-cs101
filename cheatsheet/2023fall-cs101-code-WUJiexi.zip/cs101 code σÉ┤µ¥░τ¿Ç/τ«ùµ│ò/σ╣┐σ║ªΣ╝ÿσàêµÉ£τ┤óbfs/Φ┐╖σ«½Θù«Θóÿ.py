'''
2300015897
'''
from collections import deque
dx = [1,0,-1,0]
dy = [0,1,0,-1]
def is_valid(x,y):
    if 0 <= x < n and 0 <= y < m and maze[x][y] == 0 and not in_queue[x][y]:
        return True
    return False

def bfs(x,y):
    global step,flag
    q = deque([(x,y)])

    while q:
        cnt = len(q)
        for i in range(cnt):
            front = q.popleft()

            for i in range(4):
                nx = front[0] + dx[i]
                ny = front[1] + dy[i]

                if nx == n - 1 and ny == m - 1:
                    step += 1
                    flag = 1
                    return step

                if is_valid(nx,ny):
                    in_queue[nx][ny] = True
                    q.append((nx,ny))

        step += 1

n,m = map(int,input().split())
maze = [list(map(int,input().split())) for i in range(n)]
in_queue = [[False]*m for i in range(n)]
in_queue[0][0] = True
step,flag = 0,0
bfs(0,0)
print(step if flag else "-1")