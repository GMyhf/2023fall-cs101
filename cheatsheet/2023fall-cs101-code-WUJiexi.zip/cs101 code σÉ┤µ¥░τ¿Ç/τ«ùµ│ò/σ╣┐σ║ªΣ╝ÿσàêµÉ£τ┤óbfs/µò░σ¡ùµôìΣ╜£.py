from collections import deque

maxn = 100000
in_queue = [False] * (maxn + 1)
def get_step(n):
    queue = deque()
    queue.append(1)
    step = 0
    while True:
        cnt = len(queue)
        for i in range(cnt):
            front = queue.popleft()
            if front == n:
                return step
            in_queue[front] = True
            if 2*front <= n:
                if not in_queue[2*front]:
                    queue.append(2*front)
            if front + 1 <= n:
                if not in_queue[front + 1]:
                    queue.append(front + 1)
        step += 1

n = int(input())
print(get_step(n))