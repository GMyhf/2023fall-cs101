list=[1,2,3,4,5]
sum=0
for i in range(len(list)):
    sum=sum+list[i]
print(sum)
    
