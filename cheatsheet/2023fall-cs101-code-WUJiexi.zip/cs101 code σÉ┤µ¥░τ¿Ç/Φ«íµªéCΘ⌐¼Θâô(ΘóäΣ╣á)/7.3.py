sum=0
counter=1
while counter<=100:
    sum=sum+counter
    counter+=1
print("1到100之和：%d"%sum)

