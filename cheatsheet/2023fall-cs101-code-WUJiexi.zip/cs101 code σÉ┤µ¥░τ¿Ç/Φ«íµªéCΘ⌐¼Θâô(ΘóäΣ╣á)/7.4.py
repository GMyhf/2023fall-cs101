while 1:
    print("I love you")
