num=int(input())
if num % 2 == 0:
    print("偶数")
else:
    print("奇数")
    
