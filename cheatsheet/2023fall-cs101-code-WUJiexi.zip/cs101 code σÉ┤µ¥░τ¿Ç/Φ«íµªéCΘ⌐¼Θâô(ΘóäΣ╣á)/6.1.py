num=int(input())
if num<0:
    num=-num
print(num)
