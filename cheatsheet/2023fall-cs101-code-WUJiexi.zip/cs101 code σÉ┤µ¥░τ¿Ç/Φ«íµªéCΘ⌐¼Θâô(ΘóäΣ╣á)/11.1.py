def max(x,y):
    if x>y:
        result=x
    else:
        result=y
    return result
x,y=map(int,input().split())
c=max(x,y)
print(c,x,y)
