a,n=map(int,input().split())
sum=0
x=0
for i in range(1,n+1):
    x = x*10 + a
    sum += x
print(sum)
