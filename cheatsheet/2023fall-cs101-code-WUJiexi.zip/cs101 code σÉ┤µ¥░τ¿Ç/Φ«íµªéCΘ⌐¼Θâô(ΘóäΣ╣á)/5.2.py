str=input()
num=int(str)
num2=num**2
print(num2)
