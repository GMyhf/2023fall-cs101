sum=0
for num in range(1,101):
    sum=sum+num
print("%d"%sum)
