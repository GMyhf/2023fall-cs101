sex=input("请输入您的性别(M或是F):")
age=int(input("请输入您的年龄(1-120):"))
if sex=="M":
    if age>=22:
        print("达到合法结婚年龄")
    else:
        print("未达到合法结婚年龄")
if sex=="F":
    if age>=20:
        print("达到合法结婚年龄")
    else:
        print("未达到合法结婚年龄")
