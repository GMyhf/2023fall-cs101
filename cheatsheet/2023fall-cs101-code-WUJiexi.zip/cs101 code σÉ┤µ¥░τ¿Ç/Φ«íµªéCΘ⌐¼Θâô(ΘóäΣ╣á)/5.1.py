name=input()
message="Hello"+name
print(message)
