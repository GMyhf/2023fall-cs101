def parts(x):
    if x == 0:
        return 1
    else:
        y=x+parts(x-1)
        return y
n=int(input())
print("%d刀最多能切成%d块"%(n,parts(n)))