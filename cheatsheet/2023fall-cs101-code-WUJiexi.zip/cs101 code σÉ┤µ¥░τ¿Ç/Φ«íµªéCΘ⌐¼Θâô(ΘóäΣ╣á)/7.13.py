a,n=map(int,input().split())
sum=0
for i in range(1,n+1):
    x=0
    for j in range(0,i):
        x = x + a*(10**j)
    sum += x
print(sum)
