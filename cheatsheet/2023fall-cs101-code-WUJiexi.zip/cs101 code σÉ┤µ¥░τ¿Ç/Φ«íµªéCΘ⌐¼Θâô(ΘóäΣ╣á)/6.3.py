score=int(input())
if score>=85:
    print("优秀")
elif score>=75:
    print("良好")
elif score>=60:
    print("及格")
else:
    print("不及格")
