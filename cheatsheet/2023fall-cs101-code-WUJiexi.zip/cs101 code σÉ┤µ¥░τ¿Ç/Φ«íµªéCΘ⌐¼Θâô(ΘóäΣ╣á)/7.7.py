for i in range(1,10):
    for j in range(1,10):
        print("%d*%d=%2d"%(i,j,i*j),end="\t")
    print("\n")
