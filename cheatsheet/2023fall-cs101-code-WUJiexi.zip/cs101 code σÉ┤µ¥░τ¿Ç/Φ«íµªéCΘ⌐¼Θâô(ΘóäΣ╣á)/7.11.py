for hundred in range(1,10):
    for ten in range(0,10):
        for one in range(0,10):
            if (hundred**3 + ten**3 + one**3 == hundred*100 + ten*10 + one*1):
                print(hundred,ten,one,sep="")
