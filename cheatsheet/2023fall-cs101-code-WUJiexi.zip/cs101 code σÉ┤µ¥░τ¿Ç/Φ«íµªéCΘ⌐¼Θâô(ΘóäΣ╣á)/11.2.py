def divide_exactly(x,y):
    if x%y == 0 : return True
    else : return False

def is_Prime(a):
    if a<2 : return False
    for i in range(2,int(a**0.5)+1):
        if divide_exactly(a,i): return False
    return True

for n in range(1,1000):
    if is_Prime(n):
        print(n,end=' ')

