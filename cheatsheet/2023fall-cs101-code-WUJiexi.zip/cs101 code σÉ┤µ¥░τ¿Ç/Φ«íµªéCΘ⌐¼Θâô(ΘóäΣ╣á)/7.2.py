for i in range(100):
    print("I love you")
