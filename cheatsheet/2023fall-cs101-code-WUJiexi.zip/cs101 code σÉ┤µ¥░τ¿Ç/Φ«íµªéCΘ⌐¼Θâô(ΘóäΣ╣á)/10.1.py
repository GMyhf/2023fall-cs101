d={"name":"alice","age":19,"sex":"f"}
for it in d.items():
    print("key=%s,value=%s"%(it[0],it[1]))