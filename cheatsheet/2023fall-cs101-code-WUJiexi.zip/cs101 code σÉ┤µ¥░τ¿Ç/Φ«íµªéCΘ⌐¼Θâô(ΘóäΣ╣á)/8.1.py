s=[10,20,30,40,50,60]
sum=0
for i in s:
    sum=sum + i
print(sum)
