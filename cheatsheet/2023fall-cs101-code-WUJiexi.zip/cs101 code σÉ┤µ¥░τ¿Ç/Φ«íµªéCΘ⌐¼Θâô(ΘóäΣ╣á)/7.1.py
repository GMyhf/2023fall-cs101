n=int(input())
l=[100,50,20,10,5,1]
for i in l:
    print(n//i)
    n=n%i
