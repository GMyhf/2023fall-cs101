n=int(input())
sum=list(map(int,input().split()))
v=int(input())
flag=False
for i in range(len(sum)):
    if v==sum[i]:
        flag=True
        break
if flag==True:
    print(i)
else:
    print(-1)
