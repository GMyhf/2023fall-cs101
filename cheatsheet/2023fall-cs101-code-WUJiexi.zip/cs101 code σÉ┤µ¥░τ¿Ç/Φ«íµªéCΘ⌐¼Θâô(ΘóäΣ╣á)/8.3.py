squares=[]
for i in range(10):
    squares.append(i**3)
print(squares)
