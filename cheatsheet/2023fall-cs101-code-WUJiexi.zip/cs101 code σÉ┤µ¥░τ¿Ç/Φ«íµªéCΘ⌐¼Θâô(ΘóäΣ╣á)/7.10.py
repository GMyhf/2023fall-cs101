for n in range (100,1000):
    s=str(n)
    hundred=int(s[0])
    ten=int(s[1])
    one=int(s[2])
    if (hundred**3 + ten**3 + one**3 == n):
        print(n)
