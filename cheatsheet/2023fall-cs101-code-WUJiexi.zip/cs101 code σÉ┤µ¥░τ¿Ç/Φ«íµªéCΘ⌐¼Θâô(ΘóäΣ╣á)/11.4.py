n=int(input())
#初始值
nf=1
#利用循环计算
for i in range(2,n+1):
    nf=i*nf
print(nf)