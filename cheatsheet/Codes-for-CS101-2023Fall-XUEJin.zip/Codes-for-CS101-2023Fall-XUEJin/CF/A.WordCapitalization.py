s = input()
print(s[0].upper()+s[1:])