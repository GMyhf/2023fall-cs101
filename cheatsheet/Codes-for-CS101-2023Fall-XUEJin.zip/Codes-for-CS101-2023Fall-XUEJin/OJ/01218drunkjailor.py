r = int(input())
for i in range(r):
    n = int(input())
    print(int(n**0.5))
