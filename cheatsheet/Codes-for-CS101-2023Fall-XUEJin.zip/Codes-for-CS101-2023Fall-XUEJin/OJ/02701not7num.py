print(sum([i**2 for i in range(1, int(input()) + 1) if i % 7 != 0 and '7' not in str(i)]))
