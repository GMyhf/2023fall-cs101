from math import log2;exec(int(input())*'n=int(input());print(n*(n+1)//2-2**(int(log2(n))+2)+2)\n')
