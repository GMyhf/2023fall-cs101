for _ in range(int(input())): n = input(); print('Yes' if int(n) % 19 == 0 or '19' in n else 'No')
