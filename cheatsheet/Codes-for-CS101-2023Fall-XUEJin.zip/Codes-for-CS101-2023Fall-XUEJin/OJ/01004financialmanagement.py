print(f'${sum([float(input()) for _ in range(12)]) / 12:.2f}')
