# Codes for CS101 Fall

Contributed by `stretcher`， 2023.12.28

这些代码是本人这学期于计概课在code forces平台上作业代码以及在open judge平台上所有代码的最终版本。由于这些代码本来并非用于交流，因此部分代码可能可读性较差，但聊胜于无吧。

`NoteforCS1012023FallComplete.pdf`是一学期中记录的笔记形成的最后参加期末考的参考资料，可读性较强，但因为是针对个人设计，仅供参考。

不胜谫陋，聊作分享。