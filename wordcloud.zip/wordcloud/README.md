# README



## 2023fall-cs101__Algo_DS.txt

是用 https://github.com/LC044/WeChatMsg 提取的课程微信群文本内容。



## wechat_wordcloud.py

可以参照 Python制作词云图从未如此简单，https://zhuanlan.zhihu.com/p/138356932

源码中 29行 font_path，不同系统，需要做相应修改，我是mac。



outpu0~2.jpg,  是运行输出词云图。



## stopword 目录

stopword.txt是自己编辑，主要过滤了姓名。

容易分辨哪些同学参与了讨论，手动加在停用词表过滤了。否则词云显示出来很多同学的姓名。



其他文件下载自，https://github.com/goto456/stopwords

中文常用停用词表

| 词表名 | 词表文件 |
| - | - |
| 中文停用词表                   | cn\_stopwords.txt    |
| 哈工大停用词表                 | hit\_stopwords.txt   |
| 百度停用词表                   | baidu\_stopwords.txt |
| 四川大学机器智能实验室停用词库 | scu\_stopwords.txt   |







