import matplotlib.pyplot as plt
import jieba
from wordcloud import WordCloud
from collections import Counter
import random
import numpy as np #科学计算
from PIL import Image #处理图片
import os

def read_stopword(fpath):
    # 读取中文停用词表
    with open(fpath, 'r', encoding='utf-8') as file:
        stopword = file.readlines()
    return [word.replace('\n', '') for word in stopword]

#加载多个停用词表
path = './stopword'
# 前两个停用词表是网上下载的，第三个是自己设置的
name_list = ['cn_stopwords.txt', 'baidu_stopwords.txt', 'stopword.txt']

stop_word = []
for fname in name_list:
    stop_word += read_stopword(os.path.join(path, fname))
stop_word = set(stop_word)



#font_path = "/System/Library/Fonts/STHeiti Light.ttc"
font_path = "/System/Library/Fonts/STHeiti Medium.ttc"


with open('2023fall-cs101__Algo_DS.txt','r',encoding='utf8') as f:  #打开新的文本转码为gbk
        textfile= f.read()  #读取文本内容
wordlist = jieba.lcut(textfile)#切割词语
wordlist = [item.strip('\n') for item in wordlist]
space_list = ' '.join(wordlist)

# 统计词频
word_freq = Counter(wordlist)

# 打印词频结果
#for word, freq in word_freq.items():
#    print(f"{word}: {freq}")

# 随机生成词的颜色
def random_color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return f"hsl({random.randint(0, 255)}, {random.randint(60, 80)}%, {random.randint(40, 70)}%)"

mask = np.array(Image.open('blue.jpg')) 
# 创建词云对象，并设置词频作为词语大小
wordcloud = WordCloud(background_color="white",
                      #mode='RGB',
                      mask=mask,
                      stopwords = stop_word,
                      #stopwords=STOPWORDS.add('闫'),
                      #contour_width=1,
                      #contour_color='steelblue',
                      width=4000, height=4000, 
                      max_font_size=180,            #   显示字体的最大值
                      #random_state=40,             #   为每一词返回一个PIL颜色
                      #prefer_horizontal=10,        #   调整词云中字体水平和垂直的多少
                      color_func=random_color_func,
                      font_path=font_path)



# 生成词云图
#wordcloud.generate_from_frequencies(word_freq)
wordcloud.generate(space_list)

#wordcloud.fit_words(word_freq)
#image_color = ImageColorGenerator(mask)#设置生成词云的颜色，如去掉这两行则字体为默认颜色
#wordcloud.recolor(color_func=image_color)

# 显示词云图
plt.figure(figsize=(16, 16))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.tight_layout(pad = 0) 
plt.show()

